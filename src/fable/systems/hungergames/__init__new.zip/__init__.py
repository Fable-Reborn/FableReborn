import asyncio
import copy
import random as randomm
from io import BytesIO
from typing import Dict, List, Tuple, Union, Optional

import discord
from discord import Embed, Color
from discord.enums import ButtonStyle
from discord.ext import commands
from discord.ui.button import Button

from cogs.help import chunks
from utils import random
from utils.checks import is_gm
from utils.i18n import _, locale_doc
from utils.joins import JoinView
from utils.misc import nice_join


class Player:
    def __init__(self, user, team_id=None):
        self.user = user
        self.name = user.name
        self.mention = user.mention
        self.avatar = user.avatar
        self.avatar_url = str(user.avatar) if user.avatar else None
        self.team_id = team_id
        self.health = 100
        self.food = 50
        self.water = 50
        self.weapons = []
        self.items = []
        self.status_effects = []
        self.kills = 0
        self.is_alive = True
        self.current_area = "Cornucopia"
        self.combat_bonus = 0
        self.defense_bonus = 0

    def get_avatar_url(self):
        """Get player avatar URL with fallback"""
        if self.avatar_url:
            return self.avatar_url
        return "https://cdn.discordapp.com/embed/avatars/0.png"

    def add_item(self, item):
        self.items.append(item)

    def add_weapon(self, weapon):
        self.weapons.append(weapon)

    def add_status_effect(self, effect, duration=1):
        self.status_effects.append((effect, duration))

    def update_status_effects(self):
        """Update status effects at the end of a round"""
        new_status_effects = []
        for effect, duration in self.status_effects:
            if duration > 1:
                new_status_effects.append((effect, duration - 1))
            # Apply effect consequences that persist until removed
            if effect == "poisoned":
                self.health -= 10
            elif effect == "wounded":
                self.health -= 5
            elif effect == "infection":
                self.health -= 15
            elif effect == "bleeding":
                self.health -= 8
            elif effect == "food poisoning":
                self.health -= 7
                self.food -= 10
        self.status_effects = new_status_effects

        # Basic survival mechanics with variance
        self.food -= randomm.randint(5, 15)
        self.water -= randomm.randint(10, 20)

        if self.food <= 0:
            self.health -= 10
            self.food = 0
        if self.water <= 0:
            self.health -= 15
            self.water = 0

        if self.health <= 0:
            self.is_alive = False
            return False
        return True

    def get_status_emoji(self):
        """Get emoji indicating player status"""
        if not self.is_alive:
            return "💀"
        if self.health < 30:
            return "🩸"
        if self.health < 60:
            return "⚠️"
        return "✅"

    def get_status_display(self):
        """Get a formatted status display"""
        status = []
        status.append(f"❤️ {self.health}/100")
        status.append(f"🍗 {self.food}/100")
        status.append(f"💧 {self.water}/100")

        if self.weapons:
            status.append(f"🗡️ {', '.join(self.weapons)}")

        if self.status_effects:
            effects = [effect for effect, _ in self.status_effects]
            status.append(f"⚠️ {', '.join(effects)}")

        return " | ".join(status)


class Team:
    def __init__(self, team_id, players):
        self.team_id = team_id
        self.players = players
        self.base = None
        self.alliances = []  # List of Team objects
        self.enemies = []    # List of Team objects
        self.items = []
        self.weapons = []
        self.traps = []
        self.team_bonus = 0  # Bonus from training activities

    def form_alliance(self, other_team):
        """Form alliance with another team"""
        if other_team not in self.alliances and other_team != self:
            self.alliances.append(other_team)
            other_team.alliances.append(self)
            # Remove from enemies if present
            if other_team in self.enemies:
                self.enemies.remove(other_team)
            if self in other_team.enemies:
                other_team.enemies.remove(self)

    def break_alliance(self, other_team):
        """Break alliance with another team"""
        if other_team in self.alliances:
            self.alliances.remove(other_team)
            other_team.alliances.remove(self)
            self.enemies.append(other_team)
            other_team.enemies.append(self)

    def is_active(self):
        return any(player.is_alive for player in self.players)

    def get_alive_players(self):
        return [player for player in self.players if player.is_alive]

    def add_item(self, item):
        self.items.append(item)

    def add_weapon(self, weapon):
        self.weapons.append(weapon)

    def add_trap(self, trap_type, location):
        self.traps.append((trap_type, location))

    def get_team_avatar(self):
        """Get an avatar for the team (first living member)"""
        alive_players = self.get_alive_players()
        if alive_players:
            return alive_players[0].get_avatar_url()
        elif self.players:
            return self.players[0].get_avatar_url()
        return "https://cdn.discordapp.com/embed/avatars/0.png"

    def add_to_embed(self, embed, show_detailed=False):
        """Add this team to an embed with player pictures"""
        alive_count = len(self.get_alive_players())
        total_count = len(self.players)
        team_kills = sum(p.kills for p in self.players)

        field_name = f"Team {self.team_id + 1} ({alive_count}/{total_count} alive)"

        if alive_count == 0:
            field_name = f"💀 {field_name}"

        values = []
        for player in self.players:
            status = player.get_status_emoji()
            player_line = f"{status} {player.name}"
            if show_detailed:
                player_line += f": {player.get_status_display()}"
            else:
                player_line += f" (❤️ {player.health})"
            values.append(player_line)

        value = "\n".join(values)
        if team_kills > 0:
            value += f"\n\nTeam Kills: {team_kills}"

        embed.add_field(name=field_name, value=value, inline=False)

        # Add thumbnail if this is the only team in the embed
        if len(embed.fields) == 1 and alive_count > 0:
            embed.set_thumbnail(url=self.get_team_avatar())


class GameMaster:
    """Game Master that can influence events and control the arena"""
    def __init__(self, user):
        self.user = user
        self.name = user.name
        self.mention = user.mention
        self.avatar = user.avatar
        self.avatar_url = str(user.avatar) if user.avatar else None
        self.influence_points = 3
        self.available_events = [
            "Weather Change",
            "Supply Drop",
            "Arena Hazard",
            "Tribute Buff",
            "Tribute Debuff",
            "Feast Announcement",
            "Arena Shift",
            "Muttation Release"
        ]

    async def choose_event(self, ctx, game):
        """Let the GM choose an event to trigger"""
        if self.influence_points <= 0:
            await ctx.send(f"{self.name} has no influence points left!")
            return None

        try:
            event_index = await ctx.bot.paginator.Choose(
                entries=self.available_events,
                return_index=True,
                title="Choose an event to trigger",
            ).paginate(ctx, location=self.user)

            event = self.available_events[event_index]
            self.influence_points -= 1
            return await self.trigger_event(ctx, game, event)
        except Exception:
            await ctx.send(f"The Game Master couldn't choose an event.")
            return None

    async def trigger_event(self, ctx, game, event):
        """Trigger a specific event in the game"""
        embed = discord.Embed(
            title=f"Game Master Event: {event}",
            description=f"{self.name} has triggered a special event!",
            color=discord.Color.purple()
        )

        embed.set_thumbnail(url=self.avatar_url if self.avatar_url else "https://cdn.discordapp.com/embed/avatars/0.png")
        embed.set_footer(text=f"Game Master influence points remaining: {self.influence_points}")

        if event == "Weather Change":
            weather = randomm.choice(["Heavy Rain", "Extreme Heat", "Freezing Cold", "Dense Fog", "Strong Winds"])
            embed.add_field(name="The Weather Changes", value=f"The arena is now experiencing {weather}.")
            game.weather = weather

            # Apply effects based on weather
            affected = []
            for player in [p for p in game.players if p.is_alive]:
                if weather == "Freezing Cold" and "Sleeping Bag" not in player.items:
                    damage = randomm.randint(5, 15)
                    player.health -= damage
                    affected.append(f"{player.name} takes {damage} cold damage")
                elif weather == "Extreme Heat" and "Water Canteen" not in player.items:
                    player.water -= randomm.randint(10, 25)
                    affected.append(f"{player.name} loses water to dehydration")

            if affected:
                embed.add_field(name="Affected Tributes", value="\n".join(affected))

        elif event == "Supply Drop":
            locations = randomm.sample(game.map_areas, 3)
            embed.add_field(
                name="Supply Drops Incoming",
                value=f"Supply crates have been dropped at:\n- {locations[0]}\n- {locations[1]}\n- {locations[2]}"
            )
            game.supply_drops = locations

        elif event == "Arena Hazard":
            hazard = randomm.choice(["Fire", "Toxic Gas", "Flooding", "Earthquake", "Falling Trees"])
            location = randomm.choice(game.map_areas)
            embed.add_field(
                name=f"Hazard Activated: {hazard}",
                value=f"A {hazard} has been triggered in the {location} area."
            )
            game.hazards.append((hazard, location))

            # Apply immediate effects if players are in that area
            affected = []
            for player in [p for p in game.players if p.is_alive and p.current_area == location]:
                damage = randomm.randint(10, 30)
                player.health -= damage
                affected.append(f"{player.name} takes {damage} damage from the {hazard}")

                if player.health <= 0:
                    player.is_alive = False
                    game.killed_this_round.append(player)
                    affected[-1] += " [KILLED]"

            if affected:
                embed.add_field(name="Affected Tributes", value="\n".join(affected))

        elif event == "Tribute Buff":
            # Choose a random player to buff
            player = randomm.choice([p for p in game.players if p.is_alive])
            buff_type = randomm.choice(["Health", "Combat", "Speed", "Stealth"])

            embed.add_field(
                name=f"Tribute Receives Sponsor Gift",
                value=f"{player.name} has received a special gift enhancing their {buff_type}!"
            )

            if buff_type == "Health":
                player.health = min(100, player.health + 30)
                embed.add_field(name="Effect", value=f"{player.name} recovers 30 health.")
            elif buff_type == "Combat":
                weapon = randomm.choice(list(game.weapons.keys()))
                player.add_weapon(weapon)
                embed.add_field(name="Effect", value=f"{player.name} receives a {weapon}.")
                player.combat_bonus += 10

        elif event == "Tribute Debuff":
            # Choose a random player to debuff
            player = randomm.choice([p for p in game.players if p.is_alive])
            debuff_type = randomm.choice(["Injury", "Poison", "Theft", "Confusion"])

            embed.add_field(
                name=f"Tribute Struck by Misfortune",
                value=f"{player.name} has been affected by {debuff_type}!"
            )

            if debuff_type == "Injury":
                damage = randomm.randint(10, 25)
                player.health -= damage
                embed.add_field(name="Effect", value=f"{player.name} takes {damage} damage.")

                if player.health <= 0:
                    player.is_alive = False
                    game.killed_this_round.append(player)
                    embed.add_field(name="FATALITY", value=f"{player.name} has died from their injuries!")
            elif debuff_type == "Poison":
                player.add_status_effect("poisoned", randomm.randint(2, 4))
                embed.add_field(name="Effect", value=f"{player.name} is poisoned for several rounds.")

        elif event == "Feast Announcement":
            game.cornucopia_active = True
            embed.add_field(
                name="Feast Announced",
                value="A feast has been prepared at the Cornucopia. Supplies, weapons, and medicine await those brave enough to attend."
            )

        elif event == "Arena Shift":
            # Force players to move to new areas
            for player in [p for p in game.players if p.is_alive]:
                new_area = randomm.choice([a for a in game.map_areas if a != player.current_area])
                player.current_area = new_area

            embed.add_field(
                name="Arena Boundaries Shift",
                value="The Gamemakers have forced all tributes into new areas of the arena."
            )

        elif event == "Muttation Release":
            mutt_type = randomm.choice(["Tracker Jackers", "Wolf Mutts", "Lizard Mutts", "Monkey Mutts"])
            area = randomm.choice(game.map_areas)

            embed.add_field(
                name=f"Muttation Release: {mutt_type}",
                value=f"The Gamemakers have released {mutt_type} into the {area}."
            )

            # Attack players in that area
            victims = []
            for player in [p for p in game.players if p.is_alive and p.current_area == area]:
                damage = randomm.randint(15, 35)
                player.health -= damage
                victims.append(f"{player.name} takes {damage} damage")

                if mutt_type == "Tracker Jackers":
                    player.add_status_effect("hallucinations", 2)
                    victims[-1] += " and is hallucinating"

                if player.health <= 0:
                    player.is_alive = False
                    game.killed_this_round.append(player)
                    victims[-1] += " [KILLED]"

            if victims:
                embed.add_field(name="Muttation Victims", value="\n".join(victims))
            else:
                embed.add_field(name="No Victims", value="No tributes were in the area.")

        return embed


class GameBase:
    def __init__(self, ctx, players: list, is_test_mode=False, num_bots=2, force_choice=False):
        self.ctx = ctx
        self.raw_players = players
        self.players = []
        self.teams = []
        self.round = 1
        self.events = []
        self.map_areas = ["Cornucopia", "Forest", "Mountain", "Lake", "Cave", "Ruins", "Plains", "Beach"]
        self.current_area = "Cornucopia"
        self.is_test_mode = is_test_mode
        self.num_bots = num_bots  # Store the number of bots to add
        self.bot_players = []
        self.force_choice = force_choice
        self.bot_names = [
            "BotTribute1", "BotTribute2", "BotTribute3", "BotTribute4",
            "BotTribute5", "BotTribute6", "BotTribute7", "BotTribute8",
            "DeadlyBot", "SurvivorBot", "HunterBot", "SneakyBot"
        ]
        # Game state tracking
        self.day = 1
        self.is_night = False
        self.cornucopia_active = True
        self.special_events = []
        self.killed_this_round = []
        self.traps = []  # List of (trap_type, location, owner) tuples
        self.weather = "Clear"  # Initialize weather attribute
        self.supply_drops = []  # Initialize supply drops
        self.hazards = []  # Initialize hazards

        # Initialize Game Master
        self.game_master = None

        # In test mode, command author becomes GM
        if is_test_mode and players:
            # Make the command author (first player) the Game Master
            self.game_master = GameMaster(players[0])
        # In normal mode, check for GM permissions
        elif not is_test_mode:
            for player in players:
                if is_gm(player):
                    self.game_master = GameMaster(player)
                    self.raw_players.remove(player)
                    break

        # Randomly select a player as GM if none was found and we want to ensure a GM
        if self.game_master is None and players and randomm.random() < 0.3:  # 30% chance
            random_player = randomm.choice(players)
            # Don't remove from players - they'll be both GM and player
            self.game_master = GameMaster(random_player)

        # Item and weapon lists with power values
        self.weapons = {
            "Wooden Spear": 10,
            "Bow": 15,
            "Crossbow": 20,
            "Sword": 25,
            "Mace": 30,
            "Chainsaw": 40,
            "Throwing Knives": 15,
            "Slingshot": 10,
            "Axe": 20,
            "Pickaxe": 15,
            "Machete": 20,
            "Trident": 25,
            "Brass Knuckles": 10,
            "Blowgun": 15,
            "Poison Darts": 25
        }

        self.items = {
            "First Aid Kit": "healing",
            "Bandages": "healing",
            "Backpack": "utility",
            "Water Canteen": "water",
            "Purification Tablets": "water",
            "Rope": "utility",
            "Sleeping Bag": "utility",
            "Night Vision Goggles": "utility",
            "Food Rations": "food",
            "Fishing Rod": "food",
            "Matches": "utility",
            "Camouflage Paint": "stealth",
            "Landmine": "trap",
            "Spikes": "trap",
            "Poison": "offensive",
            "Antidote": "healing",
            "Smoke Bomb": "escape",
            "Signal Flare": "utility",
            "Map": "intel",
            "Compass": "intel",
            "Shield": "defense",
            "Armor": "defense",
            "Helmet": "defense"
        }

    def get_active_teams(self):
        """Return list of teams with at least one living member"""
        return [team for team in self.teams if team.is_active()]

    def create_bot_player(self, name=None):
        """Create a bot player for testing"""
        if not name:
            name = self.bot_names.pop(0) if self.bot_names else f"Bot{randomm.randint(1,999)}"

        # Create a fake user object with the necessary attributes
        class FakeUser:
            def __init__(self, name):
                self.name = name
                self.mention = f"@{name}"
                self.avatar = None
                self.id = randomm.randint(10000, 99999)

        user = FakeUser(name)
        player = Player(user)
        self.bot_players.append(player)
        return player

    def setup_game(self):
        """Initialize players and teams for the game"""
        if self.is_test_mode:
            # Add exactly self.num_bots bots
            for _ in range(self.num_bots):
                self.raw_players.append(self.create_bot_player())

        # Shuffle players for randomized teams
        all_players = copy.copy(self.raw_players)
        randomm.shuffle(all_players)

        # Create Player objects
        for idx, user in enumerate(all_players):
            player = Player(user) if not hasattr(user, 'health') else user
            player.current_area = "Cornucopia"  # Everyone starts at the Cornucopia
            self.players.append(player)

        # Form teams
        self.form_teams()

    def form_teams(self):
        """
        Create teams of exactly 2, with one leftover if odd.
        We'll assume the list is already shuffled in setup_game.
        """
        self.teams.clear()
        player_count = len(self.players)

        # Chunk players into pairs of 2
        chunked = [self.players[i: i + 2] for i in range(0, player_count, 2)]

        for team_id, chunk in enumerate(chunked):
            for p in chunk:
                p.team_id = team_id
            self.teams.append(Team(team_id, chunk))

    async def send_cast(self):
        """Display the teams and players with profile pictures"""
        embed = discord.Embed(
            title="The Hunger Games - The Cast",
            description="May the odds be ever in your favor!",
            color=discord.Color.blue()
        )

        # If there's a Game Master, show them first
        if self.game_master:
            embed.add_field(
                name="Game Master",
                value=f"{self.game_master.name} will control the arena!",
                inline=False
            )
            embed.set_thumbnail(url=self.game_master.avatar_url if self.game_master.avatar_url else "https://cdn.discordapp.com/embed/avatars/0.png")

        # Add all teams to the embed
        for team in self.teams:
            team.add_to_embed(embed)

        await self.ctx.send(embed=embed)

    def get_team_actions(self, team_size):
        """Get appropriate team actions based on team size"""
        # Team actions with real gameplay effects
        common_actions = [
            (_("search for water and food together"), {"type": "gather", "food": 20, "water": 30}),
            (_("set up a defensive camp"), {"type": "defend", "defense_bonus": 15}),
            (_("forge an alliance with another team"), {"type": "alliance"}),
            (_("hunt for wild game"), {"type": "gather", "food": 35}),
            (_("raid another team's supplies"), {"type": "raid"}),
            (_("set deadly traps for others"), {"type": "trap"}),
            (_("find a good vantage point to scout"), {"type": "scout"}),
            (_("train together to improve combat skills"), {"type": "train", "combat_bonus": 10}),
            (_("share supplies and treat each other's wounds"), {"type": "heal", "health": 20}),
            (_("ambush another tribute"), {"type": "ambush"}),
            (_("move to a new area for better resources"), {"type": "move"}),
            (_("build fortifications in their current area"), {"type": "fortify"}),
        ]

        # Actions specific to 2-person teams
        duo_actions = [
            (_("form a romantic alliance"), {"type": "bond", "morale": 20}),
            (_("share a heartfelt conversation by the fire"), {"type": "bond", "morale": 15}),
            (_("take shifts keeping watch during the night"), {"type": "defend", "defense_bonus": 20}),
            (_("teach each other survival skills"), {"type": "train", "skill_bonus": 15}),
        ]

        # Actions specific to 3+ person teams
        group_actions = [
            (_("split up to cover more ground"), {"type": "explore", "discovery_chance": 20}),
            (_("hold a strategy meeting"), {"type": "plan", "strategy_bonus": 15}),
            (_("combine their skills to create something useful"), {"type": "craft"}),
            (_("perform a coordinated hunt"), {"type": "hunt", "food": 40, "combat_bonus": 10}),
        ]

        # Lethal team actions
        lethal_actions = [
            (_("hunt down USER"), {"type": "kill", "target": "USER"}),
            (_("ambush USER at the river"), {"type": "kill", "target": "USER"}),
            (_("set a trap that kills USER"), {"type": "kill", "target": "USER"}),
            (_("surround and eliminate USER"), {"type": "kill", "target": "USER"}),
        ]

        # Team failures or accidents
        accident_actions = [
            (_("accidentally trigger their own trap"), {"type": "accident", "damage": 30}),
            (_("eat poisonous berries by mistake"), {"type": "poison", "damage": 25}),
            (_("get into a violent argument"), {"type": "betrayal"}),
            (_("lose their way and wander into danger"), {"type": "lost"}),
        ]

        # Attack actions targeting teams
        team_attack_actions = [
            (_("attack Team USER"), {"type": "attack", "target": "USER"}),
            (_("raid Team USER's camp"), {"type": "raid", "target": "USER"}),
            (_("steal supplies from Team USER"), {"type": "steal", "target": "USER"}),
            (_("betray their alliance with Team USER"), {"type": "betrayal", "target": "USER"}),
        ]

        # Build the action list based on team size
        if team_size == 2:
            actions = common_actions + duo_actions
        else:
            actions = common_actions + group_actions

        # Add some lethal, team attack, and accident actions
        actions += lethal_actions + team_attack_actions + accident_actions

        return actions

    def get_solo_actions(self):
        """Get actions for solo players with meaningful gameplay effects"""
        # Basic survival actions
        survival_actions = [
            (_("search for food"), {"type": "gather", "food": 25}),
            (_("look for water"), {"type": "gather", "water": 30}),
            (_("set up a small shelter"), {"type": "shelter", "defense": 15}),
            (_("scout the area"), {"type": "scout", "intel": 1}),
            (_("forage for medicinal herbs"), {"type": "heal", "health": 20}),
            (_("hunt small game"), {"type": "hunt", "food": 20}),
            (_("fish at the lake"), {"type": "fish", "food": 15, "water": 10}),
            (_("move to a different area"), {"type": "move"}),
        ]

        # Combat/offensive actions
        combat_actions = [
            (_("craft a makeshift weapon"), {"type": "craft", "weapon": True}),
            (_("set traps for other tributes"), {"type": "trap"}),
            (_("stalk another tribute"), {"type": "stalk"}),
            (_("attack USER"), {"type": "attack", "target": "USER"}),
            (_("ambush USER"), {"type": "ambush", "target": "USER"}),
            (_("poison USER's water supply"), {"type": "poison", "target": "USER"}),
        ]

        # Special actions
        special_actions = [
            (_("search for supplies at the Cornucopia"), {"type": "cornucopia"}),
            (_("steal from another tribute"), {"type": "steal"}),
            (_("form an alliance with another loner"), {"type": "alliance"}),
            (_("hide and observe other tributes"), {"type": "observe"}),
            (_("follow another tribute"), {"type": "follow"}),
            (_("build defenses around current position"), {"type": "fortify"}),
        ]

        # Risky actions with high reward/risk
        risky_actions = [
            (_("attempt to raid a team's camp"), {"type": "raid", "team": True}),
            (_("search the most dangerous part of the arena"), {"type": "danger"}),
            (_("challenge USER to a direct fight"), {"type": "duel", "target": "USER"}),
            (_("attempt to steal from the strongest team"), {"type": "steal", "team": True}),
        ]

        # Desperate actions
        desperate_actions = [
            (_("run away and hide"), {"type": "hide"}),
            (_("beg for mercy from USER"), {"type": "beg", "target": "USER"}),
            (_("play dead to avoid detection"), {"type": "fake_death"}),
            (_("make a desperate attack on USER"), {"type": "desperate", "target": "USER"}),
        ]

        # Self-ending actions
        end_actions = [
            (_("take a lethal poison"), {"type": "suicide"}),
            (_("walk into a known trap zone"), {"type": "suicide"}),
            (_("give up and stop running"), {"type": "surrender"}),
        ]

        # Combine all action types with weights to control frequency
        all_actions = survival_actions * 3 + combat_actions * 2 + special_actions * 2 + risky_actions + desperate_actions

        # Add end actions only rarely
        if randomm.random() < 0.05:  # 5% chance
            all_actions.extend(end_actions)

        return all_actions

    async def process_combat(self, attacker, target, attack_type="normal"):
        """Process combat between players with enhanced mechanics"""
        embed = discord.Embed(
            title="Combat Encounter",
            description=f"{attacker.name} attacks {target.name}!",
            color=discord.Color.red()
        )

        # Add attacker thumbnail (use their avatar with grayscale if dead)
        embed.set_thumbnail(url=attacker.get_avatar_url())

        # Calculate attack power
        weapon_power = 0
        for weapon in attacker.weapons:
            weapon_power += self.weapons.get(weapon, 5)

        # Add attacker's combat bonus from training
        weapon_power += attacker.combat_bonus

        # Base attack chance depends on attack type
        base_chance = 50
        if attack_type == "ambush":
            base_chance += 20
            embed.add_field(name="Ambush Advantage", value="+20% success chance", inline=True)
        elif attack_type == "duel":
            base_chance += 10
            embed.add_field(name="Direct Challenge", value="+10% success chance", inline=True)

        # Adjust for weapons
        base_chance += min(30, weapon_power // 2)

        # Defensive items reduce success chance
        defense_bonus = target.defense_bonus
        defensive_items = [
            item for item in target.items
            if item in ["Shield", "Armor", "Helmet", "Camouflage Paint"]
        ]

        for item in defensive_items:
            if item == "Shield":
                defense_bonus += 15
            elif item == "Armor":
                defense_bonus += 20
            elif item == "Helmet":
                defense_bonus += 10
            elif item == "Camouflage Paint":
                defense_bonus += 5

        base_chance -= min(40, defense_bonus)

        # Environmental factors
        if self.is_night and "Night Vision Goggles" not in attacker.items:
            base_chance -= 10
            embed.add_field(name="Night Penalty", value="-10% success chance (no night vision)", inline=True)

        if attacker.current_area == "Forest" and "Camouflage Paint" in target.items:
            base_chance -= 15
            embed.add_field(name="Camouflage Advantage", value="-15% success chance (target hidden)", inline=True)

        # Weather effects
        if self.weather == "Dense Fog":
            base_chance -= 15
            embed.add_field(name="Fog Penalty", value="-15% success chance (poor visibility)", inline=True)
        elif self.weather == "Strong Winds" and "Bow" in attacker.weapons:
            base_chance -= 20
            embed.add_field(name="Wind Penalty", value="-20% success chance (affects archery)", inline=True)

        # Roll for success
        success_roll = randomm.randint(1, 100)
        success = success_roll <= base_chance

        embed.add_field(
            name="Attack Roll",
            value=f"Needed: {base_chance} or less\nRolled: {success_roll}\nResult: {'SUCCESS' if success else 'FAILURE'}",
            inline=False
        )

        if success:
            # Calculate damage
            base_damage = randomm.randint(10, 20)
            weapon_damage = weapon_power // 2
            critical = randomm.random() < 0.1  # 10% chance for critical hit

            if critical:
                damage = base_damage + weapon_damage * 2
                embed.add_field(name="Critical Hit!", value=f"+{weapon_damage} bonus damage", inline=True)
            else:
                damage = base_damage + weapon_damage

            # Reduce damage based on defensive items
            damage_reduction = defense_bonus // 2
            damage = max(5, damage - damage_reduction)

            # Apply damage
            target.health -= damage

            embed.add_field(
                name="Attack Successful",
                value=f"{attacker.name} deals {damage} damage to {target.name}!",
                inline=False
            )

            # Add status effects based on weapon
            if randomm.random() < 0.3:  # 30% chance
                if any(w in ["Sword", "Machete", "Axe"] for w in attacker.weapons):
                    target.add_status_effect("bleeding", randomm.randint(2, 3))
                    embed.add_field(name="Bleeding", value=f"{target.name} is now bleeding!", inline=True)
                elif any(w in ["Poison Darts", "Blowgun"] for w in attacker.weapons):
                    target.add_status_effect("poisoned", randomm.randint(2, 4))
                    embed.add_field(name="Poisoned", value=f"{target.name} has been poisoned!", inline=True)

            # Check for kill
            if target.health <= 0:
                target.health = 0
                target.is_alive = False
                self.killed_this_round.append(target)
                attacker.kills += 1

                embed.add_field(
                    name="Fatality!",
                    value=f"{target.name} has been eliminated by {attacker.name}!",
                    inline=False
                )
                embed.color = discord.Color.dark_red()

            # Status updates
            embed.add_field(
                name=f"{target.name}'s Status",
                value=f"Health: {max(0, target.health)}/100",
                inline=True
            )
        else:
            # Attack failed
            embed.add_field(
                name="Attack Failed",
                value=f"{attacker.name} missed their attack on {target.name}!",
                inline=False
            )

            # Counter-attack chance (20%)
            if randomm.random() < 0.2:
                counter_damage = randomm.randint(5, 15)
                attacker.health -= counter_damage

                embed.add_field(
                    name="Counter-Attack!",
                    value=f"{target.name} counter-attacks for {counter_damage} damage!",
                    inline=False
                )

                # Check for kill on counter
                if attacker.health <= 0:
                    attacker.is_alive = False
                    self.killed_this_round.append(attacker)
                    target.kills += 1

                    embed.add_field(
                        name="Counter Fatality!",
                        value=f"{attacker.name} has been eliminated by {target.name}'s counter-attack!",
                        inline=False
                    )
                    embed.color = discord.Color.dark_red()

        return embed

    async def process_action_effects(self, player, action_data):
        """Process the effects of an action on a player with enhanced consequences"""
        action_type = action_data.get("type", "")
        result_text = ""

        if action_type == "gather":
            food_gain = action_data.get("food", 0)
            water_gain = action_data.get("water", 0)

            # Environmental modifiers
            if self.weather == "Heavy Rain":
                water_gain = int(water_gain * 1.5)  # 50% bonus to water gathering in rain
            elif self.weather == "Extreme Heat":
                water_gain = int(water_gain * 0.7)  # 30% penalty to water gathering in heat

            if player.current_area == "Forest":
                food_gain = int(food_gain * 1.2)  # 20% bonus to food in forest
            elif player.current_area == "Lake":
                water_gain = int(water_gain * 1.5)  # 50% bonus to water at lake

            # Tool bonuses
            if "Fishing Rod" in player.items and player.current_area == "Lake":
                food_gain += randomm.randint(10, 25)
                result_text += " Used fishing rod effectively."

            if "Water Canteen" in player.items and water_gain > 0:
                water_gain = int(water_gain * 1.3)  # 30% bonus to water with canteen

            if "Backpack" in player.items and food_gain > 0:
                food_gain = int(food_gain * 1.2)  # 20% bonus to food with backpack

            if food_gain:
                player.food = min(100, player.food + food_gain)
                result_text += f" Found {food_gain} food."

            if water_gain:
                player.water = min(100, player.water + water_gain)
                result_text += f" Found {water_gain} water."

            # Risk of poisoning from foraged food
            if "Purification Tablets" not in player.items and randomm.random() < 0.1:  # 10% chance
                player.add_status_effect("food poisoning", randomm.randint(1, 3))
                result_text += " Got food poisoning from something they ate!"

        elif action_type == "heal":
            health_gain = action_data.get("health", 0)

            # Item bonuses
            if "First Aid Kit" in player.items:
                health_gain = int(health_gain * 1.5)  # 50% bonus with first aid kit
                player.items.remove("First Aid Kit")  # Consume the item
                result_text += " Used First Aid Kit for improved healing."
            elif "Bandages" in player.items:
                health_gain = int(health_gain * 1.2)  # 20% bonus with bandages
                player.items.remove("Bandages")  # Consume the item
                result_text += " Used Bandages for improved healing."

            # Remove status effects
            if "poisoned" in [effect for effect, _ in player.status_effects] and "Antidote" in player.items:
                new_status = [(e, d) for e, d in player.status_effects if e != "poisoned"]
                player.status_effects = new_status
                player.items.remove("Antidote")
                result_text += " Used Antidote to cure poisoning."

            player.health = min(100, player.health + health_gain)
            result_text += f" Restored {health_gain} health."

        elif action_type == "craft":
            if action_data.get("weapon", False):
                base_weapons = ["Wooden Spear", "Slingshot", "Wooden Club", "Stone Knife"]
                if "Rope" in player.items:
                    base_weapons.extend(["Bow", "Bolas", "Snare"])
                    player.items.remove("Rope")
                    result_text += " Used rope in crafting."

                weapon = randomm.choice(base_weapons)
                player.add_weapon(weapon)
                result_text += f" Crafted a {weapon}."
            else:
                craftable_items = ["Shelter", "Wooden Bowl", "Fishing Hook"]
                if "Rope" in player.items:
                    craftable_items.extend(["Simple Trap", "Water Filter"])
                    player.items.remove("Rope")
                    result_text += " Used rope in crafting."

                item = randomm.choice(craftable_items)
                player.add_item(item)
                result_text += f" Crafted a {item}."

        elif action_type == "trap":
            trap_types = ["snare", "pitfall", "alarm trap"]

            # Add advanced traps if player has the items
            if "Rope" in player.items:
                trap_types.extend(["net trap", "tripwire"])
                player.items.remove("Rope")
                result_text += " Used rope for trap construction."

            if "Spikes" in player.items:
                trap_types.extend(["spike trap", "spike pit"])
                player.items.remove("Spikes")
                result_text += " Used spikes for trap construction."

            if "Poison" in player.items:
                trap_types.extend(["poisoned darts", "poisoned spikes"])
                player.items.remove("Poison")
                result_text += " Used poison for trap construction."

            trap_type = randomm.choice(trap_types)
            location = player.current_area
            self.traps.append((trap_type, location, player))
            result_text += f" Set a {trap_type} trap in the {location}."

            # Chance for immediate trap activation if other players are nearby
            nearby_players = [
                p for p in self.players
                if p.is_alive and p != player and p.current_area == location
            ]

            if nearby_players and randomm.random() < 0.3:  # 30% chance
                target = randomm.choice(nearby_players)
                damage = randomm.randint(10, 30)
                if "poisoned" in trap_type:
                    target.add_status_effect("poisoned", randomm.randint(2, 4))
                    result_text += f" {target.name} was caught and poisoned!"
                else:
                    target.health -= damage
                    result_text += f" {target.name} was caught and took {damage} damage!"

                if target.health <= 0:
                    target.is_alive = False
                    player.kills += 1
                    self.killed_this_round.append(target)
                    result_text += f" {target.name} was killed by the trap!"

        elif action_type == "attack" or action_type == "ambush":
            target = action_data.get("target")
            if isinstance(target, Player) and target.is_alive:
                # Instead of awaiting here, we'll return a special result that
                # the calling function can handle
                result_text += f" Attacks {target.name}."
                return result_text, {"combat": True, "attacker": player, "target": target, "attack_type": action_type}

        elif action_type == "cornucopia":
            if self.cornucopia_active:
                # Higher risk, higher reward
                if randomm.randint(1, 100) <= 40:  # 40% chance of injury
                    damage = randomm.randint(10, 25)
                    player.health -= damage
                    result_text += f" Was injured at the Cornucopia, taking {damage} damage."

                    if player.health <= 0:
                        player.is_alive = False
                        self.killed_this_round.append(player)
                        result_text += f" {player.name} died at the Cornucopia!"
                        return result_text, None

                # Get rewards
                num_items = randomm.randint(1, 3)
                for _ in range(num_items):
                    if randomm.random() < 0.6:  # 60% chance for an item
                        item = randomm.choice(list(self.items.keys()))
                        player.add_item(item)
                        result_text += f" Found a {item}."
                    else:  # 40% chance for a weapon
                        weapon = randomm.choice(list(self.weapons.keys()))
                        player.add_weapon(weapon)
                        result_text += f" Found a {weapon}."

                # Encounters at Cornucopia
                nearby_players = [
                    p for p in self.players
                    if p.is_alive and p != player and p.current_area == "Cornucopia"
                ]

                if nearby_players and randomm.random() < 0.4:  # 40% chance
                    opponent = randomm.choice(nearby_players)
                    result_text += f" Encountered {opponent.name} at the Cornucopia!"

                    # Chance for immediate combat
                    if randomm.random() < 0.6:  # 60% chance
                        attacker = player if randomm.random() < 0.5 else opponent
                        target = opponent if attacker == player else player
                        return result_text, {"combat": True, "attacker": attacker, "target": target, "attack_type": "normal"}
            else:
                result_text += " Found the Cornucopia empty."

                # Small chance of finding leftover supplies
                if randomm.random() < 0.2:  # 20% chance
                    if randomm.random() < 0.7:  # 70% chance for item
                        item = randomm.choice(list(self.items.keys()))
                        player.add_item(item)
                        result_text += f" Found a forgotten {item}."
                    else:  # 30% chance for weapon
                        weapon = randomm.choice(list(self.weapons.keys()))
                        player.add_weapon(weapon)
                        result_text += f" Found a forgotten {weapon}."

        elif action_type == "suicide" or action_type == "surrender":
            player.health = 0
            player.is_alive = False
            self.killed_this_round.append(player)
            result_text += f" {player.name} has eliminated themselves from the games."

        elif action_type == "move":
            destination = action_data.get("destination", randomm.choice(self.map_areas))
            old_area = player.current_area
            player.current_area = destination
            result_text += f" Moved from {old_area} to {destination}."

            # Check for hazards in the new area
            for hazard, location in self.hazards:
                if location == destination:
                    damage = randomm.randint(10, 25)
                    player.health -= damage
                    result_text += f" Encountered {hazard} and took {damage} damage!"

                    if hazard == "Toxic Gas":
                        player.add_status_effect("poisoned", randomm.randint(2, 3))
                        result_text += " Was poisoned by the gas!"

                    if player.health <= 0:
                        player.is_alive = False
                        self.killed_this_round.append(player)
                        result_text += f" {player.name} died from the {hazard}!"
                        return result_text, None

            # Check for traps in the new area
            for trap_type, location, owner in self.traps:
                if location == destination and owner != player and randomm.random() < 0.4:  # 40% chance
                    damage = randomm.randint(15, 30)
                    player.health -= damage
                    result_text += f" Triggered a {trap_type} and took {damage} damage!"

                    if "poison" in trap_type:
                        player.add_status_effect("poisoned", randomm.randint(2, 4))
                        result_text += " Was poisoned by the trap!"

                    if player.health <= 0:
                        player.is_alive = False
                        self.killed_this_round.append(player)
                        owner.kills += 1
                        result_text += f" {player.name} was killed by {owner.name}'s trap!"
                        return result_text, None

            # Check for supply drops in the new area
            if destination in self.supply_drops:
                result_text += " Found a supply drop!"

                # Get items from the supply drop
                num_items = randomm.randint(1, 2)
                for _ in range(num_items):
                    if randomm.random() < 0.7:  # 70% chance for item
                        item = randomm.choice(list(self.items.keys()))
                        player.add_item(item)
                        result_text += f" Found a {item}."
                    else:  # 30% chance for weapon
                        weapon = randomm.choice(list(self.weapons.keys()))
                        player.add_weapon(weapon)
                        result_text += f" Found a {weapon}."

                # Remove this supply drop
                self.supply_drops.remove(destination)

        elif action_type == "hide":
            # Hiding increases defense but reduces ability to gather resources
            player.add_status_effect("hidden", 1)  # Lasts 1 round
            player.defense_bonus += 15  # Temporary defense bonus

            # Hiding effectiveness depends on area and items
            effectiveness = "poorly"
            if player.current_area in ["Forest", "Cave"] or "Camouflage Paint" in player.items:
                effectiveness = "effectively"
                player.defense_bonus += 10  # Additional bonus
                if "Camouflage Paint" in player.items:
                    player.items.remove("Camouflage Paint")

            result_text += f" Hid {effectiveness} in the {player.current_area}."

            # Small chance to find items while hiding
            if randomm.random() < 0.2:  # 20% chance
                if player.current_area == "Forest":
                    player.food += randomm.randint(5, 15)
                    result_text += " Found some berries while hiding."
                elif player.current_area == "Cave":
                    if randomm.random() < 0.5:
                        player.add_item("Stone")
                        result_text += " Found a useful stone while hiding."

        elif action_type == "fortify":
            player.defense_bonus += randomm.randint(10, 20)
            result_text += f" Built defenses in the {player.current_area}, improving protection."

            # Chance to create actual structures based on area
            if player.current_area == "Forest" and "Rope" in player.items:
                result_text += " Built a tree platform for safer sleeping."
                player.items.remove("Rope")
            elif player.current_area == "Cave":
                result_text += " Blocked the cave entrance with rocks for better security."
            elif player.current_area == "Beach" and "Rope" in player.items:
                result_text += " Built a simple shelter against the elements."
                player.items.remove("Rope")

            # Being in a fortified position makes it harder for others to attack
            if randomm.random() < 0.3 and "Spikes" in player.items:
                self.traps.append(("defensive spikes", player.current_area, player))
                player.items.remove("Spikes")
                result_text += " Set up defensive spikes around the perimeter."

        return result_text, None

    async def process_team_action(self, team, action_text, action_data):
        """Process a team action with team targeting and enhanced consequences"""
        result_text = action_text
        alive_members = team.get_alive_players()

        if not alive_members:
            return result_text

        action_type = action_data.get("type", "")
        target_team = action_data.get("target_team")

        # Get alive players in this team
        alive_players = team.get_alive_players()
        if not alive_players:
            return result_text

        # Team heal action with improved mechanics
        if action_type == "heal":
            health_gain = action_data.get("health", 15)

            # Check for medical items that can be shared
            medical_items = []
            for player in alive_players:
                for item in player.items:
                    if item in ["First Aid Kit", "Bandages", "Antidote"]:
                        medical_items.append((player, item))

            # Apply healing to each player
            healed_players = []
            for player in alive_players:
                # Base healing
                actual_gain = health_gain

                # Boost healing if medical items are available
                if medical_items:
                    owner, item = medical_items.pop(0)
                    if item == "First Aid Kit":
                        actual_gain = int(actual_gain * 1.5)  # 50% bonus
                        owner.items.remove(item)
                        healed_players.append(f"{player.name} (+{actual_gain} health, used First Aid Kit)")
                    elif item == "Bandages":
                        actual_gain = int(actual_gain * 1.2)  # 20% bonus
                        owner.items.remove(item)
                        healed_players.append(f"{player.name} (+{actual_gain} health, used Bandages)")
                else:
                    healed_players.append(f"{player.name} (+{actual_gain} health)")

                player.health = min(100, player.health + actual_gain)

                # Cure status effects if antidote is available
                if "poisoned" in [effect for effect, _ in player.status_effects]:
                    for owner, item in medical_items:
                        if item == "Antidote":
                            new_status = [(e, d) for e, d in player.status_effects if e != "poisoned"]
                            player.status_effects = new_status
                            owner.items.remove(item)
                            healed_players[-1] += ", cured poisoning with Antidote"
                            break

            result_text += "\n" + "\n".join(healed_players)

        # Team resource gathering with improved mechanics
        elif action_type == "gather" or action_type == "hunt":
            food_gain = action_data.get("food", 0)
            water_gain = action_data.get("water", 0)

            # Environmental bonuses
            if alive_players[0].current_area == "Forest":
                food_gain = int(food_gain * 1.2)  # 20% bonus in forest
            elif alive_players[0].current_area == "Lake":
                water_gain = int(water_gain * 1.5)  # 50% bonus at lake

            # Weather effects
            if self.weather == "Heavy Rain":
                water_gain = int(water_gain * 1.3)  # 30% bonus in rain
            elif self.weather == "Extreme Heat":
                water_gain = int(water_gain * 0.7)  # 30% penalty in heat

            # Team coordination bonus
            num_players = len(alive_players)
            efficiency = 1.0 + (num_players * 0.1)  # 10% bonus per player
            food_gain = int(food_gain * efficiency)
            water_gain = int(water_gain * efficiency)

            # Apply specialized tools if available
            has_fishing_rod = any("Fishing Rod" in p.items for p in alive_players)
            has_bow = any("Bow" in p.weapons for p in alive_players)

            if action_type == "hunt" and has_bow:
                food_gain = int(food_gain * 1.5)  # 50% bonus with bow for hunting
                result_text += " Using their bow improved hunting results."

            if alive_players[0].current_area == "Lake" and has_fishing_rod:
                food_gain += randomm.randint(15, 30)  # Extra food from fishing
                result_text += " Fishing was particularly successful."

            # Distribute resources among team members
            for player in alive_players:
                if food_gain:
                    player.food = min(100, player.food + food_gain)
                if water_gain:
                    player.water = min(100, player.water + water_gain)

            if food_gain:
                result_text += f" The team gathered {food_gain} food per person."
            if water_gain:
                result_text += f" The team found {water_gain} water per person."

            # Special find chance
            if randomm.random() < 0.3:  # 30% chance
                special_item = randomm.choice(list(self.items.keys()))
                lucky_player = randomm.choice(alive_players)
                lucky_player.add_item(special_item)
                result_text += f" {lucky_player.name} found a {special_item} during the expedition."

        # Team training/bonding with improved mechanics
        elif action_type == "train" or action_type == "bond":
            # Apply abstract bonuses to all team members
            bonus_type = "combat" if action_type == "train" else "morale"

            if action_type == "train":
                # Training improves combat ability
                combat_bonus = randomm.randint(5, 10)
                for player in alive_players:
                    player.combat_bonus += combat_bonus

                result_text += f" Everyone gained +{combat_bonus} combat skill."

                # Training sometimes yields weapons
                if randomm.random() < 0.3:  # 30% chance
                    for player in alive_players:
                        if not player.weapons:
                            player.add_weapon("Improvised Weapon")
                    result_text += " Everyone created improvised weapons."

                # Knowledge sharing
                if randomm.random() < 0.5:  # 50% chance
                    num_tactics = randomm.randint(1, 3)
                    tactics = [
                        "ambush techniques", "defensive formations",
                        "trap detection", "wilderness survival",
                        "tracking skills", "stealth movement"
                    ]
                    learned = randomm.sample(tactics, min(num_tactics, len(tactics)))
                    result_text += f" The team learned {nice_join(learned)}."

            else:  # Bonding
                # Sometimes bonding leads to sharing items
                if randomm.random() < 0.4:  # 40% chance
                    result_text += " The team shared their supplies evenly."

                    # Pool all food and water
                    total_food = sum(p.food for p in alive_players)
                    total_water = sum(p.water for p in alive_players)

                    # Distribute evenly
                    avg_food = total_food // len(alive_players)
                    avg_water = total_water // len(alive_players)

                    for player in alive_players:
                        player.food = avg_food
                        player.water = avg_water

                # Improved morale can lead to health recovery
                health_boost = randomm.randint(5, 10)
                for player in alive_players:
                    player.health = min(100, player.health + health_boost)

                result_text += f" Improved morale restored {health_boost} health to everyone."

        # Team killing action with improved mechanics
        elif action_type == "kill":
            target = action_data.get("target")
            if isinstance(target, Player) and target.is_alive:
                # Create a special team attack embed
                embed = discord.Embed(
                    title="Team Assault",
                    description=f"Team {team.team_id + 1} launches a coordinated attack against {target.name}!",
                    color=discord.Color.dark_red()
                )

                # Calculate combined team attack power
                team_power = 0
                attackers_str = []
                for player in alive_players:
                    player_power = 5  # Base power
                    for weapon in player.weapons:
                        player_power += self.weapons.get(weapon, 5)
                    team_power += player_power
                    attackers_str.append(f"{player.name} ({player_power} power)")

                embed.add_field(
                    name="Attacking Force",
                    value="\n".join(attackers_str),
                    inline=False
                )

                # Target defense calculation
                defense_power = 5  # Base defense

                # Defensive items
                for item in target.items:
                    if item == "Shield":
                        defense_power += 15
                    elif item == "Armor":
                        defense_power += 20
                    elif item == "Helmet":
                        defense_power += 10
                    elif item == "Camouflage Paint":
                        defense_power += 5

                # Add target's personal defense bonus
                defense_power += target.defense_bonus

                embed.add_field(
                    name=f"{target.name}'s Defense",
                    value=f"Defense Power: {defense_power}",
                    inline=True
                )

                # Teams are much more effective than individuals
                advantage = team_power - defense_power
                base_chance = 60 + min(advantage, 30)  # Cap the advantage

                # Roll for success
                success_roll = randomm.randint(1, 100)
                success = success_roll <= base_chance

                embed.add_field(
                    name="Attack Roll",
                    value=f"Needed: {base_chance} or less\nRolled: {success_roll}\nResult: {'SUCCESS' if success else 'FAILURE'}",
                    inline=False
                )

                if success:
                    # Team attack succeeds
                    damage = randomm.randint(30, 50) + (team_power // 4)

                    # Reduce damage based on defense
                    damage_reduction = defense_power // 3
                    damage = max(10, damage - damage_reduction)

                    target.health -= damage

                    embed.add_field(
                        name="Attack Damage",
                        value=f"{damage} damage dealt to {target.name}!",
                        inline=False
                    )

                    if target.health <= 0:
                        target.health = 0
                        target.is_alive = False
                        self.killed_this_round.append(target)

                        # Award kill to a random team member
                        killer = randomm.choice(alive_players)
                        killer.kills += 1

                        embed.add_field(
                            name="FATALITY",
                            value=f"{target.name} has been eliminated by Team {team.team_id + 1}!",
                            inline=False
                        )
                        embed.color = discord.Color.dark_red()

                        result_text += f" They successfully eliminated {target.name}!"
                    else:
                        # Add a status effect for severe wounds
                        if randomm.random() < 0.5:  # 50% chance
                            target.add_status_effect("bleeding", randomm.randint(2, 3))
                            embed.add_field(
                                name="Bleeding Wound",
                                value=f"{target.name} is now bleeding from their wounds!",
                                inline=False
                            )

                        embed.add_field(
                            name="Target Status",
                            value=f"{target.name} survives with {target.health} health remaining.",
                            inline=False
                        )
                        result_text += f" They wounded {target.name} severely but didn't kill them."
                else:
                    # Attack fails
                    embed.add_field(
                        name="Attack Failed",
                        value=f"Team {team.team_id + 1} failed to eliminate {target.name}.",
                        inline=False
                    )

                    # Counterattack chance
                    if randomm.random() < 0.3:  # 30% chance
                        counter_target = randomm.choice(alive_players)
                        counter_damage = randomm.randint(10, 20)
                        counter_target.health -= counter_damage

                        embed.add_field(
                            name="Counterattack!",
                            value=f"{target.name} fights back and deals {counter_damage} damage to {counter_target.name}!",
                            inline=False
                        )

                        if counter_target.health <= 0:
                            counter_target.is_alive = False
                            self.killed_this_round.append(counter_target)
                            target.kills += 1

                            embed.add_field(
                                name="Counter Kill!",
                                value=f"{counter_target.name} was killed by {target.name}'s counterattack!",
                                inline=False
                            )

                    result_text += f" They attempted to eliminate {target.name} but failed."

                await self.ctx.send(embed=embed)

        # Team accident with improved mechanics
        elif action_type == "accident":
            damage = action_data.get("damage", 20)

            # Different accident types
            accident_type = randomm.choice([
                "trap malfunction", "food poisoning", "falling rocks",
                "wild animal attack", "flash flood", "quicksand"
            ])

            # Accident severity varies by location and weather
            severity = 1.0
            if alive_players[0].current_area == "Mountain":
                severity = 1.3  # 30% worse in mountains
            elif alive_players[0].current_area == "Forest" and self.weather == "Heavy Rain":
                severity = 1.4  # 40% worse in forests during rain

            damage = int(damage * severity)

            # Apply damage to each team member
            casualties = []
            injured = []

            for player in alive_players:
                # Some players might avoid the accident
                if randomm.random() < 0.2:  # 20% chance to avoid
                    continue

                # Apply damage
                actual_damage = max(5, randomm.randint(damage - 10, damage + 10))
                player.health -= actual_damage

                if player.health <= 0:
                    player.is_alive = False
                    self.killed_this_round.append(player)
                    casualties.append(player.name)
                else:
                    injured.append(f"{player.name} (-{actual_damage} health)")

            if casualties:
                result_text += f" {nice_join(casualties)} {'were' if len(casualties) > 1 else 'was'} killed in the {accident_type}."

            if injured:
                result_text += f" {nice_join(injured)} {'were' if len(injured) > 1 else 'was'} injured in the {accident_type}."

            if not casualties and not injured:
                result_text += f" Everyone managed to avoid the {accident_type}."

        # Team betrayal with improved mechanics
        elif action_type == "betrayal" and target_team:
            if target_team in team.alliances:
                embed = discord.Embed(
                    title="Alliance Betrayal!",
                    description=f"Team {team.team_id + 1} betrays their alliance with Team {target_team.team_id + 1}!",
                    color=discord.Color.red()
                )

                team.break_alliance(target_team)
                result_text += f" betrays Team {target_team.team_id+1}!"

                # Calculate attack advantage
                surprise_modifier = randomm.randint(10, 30)

                # Victims might be caught off guard
                victims = target_team.get_alive_players()
                if not victims:
                    result_text += " But there was no one left to betray!"
                    embed.add_field(name="Failed Betrayal", value="There were no survivors to betray.", inline=False)
                else:
                    # Choose a random victim
                    victim = randomm.choice(victims)

                    # Calculate damage
                    damage = randomm.randint(20, 40) + surprise_modifier
                    victim.health -= damage

                    embed.add_field(
                        name="Surprise Attack",
                        value=f"{victim.name} takes {damage} damage from the unexpected betrayal!",
                        inline=False
                    )

                    result_text += f" Attacked {victim.name} for {damage} damage!"

                    # Check for kill
                    if victim.health <= 0:
                        victim.is_alive = False
                        self.killed_this_round.append(victim)

                        # Award kill to a random attacker
                        killer = randomm.choice(team.get_alive_players())
                        killer.kills += 1

                        embed.add_field(
                            name="Betrayal Kill",
                            value=f"{victim.name} was killed by the betrayal!",
                            inline=False
                        )

                        result_text += f" Killed {victim.name} in the betrayal!"

                await self.ctx.send(embed=embed)
            else:
                result_text += " Can't betray a non-ally!"

        # Team attack with improved mechanics
        elif action_type == "attack" and target_team:
            if target_team.team_id == team.team_id:
                return result_text + " Can't attack themselves!"

            # Create a team battle embed
            embed = discord.Embed(
                title="Team Battle",
                description=f"Team {team.team_id + 1} attacks Team {target_team.team_id + 1}!",
                color=discord.Color.dark_red()
            )

            # Calculate team strengths with detailed factors
            attacking_team = []
            for player in alive_members:
                player_power = 5  # Base power
                for weapon in player.weapons:
                    player_power += self.weapons.get(weapon, 5)
                # Add player's combat bonus
                player_power += player.combat_bonus
                attacking_team.append((player, player_power))

            defending_team = []
            for player in target_team.get_alive_players():
                player_power = 5  # Base defense
                for item in player.items:
                    if item == "Shield":
                        player_power += 15
                    elif item == "Armor":
                        player_power += 20
                    elif item == "Helmet":
                        player_power += 10
                # Add player's defense bonus
                player_power += player.defense_bonus
                defending_team.append((player, player_power))

            if not defending_team:
                result_text += " No one left to attack on that team!"
                embed.add_field(name="No Target", value="There are no living members in the target team.", inline=False)
                await self.ctx.send(embed=embed)
                return result_text

            # Display team compositions
            attackers_str = []
            for player, power in attacking_team:
                attackers_str.append(f"{player.name} (Power: {power})")

            defenders_str = []
            for player, power in defending_team:
                defenders_str.append(f"{player.name} (Defense: {power})")

            embed.add_field(name="Attacking Force", value="\n".join(attackers_str), inline=True)
            embed.add_field(name="Defending Force", value="\n".join(defenders_str), inline=True)

            # Calculate total powers
            attacker_power = sum(power for _, power in attacking_team)
            defender_power = sum(power for _, power in defending_team)

            # Environmental factors
            area = alive_members[0].current_area
            if area == "Forest" and self.is_night:
                attacker_power = int(attacker_power * 0.8)  # 20% penalty in forest at night
                embed.add_field(name="Night Forest Penalty", value="-20% attack power", inline=True)
            elif area == "Mountain":
                attacker_power = int(attacker_power * 1.2)  # 20% bonus in mountains (high ground)
                embed.add_field(name="High Ground Bonus", value="+20% attack power", inline=True)

            # Weather effects
            if self.weather == "Heavy Rain" and any("Bow" in p.weapons for p, _ in attacking_team):
                attacker_power = int(attacker_power * 0.8)  # 20% penalty to bows in rain
                embed.add_field(name="Rain Penalty", value="-20% to ranged weapons", inline=True)
            elif self.weather == "Strong Winds":
                attacker_power = int(attacker_power * 0.9)  # 10% general penalty in wind
                embed.add_field(name="Wind Penalty", value="-10% to attack power", inline=True)

            # Base success chance with power difference
            success_chance = 50 + ((attacker_power - defender_power) // 2)
            success_chance = max(30, min(70, success_chance))  # Bound between 30% and 70%

            # Roll for success
            success_roll = randomm.randint(1, 100)
            success = success_roll <= success_chance

            embed.add_field(
                name="Battle Roll",
                value=f"Attack Power: {attacker_power}\nDefense Power: {defender_power}\nSuccess Chance: {success_chance}%\nRolled: {success_roll}",
                inline=False
            )

            if success:
                # Attack succeeds - calculate casualties
                casualties = []
                wounded = []

                # Calculate base damage per defender
                base_damage = randomm.randint(15, 25) + (attacker_power // len(defending_team))

                for defender, defense in defending_team:
                    # Reduce damage based on defense
                    damage_reduction = defense // 3
                    damage = max(10, base_damage - damage_reduction)

                    # Apply damage
                    defender.health -= damage

                    if defender.health <= 0:
                        defender.health = 0
                        defender.is_alive = False
                        casualties.append(defender.name)
                        self.killed_this_round.append(defender)

                        # Award kill to random attacker
                        killer = randomm.choice([p for p, _ in attacking_team])
                        killer.kills += 1
                    else:
                        wounded.append(f"{defender.name} (-{damage} health, {defender.health} remaining)")

                # Attack results
                if casualties:
                    embed.add_field(
                        name="Casualties",
                        value=f"Team {team.team_id + 1} killed: {nice_join(casualties)}",
                        inline=False
                    )
                    result_text += f" killed {nice_join(casualties)}!"

                if wounded:
                    embed.add_field(
                        name="Wounded",
                        value="\n".join(wounded),
                        inline=False
                    )
                    if not casualties:
                        result_text += f" wounded several members of Team {target_team.team_id + 1}."

                # Attacker injuries (reduced)
                if randomm.random() < 0.3:  # 30% chance of attacker injuries
                    for attacker, _ in attacking_team:
                        if randomm.random() < 0.3:  # 30% chance per attacker
                            damage = randomm.randint(5, 15)
                            attacker.health -= damage
                            embed.add_field(
                                name="Attacker Injury",
                                value=f"{attacker.name} took {damage} damage during the attack.",
                                inline=True
                            )
            else:
                # Attack fails
                embed.add_field(
                    name="Attack Repelled",
                    value=f"Team {target_team.team_id + 1} successfully defends against the attack!",
                    inline=False
                )

                result_text += " fails their attack!"

                # Counterattack
                if randomm.random() < 0.4:  # 40% chance
                    counter_damage = randomm.randint(10, 20)
                    counter_target = randomm.choice([p for p, _ in attacking_team])
                    counter_target.health -= counter_damage

                    embed.add_field(
                        name="Counterattack",
                        value=f"{randomm.choice(defenders_str).split(' ')[0]} counterattacks and deals {counter_damage} damage to {counter_target.name}!",
                        inline=False
                    )

                    if counter_target.health <= 0:
                        counter_target.health = 0
                        counter_target.is_alive = False
                        self.killed_this_round.append(counter_target)

                        # Award kill to random defender
                        killer = randomm.choice([p for p, _ in defending_team])
                        killer.kills += 1

                        embed.add_field(
                            name="Counterattack Kill",
                            value=f"{counter_target.name} was killed in the counterattack!",
                            inline=False
                        )

                        result_text += f" {counter_target.name} was killed in a counterattack!"

            await self.ctx.send(embed=embed)

        # Team alliance with improved mechanics
        elif action_type == "alliance" and target_team:
            if target_team in team.alliances:
                result_text += " Already allied with this team!"
            else:
                team.form_alliance(target_team)

                embed = discord.Embed(
                    title="New Alliance Formed",
                    description=f"Team {team.team_id+1} and Team {target_team.team_id+1} have formed an alliance!",
                    color=discord.Color.green()
                )

                # Show the allied teams
                team1_members = [p.name for p in team.get_alive_players()]
                team2_members = [p.name for p in target_team.get_alive_players()]

                embed.add_field(
                    name=f"Team {team.team_id+1}",
                    value=nice_join(team1_members) or "No living members",
                    inline=True
                )

                embed.add_field(
                    name=f"Team {target_team.team_id+1}",
                    value=nice_join(team2_members) or "No living members",
                    inline=True
                )

                # Alliance benefits
                benefits = [
                    "Can coordinate attacks",
                    "Will not target each other",
                    "May share resources",
                    "Improved survival chances"
                ]

                embed.add_field(
                    name="Alliance Benefits",
                    value="\n".join(f"• {b}" for b in benefits),
                    inline=False
                )

                embed.set_footer(text="But remember, only one team can win the Hunger Games...")

                await self.ctx.send(embed=embed)
                result_text += f" forms alliance with Team {target_team.team_id+1}!"

                # Alliance celebration - share resources
                if randomm.random() < 0.5:  # 50% chance
                    # Find a player with items to share
                    for player in alive_players:
                        if player.items:
                            shared_item = player.items.pop(0)
                            target_player = randomm.choice(target_team.get_alive_players())
                            target_player.add_item(shared_item)
                            result_text += f" {player.name} shares a {shared_item} with {target_player.name} as a sign of goodwill."
                            break

        # Team move action
        elif action_type == "move":
            # Choose a new area that's different from current
            current_area = alive_players[0].current_area
            possible_areas = [area for area in self.map_areas if area != current_area]
            destination = randomm.choice(possible_areas)

            # Move all team members
            for player in alive_players:
                player.current_area = destination

            result_text += f" Team moves to the {destination}."

            # Check for hazards in the new area
            for hazard, location in self.hazards:
                if location == destination:
                    # Calculate hazard impact
                    casualties = []
                    injured = []

                    for player in alive_players:
                        # Some players might avoid the hazard
                        if randomm.random() < 0.3:  # 30% chance to avoid
                            continue

                        damage = randomm.randint(10, 25)
                        player.health -= damage

                        if hazard == "Toxic Gas":
                            player.add_status_effect("poisoned", randomm.randint(2, 3))

                        if player.health <= 0:
                            player.is_alive = False
                            self.killed_this_round.append(player)
                            casualties.append(player.name)
                        else:
                            injured.append(f"{player.name} (-{damage} health)")

                    if casualties:
                        result_text += f" {nice_join(casualties)} {'were' if len(casualties) > 1 else 'was'} killed by the {hazard}."

                    if injured:
                        result_text += f" {nice_join(injured)} {'were' if len(injured) > 1 else 'was'} injured by the {hazard}."

                    if not casualties and not injured:
                        result_text += f" The team avoided the {hazard}."

            # Check for supply drops in the new area
            if destination in self.supply_drops:
                result_text += " The team finds a supply drop!"

                # Distribute items among team members
                for player in alive_players:
                    if randomm.random() < 0.7:  # 70% chance for item
                        item = randomm.choice(list(self.items.keys()))
                        player.add_item(item)
                        result_text += f" {player.name} found a {item}."
                    else:  # 30% chance for weapon
                        weapon = randomm.choice(list(self.weapons.keys()))
                        player.add_weapon(weapon)
                        result_text += f" {player.name} found a {weapon}."

                # Remove this supply drop
                self.supply_drops.remove(destination)

        # Team defend/fortify
        elif action_type == "defend" or action_type == "fortify":
            defense_bonus = action_data.get("defense_bonus", 10)

            # Apply defense bonus to all team members
            for player in alive_players:
                player.defense_bonus += defense_bonus

            result_text += f" Team builds defenses at {alive_players[0].current_area}, gaining +{defense_bonus} defense."

            # Additional fortification effects based on area
            area = alive_players[0].current_area
            if area == "Forest":
                result_text += " They build elevated platforms in the trees."
            elif area == "Cave":
                result_text += " They barricade the cave entrance."
            elif area == "Mountain":
                result_text += " They establish a high vantage point."
            elif area == "Lake":
                result_text += " They build a small raft for mobility."

            # Set up team traps for additional defense
            has_traps = False
            for player in alive_players:
                if "Rope" in player.items or "Spikes" in player.items:
                    has_traps = True
                    if "Rope" in player.items:
                        player.items.remove("Rope")
                    if "Spikes" in player.items:
                        player.items.remove("Spikes")
                    break

            if has_traps:
                trap_type = randomm.choice(["defensive perimeter", "alarm system", "spike trap", "pitfall"])
                self.traps.append((trap_type, area, alive_players[0]))
                result_text += f" They set up a {trap_type} to protect their position."

        return result_text

    async def handle_game_master_turn(self):
        """Let the game master influence the game"""
        if not self.game_master:
            return None

        embed = discord.Embed(
            title="Game Master Turn",
            description=f"{self.game_master.name}, you may influence the Hunger Games.",
            color=discord.Color.purple()
        )

        if self.game_master.influence_points <= 0:
            embed.add_field(
                name="No Influence Remaining",
                value="You have used all your Game Master influence points."
            )
            return embed

        embed.add_field(
            name="Available Actions",
            value=f"You have {self.game_master.influence_points} influence points remaining."
        )

        await self.ctx.send(embed=embed)

        # Let the GM choose an event
        event_result = await self.game_master.choose_event(self.ctx, self)
        return event_result

    async def handle_special_events(self):
        """Create random arena events that affect all players"""
        # Only trigger special events occasionally
        if randomm.random() > 0.2:  # 20% chance per round
            return None

        possible_events = [
            ("Game Maker Fireball", "A series of fireballs rain down from the sky!", "damage"),
            ("Freezing Weather", "The temperature drops dramatically overnight.", "cold"),
            ("Fog of Death", "A toxic fog slowly creeps through the arena.", "poison"),
            ("Feast at Cornucopia", "A feast has been laid out at the Cornucopia with supplies for all!", "feast"),
            ("Flash Flood", "Water rapidly rises in the lower parts of the arena.", "flood"),
            ("Muttation Attack", "Genetically modified creatures hunt the tributes.", "mutts"),
            ("Forest Fire", "A section of the forest has been set ablaze.", "fire"),
            ("Supply Drop", "Parachutes with supplies descend into the arena.", "supplies"),
            ("Arena Shift", "The arena's geography changes, forcing tributes to move.", "shift"),
            ("Tracker Jacker Nest", "Nests of deadly wasps have been placed around the arena.", "wasps")
        ]

        event = randomm.choice(possible_events)
        event_name, event_desc, event_type = event

        embed = discord.Embed(
            title=f"Special Event: {event_name}",
            description=event_desc,
            color=discord.Color.red()
        )

        # Apply event effects to players
        if event_type == "damage":
            # Random damage to random players
            affected = []
            for player in [p for p in self.players if p.is_alive]:
                if randomm.random() < 0.3:  # 30% chance to be hit
                    damage = randomm.randint(10, 30)
                    player.health -= damage
                    affected.append(f"{player.name} (-{damage} health)")

                    if player.health <= 0:
                        player.is_alive = False
                        self.killed_this_round.append(player)
                        affected[-1] += " [KILLED]"

            if affected:
                embed.add_field(name="Affected Tributes", value="\n".join(affected))
            else:
                embed.add_field(name="Results", value="Everyone managed to find shelter in time.")

        elif event_type == "cold":
            # Cold weather affects those without shelter
            affected = []
            for player in [p for p in self.players if p.is_alive]:
                has_shelter = "Sleeping Bag" in player.items
                if not has_shelter:
                    damage = randomm.randint(5, 15)
                    player.health -= damage
                    affected.append(f"{player.name} (-{damage} health)")

                    if player.health <= 0:
                        player.is_alive = False
                        self.killed_this_round.append(player)
                        affected[-1] += " [KILLED]"
                else:
                    affected.append(f"{player.name} (protected by shelter)")

            embed.add_field(name="Affected Tributes", value="\n".join(affected))
            self.weather = "Freezing Cold"

        elif event_type == "feast":
            # Cornucopia feast - can lead to conflicts
            self.cornucopia_active = True
            embed.add_field(
                name="Announcement",
                value="All tributes are invited to a feast at the Cornucopia. Weapons, food, medicine, and other supplies await those brave enough to claim them."
            )

        elif event_type == "supplies":
            # Random supply drops for some players
            recipients = []
            for player in [p for p in self.players if p.is_alive]:
                if randomm.random() < 0.4:  # 40% chance to get supplies
                    if randomm.random() < 0.7:  # 70% item, 30% weapon
                        item = randomm.choice(list(self.items.keys()))
                        player.add_item(item)
                        recipients.append(f"{player.name} received {item}")
                    else:
                        weapon = randomm.choice(list(self.weapons.keys()))
                        player.add_weapon(weapon)
                        recipients.append(f"{player.name} received {weapon}")

            if recipients:
                embed.add_field(name="Supply Recipients", value="\n".join(recipients))
            else:
                embed.add_field(name="Results", value="The supplies were taken by unknown forces.")

            # Add supply drops to random areas
            drop_areas = randomm.sample(self.map_areas, 3)
            self.supply_drops.extend(drop_areas)
            embed.add_field(
                name="Supply Locations",
                value=f"Supplies have been dropped at: {', '.join(drop_areas)}"
            )

        elif event_type == "flood":
            # Flooding in low-lying areas
            affected_areas = ["Lake", "Beach", "Plains"]
            affected_players = []

            for player in [p for p in self.players if p.is_alive and p.current_area in affected_areas]:
                damage = randomm.randint(5, 20)
                player.health -= damage
                affected_players.append(f"{player.name} (-{damage} health)")

                # Chance to lose items due to water damage
                if player.items and randomm.random() < 0.3:
                    lost_item = randomm.choice(player.items)
                    player.items.remove(lost_item)
                    affected_players[-1] += f", lost {lost_item} to water damage"

                if player.health <= 0:
                    player.is_alive = False
                    self.killed_this_round.append(player)
                    affected_players[-1] += " [DROWNED]"

            if affected_players:
                embed.add_field(name="Flood Victims", value="\n".join(affected_players))
            else:
                embed.add_field(name="Results", value="All tributes were in safe areas during the flood.")

            self.weather = "Heavy Rain"

        elif event_type == "fire":
            # Forest fire
            fire_area = "Forest"
            affected_players = []

            for player in [p for p in self.players if p.is_alive and p.current_area == fire_area]:
                # Check if player can escape
                escape_chance = 70  # 70% base chance
                if player.items and "Map" in player.items:
                    escape_chance += 20  # Maps help find escape routes

                if randomm.randint(1, 100) <= escape_chance:
                    # Player escapes to random new area
                    new_area = randomm.choice([a for a in self.map_areas if a != fire_area])
                    player.current_area = new_area
                    affected_players.append(f"{player.name} escaped to {new_area}")
                else:
                    # Player is caught in the fire
                    damage = randomm.randint(20, 40)
                    player.health -= damage
                    affected_players.append(f"{player.name} (-{damage} health from burns)")

                    if player.health <= 0:
                        player.is_alive = False
                        self.killed_this_round.append(player)
                        affected_players[-1] += " [BURNED]"

            if affected_players:
                embed.add_field(name="Forest Fire Victims", value="\n".join(affected_players))
            else:
                embed.add_field(name="Results", value="No tributes were in the forest during the fire.")

            # Add fire hazard
            self.hazards.append(("Forest Fire", "Forest"))

        else:
            # Generic effect for other event types
            affected = []
            for player in [p for p in self.players if p.is_alive]:
                if randomm.random() < 0.3:  # 30% chance to be affected
                    damage = randomm.randint(5, 15)
                    player.health -= damage
                    affected.append(f"{player.name} (-{damage} health)")

                    if player.health <= 0:
                        player.is_alive = False
                        self.killed_this_round.append(player)
                        affected[-1] += " [KILLED]"

            if affected:
                embed.add_field(name="Affected Tributes", value="\n".join(affected))
            else:
                embed.add_field(name="Results", value="Everyone managed to avoid the danger.")

        return embed

    async def get_inputs(self):
        """Get and process player actions for a round."""
        self.killed_this_round = []

        manual_round = self.force_choice or (self.round % 2 == 0)

        # Day/night cycle progression
        self.is_night = not self.is_night
        if not self.is_night:
            self.day += 1

        special_event = await self.handle_special_events()

        time_of_day = "Night" if self.is_night else "Day"
        roundtext = f"**{time_of_day} {self.day} - Round {self.round}**"
        status = await self.ctx.send(roundtext)

        user_actions = []
        combat_results = []

        alive_players = [p for p in self.players if p.is_alive]
        teams = {}
        for player in alive_players:
            teams.setdefault(player.team_id, []).append(player)

        for team_group in teams.values():
            if len(team_group) == 1:
                # SOLO ACTION HANDLING
                player = team_group[0]
                prompt_text = f"Letting {player.mention} choose their action..."
                try:
                    await status.edit(content=f"{status.content}\n{prompt_text}")
                except discord.errors.NotFound:
                    status = await self.ctx.send(roundtext)

                actions = self.get_solo_actions()
                allowed_types_solo = {
                    "gather", "heal", "craft", "trap", "attack", "ambush", "cornucopia",
                    "shelter", "scout", "hunt", "fish", "move", "hide", "fortify"
                }
                filtered_actions = [
                    act for act in actions
                    if (not isinstance(act[1], dict)) or (act[1].get("type") in allowed_types_solo)
                ]
                possible_actions = random.sample(filtered_actions, min(5, len(filtered_actions)))
                possible_targets = [p for p in alive_players if p != player]
                target = random.choice(possible_targets) if possible_targets else None

                actions_with_targets = []
                for action_text, action_data in possible_actions:
                    if isinstance(action_data, dict) and action_data.get("target") == "USER" and target:
                        new_text = action_text.replace("USER", target.name)
                        new_data = action_data.copy()
                        new_data["target"] = target
                        actions_with_targets.append((new_text, new_data))
                    else:
                        actions_with_targets.append((action_text, action_data))

                action_descriptions = [a[0] for a in actions_with_targets]
                selected_index = 0

                if (player in self.bot_players and not self.force_choice) or not manual_round:
                    if player.health < 30 or player.food < 20 or player.water < 20:
                        for i, (_, data) in enumerate(actions_with_targets):
                            if isinstance(data, dict) and (
                                    data.get("type") in {"heal", "gather"} or
                                    data.get("health", 0) > 0 or data.get("food", 0) > 0 or data.get("water", 0) > 0
                            ):
                                selected_index = i
                                break
                    elif player.weapons and target and randomm.random() < 0.7:
                        for i, (_, data) in enumerate(actions_with_targets):
                            if isinstance(data, dict) and (data.get("type") in {"attack", "ambush"}):
                                selected_index = i
                                break
                    else:
                        selected_index = randomm.randint(0, len(actions_with_targets) - 1)
                else:
                    if player in self.bot_players:
                        selected_index = randomm.randint(0, len(actions_with_targets) - 1)
                    else:
                        try:
                            selected_index = await self.ctx.bot.paginator.Choose(
                                entries=action_descriptions,
                                return_index=True,
                                title=("Choose an action"),
                            ).paginate(self.ctx, location=player.user)
                        except (self.ctx.bot.paginator.NoChoice, discord.Forbidden, asyncio.TimeoutError):
                            await self.ctx.send(
                                ("I couldn't DM {user} or they didn't choose! Choosing a random action...").format(
                                    user=player.name),
                                delete_after=30,
                            )
                            selected_index = randomm.randint(0, len(actions_with_targets) - 1)
                        else:
                            if hasattr(player.user, "send"):
                                try:
                                    await player.user.send(f"Return to the Hunger Games: {self.ctx.message.jump_url}")
                                except Exception:
                                    pass

                selected_action = actions_with_targets[selected_index]
                action_text, action_data = selected_action

                # Use the updated process_action_effects function that returns combat info
                result_text, combat_info = await self.process_action_effects(player, action_data)
                full_text = f"{action_text}{result_text}"
                user_actions.append((player.name, full_text, player))

                # Handle combat if needed
                if combat_info and combat_info.get("combat"):
                    combat_result = await self.process_combat(
                        combat_info["attacker"],
                        combat_info["target"],
                        attack_type=combat_info["attack_type"]
                    )
                    combat_results.append(combat_result)

                try:
                    await status.edit(content=f"{status.content} - Done")
                except discord.errors.NotFound:
                    pass

            else:
                # TEAM ACTION HANDLING WITH TEAM TARGETING
                current_team = next((t for t in self.teams if t.team_id == team_group[0].team_id), None)
                possible_target_teams = [
                    t for t in self.teams
                    if t.team_id != current_team.team_id and t.is_active()
                ]

                # Add team action prompt
                team_members = [p.name for p in team_group]
                prompt_text = f"Letting Team {current_team.team_id + 1} ({', '.join(team_members)}) choose their action..."
                try:
                    await status.edit(content=f"{status.content}\n{prompt_text}")
                except discord.errors.NotFound:
                    status = await self.ctx.send(roundtext)

                team_actions = self.get_team_actions(len(team_group))
                allowed_types_team = {
                    "gather", "defend", "alliance", "raid", "trap", "scout", "train", "heal",
                    "ambush", "hunt", "plan", "attack", "betrayal", "move", "fortify"
                }
                filtered_team_actions = [
                    act for act in team_actions
                    if (not isinstance(act[1], dict)) or (act[1].get("type") in allowed_types_team)
                ]
                actions_with_targets = random.sample(filtered_team_actions, min(5, len(filtered_team_actions)))

                # Convert individual targets to team targets
                processed_actions = []
                for action_text, action_data in actions_with_targets:
                    new_data = action_data.copy() if isinstance(action_data, dict) else action_data
                    new_text = action_text

                    if isinstance(new_data, dict):
                        # Handle team targeting
                        if new_data.get("target") == "USER" and possible_target_teams:
                            target_team = random.choice(possible_target_teams)
                            new_text = action_text.replace("USER", f"Team {target_team.team_id + 1}")
                            new_data["target_team"] = target_team
                            del new_data["target"]

                        # Add acting team reference
                        new_data["acting_team"] = current_team

                    processed_actions.append((new_text, new_data))

                actions_with_targets = processed_actions

                random.shuffle(team_group)
                chooser = None
                for p in team_group:
                    if p not in self.bot_players:
                        chooser = p
                        break
                if chooser is None:
                    chooser = team_group[0]

                selected_index = 0
                if (chooser in self.bot_players and not self.force_choice) or not manual_round:
                    selected_index = randomm.randint(0, len(actions_with_targets) - 1)
                else:
                    if chooser in self.bot_players:
                        selected_index = randomm.randint(0, len(actions_with_targets) - 1)
                    else:
                        action_descriptions = [a[0] for a in actions_with_targets]
                        try:
                            selected_index = await self.ctx.bot.paginator.Choose(
                                entries=action_descriptions,
                                return_index=True,
                                title=("Choose a team action for your team"),
                            ).paginate(self.ctx, location=chooser.user)
                        except (self.ctx.bot.paginator.NoChoice, discord.Forbidden, asyncio.TimeoutError):
                            await self.ctx.send(
                                ("I couldn't DM {user} or they didn't choose! Choosing a random team action...").format(
                                    user=chooser.name),
                                delete_after=30,
                            )
                            selected_index = randomm.randint(0, len(actions_with_targets) - 1)
                        else:
                            if hasattr(chooser.user, "send"):
                                try:
                                    await chooser.user.send(f"Return to the Hunger Games: {self.ctx.message.jump_url}")
                                except Exception:
                                    pass

                selected_action = actions_with_targets[selected_index]
                action_text, action_data = selected_action
                result_text = await self.process_team_action(
                    current_team,
                    action_text,
                    action_data
                )
                user_actions.append((f"Team {current_team.team_id + 1}", result_text, current_team))

        # Status effects and final updates
        for player in self.players:
            if player.is_alive:
                if not player.update_status_effects():
                    self.killed_this_round.append(player)

        embed_color = discord.Color.dark_blue() if self.is_night else discord.Color.green()
        embed = discord.Embed(
            title=f"{time_of_day} {self.day} - Round {self.round}",
            color=embed_color
        )

        # Add thumbnail for time of day
        if self.is_night:
            embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/123456789/123456789/moon.png")
        else:
            embed.set_thumbnail(url="https://cdn.discordapp.com/attachments/123456789/123456789/sun.png")

        # Add weather condition
        embed.add_field(name="Weather", value=self.weather, inline=True)

        # Add player actions with their avatars
        for actor, action, entity in user_actions:
            # Check if it's a player or team
            if isinstance(entity, Player):
                # Add player avatar
                avatar_url = entity.get_avatar_url()
                # Gray out if dead
                if not entity.is_alive:
                    value = f"💀 {action}"
                else:
                    value = action
                embed.add_field(name=actor, value=value, inline=False)
            else:  # It's a team
                value = action
                embed.add_field(name=actor, value=value, inline=False)

        await self.ctx.send(embed=embed)

        # Send all combat results that were collected
        for combat_result in combat_results:
            await self.ctx.send(embed=combat_result)

        if special_event:
            await self.ctx.send(embed=special_event)

        if self.killed_this_round:
            killed_names = [p.name for p in self.killed_this_round]
            cannon_embed = discord.Embed(
                title="Cannon Shots",
                description=f"The following tributes have fallen:\n{nice_join(killed_names)}",
                color=discord.Color.red()
            )

            # Add a skull icon for each fallen tribute
            for player in self.killed_this_round:
                cannon_embed.add_field(
                    name=f"💀 {player.name}",
                    value=f"Kills: {player.kills}",
                    inline=True
                )

            await self.ctx.send(embed=cannon_embed)

        if self.round >= 3:
            self.cornucopia_active = False

        self.round += 1
        for player in self.killed_this_round:
            if player in self.players:
                player.is_alive = False

    async def show_player_stats(self):
        alive_players = [p for p in self.players if p.is_alive]
        if not alive_players:
            return

        embed = discord.Embed(
            title="Current Tribute Status",
            description=f"Remaining: {len(alive_players)}/{len(self.players)} | Day {self.day} | {'Night' if self.is_night else 'Day'}",
            color=discord.Color.blue()
        )

        # Arena conditions
        embed.add_field(
            name="Arena Conditions",
            value=f"Weather: {self.weather}\nHazards: {len(self.hazards)}\nSupply Drops: {len(self.supply_drops)}",
            inline=False
        )

        # Group players by team
        for team in self.teams:
            team.add_to_embed(embed, show_detailed=True)

        await self.ctx.send(embed=embed)

    async def show_final_stats(self):
        embed = discord.Embed(title="Final Statistics", color=discord.Color.gold())

        # Team standings
        team_lines = []
        for team in sorted(self.teams, key=lambda t: t.team_id):
            status = "Survived" if team.is_active() else "Eliminated"
            members = ", ".join([p.name for p in team.players])
            team_lines.append(
                f"**Team {team.team_id + 1}** ({status})\n"
                f"Members: {members}\n"
                f"Kills: {sum(p.kills for p in team.players)}"
            )

        embed.add_field(name="Team Standings", value="\n\n".join(team_lines), inline=False)

        # Individual leaderboard
        sorted_players = sorted(self.players, key=lambda p: p.kills, reverse=True)
        kill_leaders = "\n".join(
            [f"{p.name}: {p.kills} kills" for p in sorted_players[:5]]
        )
        embed.add_field(name="Top Killers", value=kill_leaders, inline=False)

        # Game stats
        embed.add_field(
            name="Game Summary",
            value=f"Rounds: {self.round}\nDays: {self.day}\nDeaths: {len(self.players) - len([p for p in self.players if p.is_alive])}",
            inline=False
        )

        await self.ctx.send(embed=embed)

    async def main(self):
        """Main game loop with enhanced visualization and mechanics"""
        # Setup the game
        self.setup_game()

        # Show the starting cast
        await self.send_cast()

        # Initial round
        embed = discord.Embed(
            title="Let the Hunger Games begin!",
            description="The tributes are rising on their platforms as the countdown begins...",
            color=discord.Color.gold()
        )
        await self.ctx.send(embed=embed)

        # Initial cornucopia bloodbath
        bloodbath_embed = discord.Embed(
            title="The Bloodbath",
            description="The tributes race towards the Cornucopia as the games begin!",
            color=discord.Color.red()
        )
        await self.ctx.send(embed=bloodbath_embed)
        await asyncio.sleep(3)

        # Game loop
        while len(self.get_active_teams()) > 1:
            # Game master can influence events at the start of each day
            if not self.is_night and self.game_master:
                gm_event = await self.handle_game_master_turn()
                if gm_event:
                    await self.ctx.send(embed=gm_event)
                    await asyncio.sleep(3)

            await self.get_inputs()

            # Break alliances when only allied teams remain
            active_teams = self.get_active_teams()
            if len(active_teams) == 2:
                team1, team2 = active_teams
                if team1 in team2.alliances:
                    team1.break_alliance(team2)
                    await self.ctx.send(
                        "**The final alliance breaks!** "
                        f"Team {team1.team_id + 1} and Team {team2.team_id + 1} turn on each other!"
                    )

            if self.round % 3 == 0:
                await self.show_player_stats()

            await asyncio.sleep(3)

        # Game over - announce winner or draw
        winning_teams = self.get_active_teams()
        if len(winning_teams) == 1:
            winner = winning_teams[0]
            members = winner.get_alive_players()

            victory_embed = discord.Embed(
                title="Victory! The Hunger Games Have Ended",
                description=f"Team {winner.team_id + 1} has emerged victorious!",
                color=discord.Color.gold()
            )

            # Set thumbnail
            if members:
                victory_embed.set_thumbnail(url=winner.get_team_avatar())

            # Add victorious team members
            member_text = []
            for player in members:
                member_text.append(f"{player.get_status_emoji()} {player.name} | Kills: {player.kills} | HP: {player.health}")

            victory_embed.add_field(
                name="Victorious Tributes",
                value="\n".join(member_text) if member_text else "No survivors remain",
                inline=False
            )

            # Team stats
            total_kills = sum(p.kills for p in winner.players)
            victory_embed.set_footer(text=f"Total team kills: {total_kills} | Game length: {self.day} days")

            await self.ctx.send(embed=victory_embed)
        else:  # No teams left (shouldn't happen)
            embed = discord.Embed(
                title="Hunger Games Results",
                description="The arena claims all! No victors remain.",
                color=discord.Color.red()
            )
            await self.ctx.send(embed=embed)

        await self.show_final_stats()


class HungerGames(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.games = {}

    @commands.command(aliases=["hg"], brief=_("Play the hunger games"))
    @locale_doc
    async def hungergames(self, ctx):
        _(
            """Starts the hunger games

            Players will be able to join via the :shallow_pan_of_food: emoji.
            The game is controlled via both random actions and possibly chosen actions.
            Players may choose an action if they get a direct message from the bot. If no action is chosen by the player, the bot chooses one for them.

            Not every player will get the opportunity to choose an action. Sometimes nobody gets to choose, so don't be discouraged.

            The new and improved system includes:
            - Resource management (health, food, water)
            - Weapons and items that affect combat
            - Team mechanics that make teams meaningful
            - Day/night cycles and special events
            - Status effects and more strategic choices
            - Visual representation with player avatars
            - Game Master role for controlling the arena
            """
        )

        await ctx.send("Please keep in mind that this is a WIP")

        if self.games.get(ctx.channel.id):
            return await ctx.send(_("There is already a game in here!"))

        self.games[ctx.channel.id] = "forming"

        if ctx.channel.id == self.bot.config.game.official_tournament_channel_id:
            view = JoinView(
                Button(
                    style=ButtonStyle.primary,
                    label="Join the Hunger Games!",
                    emoji="\U0001f958",
                ),
                message=_("You joined the Hunger Games."),
                timeout=60 * 10,
            )
            await ctx.send(
                f"{ctx.author.mention} started a mass-game of Hunger Games!",
                view=view,
            )
            await asyncio.sleep(60 * 10)
            view.stop()
            players = list(view.joined)
        else:
            view = JoinView(
                Button(
                    style=ButtonStyle.primary,
                    label="Join the Hunger Games!",
                    emoji="\U0001f958",
                ),
                message=_("You joined the Hunger Games."),
                timeout=60 * 2,
            )
            view.joined.add(ctx.author)
            text = _("{author} started a game of Hunger Games!")
            await ctx.send(text.format(author=ctx.author.mention), view=view)
            await asyncio.sleep(60 * 2)
            view.stop()
            players = list(view.joined)

        if len(players) < 2:
            del self.games[ctx.channel.id]
            await self.bot.reset_cooldown(ctx)
            return await ctx.send(_("Not enough players joined..."))

        game = GameBase(ctx, players=players)
        self.games[ctx.channel.id] = game
        try:
            await game.main()
        except Exception as e:
            await ctx.send(
                _(f"{e} An error happened during the hungergame. Please try again!")
            )
            raise e
        finally:
            try:
                del self.games[ctx.channel.id]
            except KeyError:  # got stuck in between
                pass

    @commands.command(aliases=["hgtest"], brief=_("Test the hunger games with bots"))
    @locale_doc
    async def hungergamestest(self, ctx, num_bots: int = 8):
        _(
            """Starts a test hunger games with bots

            You can specify how many bots to add to the game.
            This command is useful for testing the hunger games without needing real players.

            Usage: !hungergamestest [num_bots]
            """
        )
        if self.games.get(ctx.channel.id):
            return await ctx.send(_("There is already a game in here!"))

        self.games[ctx.channel.id] = "forming"

        # Add the command author
        players = [ctx.author]

        # Make sure num_bots is within a reasonable range
        num_bots = min(max(1, num_bots), 23)  # 1 <= num_bots <= 23

        await ctx.send(
            _("{author} started a test game of Hunger Games with {num} bots!").format(
                author=ctx.author.mention,
                num=num_bots
            )
        )

        # Pass num_bots to GameBase
        game = GameBase(ctx, players=players, is_test_mode=True, num_bots=num_bots, force_choice=True)
        self.games[ctx.channel.id] = game

        try:
            await game.main()
        except Exception as e:
            await ctx.send(
                _(f"{e} An error happened during the test hungergame. Please try again!")
            )
            raise e
        finally:
            try:
                del self.games[ctx.channel.id]
            except KeyError:  # got stuck in between
                pass


async def setup(bot):
    await bot.add_cog(HungerGames(bot))