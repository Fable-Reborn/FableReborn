import asyncio
import copy
import random
from typing import Dict, List, Optional
import discord
from discord import Embed, Color, ButtonStyle
from discord.ext import commands
from discord.ui import Button, View
from collections import defaultdict


# ============================== #
#       CORE GAME CLASSES        #
# ============================== #

class Weapon:
    def __init__(self, name, damage, accuracy, durability, type_="melee", special=None):
        self.name = name
        self.damage = damage
        self.accuracy = accuracy
        self.durability = durability
        self.type = type_  # melee, ranged, explosive, trap
        self.special = special  # special effect like bleeding, poison, etc.

    def use(self):
        """Use the weapon once, reducing durability"""
        if self.durability > 0:
            self.durability -= 1
        return self.durability > 0

    def get_emoji(self):
        if self.type == "melee":
            return "⚔️"
        elif self.type == "ranged":
            return "🏹"
        elif self.type == "explosive":
            return "💣"
        elif self.type == "trap":
            return "⚠️"
        return "🔪"

    def __str__(self):
        return f"{self.get_emoji()} {self.name} ({self.damage} dmg, {self.accuracy}% acc)"


class Item:
    def __init__(self, name, type_, effect_value, uses=1, special=None):
        self.name = name
        self.type = type_  # healing, food, water, utility, defense
        self.effect_value = effect_value
        self.uses = uses
        self.special = special

    def use(self):
        """Use the item once, reducing uses"""
        if self.uses > 0:
            self.uses -= 1
        return self.uses > 0

    def get_emoji(self):
        if self.type == "healing":
            return "🩹"
        elif self.type == "food":
            return "🍗"
        elif self.type == "water":
            return "💧"
        elif self.type == "utility":
            return "🧰"
        elif self.type == "defense":
            return "🛡️"
        return "📦"

    def __str__(self):
        return f"{self.get_emoji()} {self.name} ({self.uses} uses)"


class Region:
    def __init__(self, name, resources, danger, shelter, connections, emoji):
        self.name = name
        self.resources = resources  # Dict with food, water, items chances
        self.danger = danger  # 1-10 scale
        self.shelter = shelter  # 1-10 scale
        self.connections = connections  # List of connected region names
        self.emoji = emoji
        self.players = []  # Players currently in this region
        self.condition = "normal"  # normal, dangerous, resourceful, etc.
        self.condition_timer = 0
        self.traps = []  # List of traps in this region
        self.supplies = []  # List of supplies in this region

    def add_player(self, player):
        if player not in self.players:
            self.players.append(player)

    def remove_player(self, player):
        if player in self.players:
            self.players.remove(player)

    def set_condition(self, condition, duration=3):
        self.condition = condition
        self.condition_timer = duration

    def get_condition_emoji(self):
        if self.condition == "normal":
            return ""
        elif self.condition == "fire":
            return "🔥"
        elif self.condition == "flood":
            return "🌊"
        elif self.condition == "fog":
            return "🌫️"
        elif self.condition == "feast":
            return "🍽️"
        elif self.condition == "storm":
            return "⛈️"
        return ""

    def update(self):
        """Update region conditions"""
        if self.condition_timer > 0:
            self.condition_timer -= 1
            if self.condition_timer == 0:
                self.condition = "normal"

    def __str__(self):
        condition = f" {self.get_condition_emoji()}" if self.condition != "normal" else ""
        return f"{self.emoji} {self.name}{condition}"


class Player:
    def __init__(self, user, team_id=None):
        self.user = user
        self.name = user.name
        self.mention = user.mention
        self.avatar = user.avatar
        self.id = user.id if hasattr(user, 'id') else random.randint(10000, 99999)

        self.team_id = team_id
        self.health = 100
        self.max_health = 100
        self.food = 50
        self.water = 50
        self.energy = 100

        self.weapons = []
        self.items = []
        self.status_effects = []  # List of (effect, duration) tuples

        self.kills = 0
        self.is_alive = True
        self.is_hidden = False
        self.current_region = None

        # Combat stats
        self.strength = random.randint(3, 7)  # Base combat ability
        self.agility = random.randint(3, 7)  # Dodge/stealth ability
        self.intelligence = random.randint(3, 7)  # Strategy/crafting ability

        # Tracking
        self.known_players = {}  # player_id: last_known_region
        self.alliances = []  # List of allied player IDs

    def add_weapon(self, weapon):
        self.weapons.append(weapon)

    def add_item(self, item):
        self.items.append(item)

    def remove_weapon(self, weapon):
        if weapon in self.weapons:
            self.weapons.remove(weapon)

    def remove_item(self, item):
        if item in self.items:
            self.items.remove(item)

    def add_status_effect(self, effect, duration):
        # Check if effect already exists, update duration if so
        for i, (existing_effect, existing_duration) in enumerate(self.status_effects):
            if existing_effect == effect:
                self.status_effects[i] = (effect, max(existing_duration, duration))
                return
        # Add new effect
        self.status_effects.append((effect, duration))

    def get_combat_power(self):
        """Calculate total combat power based on stats and equipment"""
        # Base power from stats
        power = self.strength * 5

        # Add weapon power (best weapon)
        weapon_power = 0
        for weapon in self.weapons:
            if weapon.damage > weapon_power:
                weapon_power = weapon.damage

        # Add weapon power and adjust for health
        total_power = (power + weapon_power) * (self.health / 100)

        # Adjust for status effects
        for effect, _ in self.status_effects:
            if effect == "wounded":
                total_power *= 0.7
            elif effect == "strengthened":
                total_power *= 1.3

        return max(1, int(total_power))

    def update_needs(self):
        """Update player needs (food, water) each round"""
        # Base consumption
        self.food -= random.randint(5, 10)
        self.water -= random.randint(7, 12)

        # Energy regeneration if well-fed and hydrated
        if self.food > 30 and self.water > 30:
            self.energy = min(100, self.energy + 10)
        else:
            self.energy = max(0, self.energy - 10)

        # Health effects of hunger and thirst
        if self.food <= 0:
            self.health -= 10
            self.food = 0
        elif self.food < 20:
            self.health -= 5

        if self.water <= 0:
            self.health -= 15
            self.water = 0
        elif self.water < 15:
            self.health -= 8

        # Natural healing if well-fed
        if self.food > 60 and self.water > 60 and self.health < self.max_health:
            self.health = min(self.max_health, self.health + 5)

    def update_status_effects(self):
        """Update status effects, reducing duration and applying effects"""
        updated_effects = []

        for effect, duration in self.status_effects:
            if duration > 1:
                updated_effects.append((effect, duration - 1))

            # Apply effect consequences
            if effect == "bleeding":
                self.health -= 8
            elif effect == "poisoned":
                self.health -= 12
                self.water -= 10
            elif effect == "infected":
                self.health -= 15
            elif effect == "well_fed":
                self.food = min(100, self.food + 10)
            elif effect == "hydrated":
                self.water = min(100, self.water + 15)
            elif effect == "healing":
                self.health = min(self.max_health, self.health + 10)

        self.status_effects = updated_effects

        # Check if player has died from status effects
        if self.health <= 0:
            self.is_alive = False
            return False
        return True

    def get_status_emoji(self):
        """Get emoji representation of player status"""
        emoji = []

        # Health status
        if self.health > 75:
            emoji.append("❤️")
        elif self.health > 40:
            emoji.append("💔")
        else:
            emoji.append("🖤")

        # Resource status
        if self.food < 20 or self.water < 20:
            emoji.append("😰")

        # Combat status
        if any(effect == "bleeding" for effect, _ in self.status_effects):
            emoji.append("🩸")
        if any(effect == "poisoned" for effect, _ in self.status_effects):
            emoji.append("🧪")
        if any(effect == "infected" for effect, _ in self.status_effects):
            emoji.append("🦠")

        # Special states
        if self.is_hidden:
            emoji.append("👁️")
        if self.weapons:
            emoji.append("⚔️")

        return " ".join(emoji)

    def __str__(self):
        return f"{self.name} {self.get_status_emoji()}"


class Team:
    def __init__(self, team_id, players):
        self.team_id = team_id
        self.players = players
        for player in players:
            player.team_id = team_id

        self.base = None  # Region where team base is located
        self.alliances = []  # List of allied team IDs
        self.enemies = []  # List of enemy team IDs
        self.morale = 50  # Team morale (0-100)
        self.strategy = "balanced"  # balanced, aggressive, defensive, stealth

    def get_alive_players(self):
        return [p for p in self.players if p.is_alive]

    def is_active(self):
        return any(p.is_alive for p in self.players)

    def get_team_power(self):
        """Calculate team's total combat power"""
        alive_players = self.get_alive_players()
        if not alive_players:
            return 0

        individual_powers = [p.get_combat_power() for p in alive_players]
        # Teamwork bonus based on morale
        team_bonus = 1.0 + ((self.morale - 50) / 200)  # +/- 25% based on morale
        return sum(individual_powers) * team_bonus

    def form_alliance(self, other_team):
        if other_team.team_id not in self.alliances and other_team.team_id != self.team_id:
            self.alliances.append(other_team.team_id)
            other_team.alliances.append(self.team_id)

            # Remove from enemies if present
            if other_team.team_id in self.enemies:
                self.enemies.remove(other_team.team_id)
            if self.team_id in other_team.enemies:
                other_team.enemies.remove(self.team_id)

            # Morale boost
            self.morale = min(100, self.morale + 15)
            other_team.morale = min(100, other_team.morale + 15)

            # Set mutual alliances between players
            for p1 in self.get_alive_players():
                for p2 in other_team.get_alive_players():
                    if p2.id not in p1.alliances:
                        p1.alliances.append(p2.id)
                    if p1.id not in p2.alliances:
                        p2.alliances.append(p1.id)

    def break_alliance(self, other_team):
        if other_team.team_id in self.alliances:
            self.alliances.remove(other_team.team_id)
            other_team.alliances.remove(self.team_id)

            self.enemies.append(other_team.team_id)
            other_team.enemies.append(self.team_id)

            # Morale penalty
            self.morale = max(0, self.morale - 20)
            other_team.morale = max(0, other_team.morale - 20)

            # Remove mutual alliances between players
            for p1 in self.get_alive_players():
                for p2 in other_team.get_alive_players():
                    if p2.id in p1.alliances:
                        p1.alliances.remove(p2.id)
                    if p1.id in p2.alliances:
                        p2.alliances.remove(p1.id)

    def get_color(self):
        """Get color associated with team"""
        colors = [
            Color.blue(), Color.green(), Color.red(), Color.purple(),
            Color.orange(), Color.teal(), Color.magenta(), Color.gold()
        ]
        return colors[self.team_id % len(colors)]

    def __str__(self):
        alive_count = len(self.get_alive_players())
        total_count = len(self.players)
        return f"Team {self.team_id + 1} ({alive_count}/{total_count} alive)"


class HungerGames:
    def __init__(self, ctx, players, is_test=False, num_bots=0, force_choice=False):
        self.ctx = ctx
        self.raw_players = players
        self.players = []
        self.teams = []
        self.round = 0
        self.day = 1
        self.is_night = False
        self.is_test = is_test
        self.num_bots = num_bots
        self.force_choice = force_choice
        self.bot_names = self.generate_bot_names()
        self.killed_this_round = []

        # Game state
        self.game_phase = "setup"  # setup, bloodbath, main, finale, ended
        self.cornucopia_active = True
        self.cornucopia_timer = 3  # Rounds until Cornucopia deactivates
        self.anthem_played = False

        # Available weapons and items
        self.available_weapons = self.create_weapons()
        self.available_items = self.create_items()

        # Arena setup
        self.regions = self.create_regions()
        self.current_event = None
        self.event_timer = 0



    def generate_bot_names(self):
        """Generate list of bot names"""
        first_names = [
            "Alex", "Riley", "Jordan", "Casey", "Quinn", "Blake", "Morgan", "Taylor",
            "Cameron", "Avery", "Reese", "Harper", "Dakota", "Skyler", "Finley", "Rowan"
        ]
        last_names = [
            "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
            "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson"
        ]

        bot_names = []
        for i in range(30):  # Generate 30 potential names
            if random.random() < 0.7:  # 70% full names
                name = f"{random.choice(first_names)} {random.choice(last_names)}"
            else:  # 30% single names
                name = random.choice(first_names)
            bot_names.append(name)

        return bot_names

    def create_weapons(self):
        """Create all available weapons in the game"""
        weapons = [
            # Melee weapons
            Weapon("Knife", 15, 90, 8, "melee", None),
            Weapon("Sword", 25, 85, 15, "melee", None),
            Weapon("Axe", 30, 80, 12, "melee", "bleeding"),
            Weapon("Spear", 20, 85, 10, "melee", None),
            Weapon("Mace", 35, 75, 10, "melee", None),
            Weapon("Machete", 25, 85, 12, "melee", "bleeding"),

            # Ranged weapons
            Weapon("Bow", 20, 75, 8, "ranged", None),
            Weapon("Crossbow", 30, 80, 6, "ranged", None),
            Weapon("Throwing Knives", 15, 70, 5, "ranged", None),
            Weapon("Slingshot", 10, 65, 10, "ranged", None),
            Weapon("Blowgun", 15, 75, 7, "ranged", "poisoned"),

            # Explosive/traps
            Weapon("Land Mine", 50, 100, 1, "explosive", None),
            Weapon("Tripwire Trap", 25, 90, 2, "trap", None),
            Weapon("Pit Trap", 30, 85, 1, "trap", None),
            Weapon("Poison Trap", 20, 95, 2, "trap", "poisoned")
        ]
        return weapons

    def create_items(self):
        """Create all available items in the game"""
        items = [
            # Healing items
            Item("First Aid Kit", "healing", 40, 1, None),
            Item("Bandages", "healing", 20, 2, None),
            Item("Medicine", "healing", 30, 1, "cure"),
            Item("Healing Herbs", "healing", 15, 3, None),

            # Food items
            Item("Dried Meat", "food", 40, 2, None),
            Item("Fruit", "food", 25, 3, None),
            Item("Energy Bar", "food", 30, 1, "energy"),
            Item("Nuts and Berries", "food", 20, 3, None),

            # Water items
            Item("Water Bottle", "water", 50, 1, None),
            Item("Purification Tablets", "water", 30, 3, "purify"),
            Item("Canteen", "water", 40, 2, None),

            # Utility items
            Item("Rope", "utility", 0, 1, "climb"),
            Item("Sleeping Bag", "utility", 0, 1, "rest"),
            Item("Night Vision Goggles", "utility", 0, 3, "nightvision"),
            Item("Backpack", "utility", 0, 1, "storage"),
            Item("Compass", "utility", 0, 1, "navigation"),

            # Defense items
            Item("Body Armor", "defense", 30, 3, None),
            Item("Shield", "defense", 20, 5, None),
            Item("Camouflage", "defense", 0, 3, "stealth"),
        ]
        return items

    def create_regions(self):
        """Create all regions in the arena"""
        # Define all regions with connections populated later
        cornucopia = Region("Cornucopia", {"food": 5, "water": 5, "items": 20}, 10, 1, [], "🏛️")
        forest = Region("Forest", {"food": 20, "water": 10, "items": 5}, 6, 7, [], "🌲")
        lake = Region("Lake", {"food": 15, "water": 25, "items": 5}, 4, 3, [], "🌊")
        mountain = Region("Mountain", {"food": 10, "water": 15, "items": 10}, 8, 5, [], "⛰️")
        plains = Region("Plains", {"food": 15, "water": 5, "items": 5}, 3, 2, [], "🌾")
        ruins = Region("Ruins", {"food": 5, "water": 5, "items": 15}, 7, 8, [], "🏚️")
        cave = Region("Cave", {"food": 5, "water": 10, "items": 10}, 9, 9, [], "🕳️")
        beach = Region("Beach", {"food": 10, "water": 20, "items": 5}, 5, 4, [], "🏖️")

        # Set connections (adjacent regions)
        cornucopia.connections = ["Forest", "Lake", "Plains", "Ruins"]
        forest.connections = ["Cornucopia", "Mountain", "Lake"]
        lake.connections = ["Cornucopia", "Forest", "Beach"]
        mountain.connections = ["Forest", "Cave", "Plains"]
        plains.connections = ["Cornucopia", "Mountain", "Beach"]
        ruins.connections = ["Cornucopia", "Cave"]
        cave.connections = ["Mountain", "Ruins"]
        beach.connections = ["Lake", "Plains"]

        # Create dictionary of regions
        regions = {
            "Cornucopia": cornucopia,
            "Forest": forest,
            "Lake": lake,
            "Mountain": mountain,
            "Plains": plains,
            "Ruins": ruins,
            "Cave": cave,
            "Beach": beach
        }

        # Setup initial supplies
        self.setup_initial_supplies(regions)

        return regions

    def setup_initial_supplies(self, regions):
        """Distribute initial supplies across regions"""
        # Cornucopia gets most weapons and items
        cornucopia = regions["Cornucopia"]

        # Add weapons to Cornucopia
        for _ in range(8):
            weapon = copy.deepcopy(random.choice(self.available_weapons))
            cornucopia.supplies.append(("weapon", weapon))

        # Add items to Cornucopia
        for _ in range(12):
            item = copy.deepcopy(random.choice(self.available_items))
            cornucopia.supplies.append(("item", item))

        # Add some resources to other regions
        for name, region in regions.items():
            if name != "Cornucopia":
                # Add 1-3 items to each region
                for _ in range(random.randint(1, 3)):
                    if random.random() < 0.7:  # 70% chance for an item
                        item = copy.deepcopy(random.choice(self.available_items))
                        region.supplies.append(("item", item))
                    else:  # 30% chance for a weapon
                        weapon = copy.deepcopy(random.choice(self.available_weapons))
                        region.supplies.append(("weapon", weapon))

    def create_bot_player(self):
        """Create a bot player for testing"""
        name = self.bot_names.pop(0) if self.bot_names else f"Tribute-{random.randint(1, 999)}"

        # Create fake user object
        class FakeUser:
            def __init__(self, name):
                self.name = name
                self.mention = f"@{name}"
                self.avatar = None
                self.id = random.randint(10000, 99999)

        user = FakeUser(name)
        return Player(user)

    def setup_game(self):
        """Initialize game, players, and teams"""
        # Create players
        self.players = []

        # Add real players
        for user in self.raw_players:
            player = Player(user)
            self.players.append(player)

        # Add bot players if needed
        if self.is_test:
            for _ in range(self.num_bots):
                bot_player = self.create_bot_player()
                self.players.append(bot_player)

        # Shuffle players
        random.shuffle(self.players)

        # Create teams (pairs of 2)
        self.form_teams()

        # Place players at random regions (except Cornucopia)
        starting_regions = [r for r in self.regions.values() if r.name != "Cornucopia"]
        for player in self.players:
            region = random.choice(starting_regions)
            self.move_player(player, region)

    def form_teams(self):
        """Form teams of 2 players each"""
        self.teams = []

        # Create pairs of players
        pairs = []
        for i in range(0, len(self.players), 2):
            if i + 1 < len(self.players):
                pairs.append([self.players[i], self.players[i + 1]])
            else:
                pairs.append([self.players[i]])

        # Create teams
        for team_id, pair in enumerate(pairs):
            team = Team(team_id, pair)
            self.teams.append(team)

            # Update player team_ids
            for player in pair:
                player.team_id = team_id

    def move_player(self, player, region):
        """Move a player to a new region"""
        # Remove from current region
        if player.current_region:
            if player in player.current_region.players:
                player.current_region.players.remove(player)

        # Add to new region
        if isinstance(region, str):
            region = self.regions[region]

        region.add_player(player)
        player.current_region = region

        return region

    def get_active_teams(self):
        """Get teams with at least one living player"""
        return [team for team in self.teams if team.is_active()]

    def get_all_alive_players(self):
        """Get all living players"""
        return [p for p in self.players if p.is_alive]

    def get_player_team(self, player):
        """Get the team a player belongs to"""
        for team in self.teams:
            if player in team.players:
                return team
        return None

    def get_player_teammates(self, player):
        """Get player's teammates"""
        team = self.get_player_team(player)
        if team:
            return [p for p in team.get_alive_players() if p != player]
        return []

    def get_region_players(self, region_name, exclude_player=None):
        """Get all players in a region"""
        if region_name in self.regions:
            players = self.regions[region_name].players
            if exclude_player:
                return [p for p in players if p != exclude_player and p.is_alive]
            return [p for p in players if p.is_alive]
        return []

    async def send_cast(self):
        """Display teams and players at the start"""
        embed = Embed(
            title="🔥 THE HUNGER GAMES - TRIBUTES 🔥",
            description="May the odds be ever in your favor!",
            color=Color.gold()
        )

        for team in self.teams:
            # Create field for each team
            members = [f"{p.mention}" for p in team.players]
            team_name = f"Team {team.team_id + 1}"

            embed.add_field(
                name=team_name,
                value="\n".join(members),
                inline=True
            )

        await self.ctx.send(embed=embed)

    async def run_bloodbath(self):
        """Run the initial bloodbath at the Cornucopia"""
        self.game_phase = "bloodbath"

        bloodbath_embed = Embed(
            title="🏛️ THE BLOODBATH 🏛️",
            description="The gong sounds! Tributes rush toward the Cornucopia or flee into the arena...",
            color=Color.red()
        )

        # Each player decides to participate in bloodbath or flee
        cornucopia = self.regions["Cornucopia"]
        events = []

        for player in self.players:
            # Bots have 70% chance to participate
            participates = random.random() < 0.7

            if participates:
                # Enter the bloodbath
                self.move_player(player, cornucopia)

                # Attempt to grab supplies
                success_chance = 50 + player.agility * 5

                if random.randint(1, 100) <= success_chance:
                    # Successfully grab supplies
                    num_items = random.randint(1, 3)
                    items_grabbed = []

                    for _ in range(num_items):
                        if cornucopia.supplies:
                            # Take a random item from supplies
                            supply_idx = random.randint(0, len(cornucopia.supplies) - 1)
                            supply_type, item = cornucopia.supplies.pop(supply_idx)

                            if supply_type == "weapon":
                                player.add_weapon(item)
                                items_grabbed.append(f"{item.get_emoji()} {item.name}")
                            else:
                                player.add_item(item)
                                items_grabbed.append(f"{item.get_emoji()} {item.name}")

                    events.append(f"{player.name} grabs {', '.join(items_grabbed)} from the Cornucopia.")
                else:
                    # Injured in the attempt
                    damage = random.randint(10, 30)
                    player.health -= damage

                    # 20% chance of death
                    if random.random() < 0.2 or player.health <= 0:
                        player.health = 0
                        player.is_alive = False
                        self.killed_this_round.append(player)

                        # Find a random killer
                        killers = [p for p in cornucopia.players if p.is_alive and p != player]
                        if killers:
                            killer = random.choice(killers)
                            killer.kills += 1
                            events.append(f"⚰️ {killer.name} kills {player.name} during the bloodbath!")
                        else:
                            events.append(f"⚰️ {player.name} dies in the confusion of the bloodbath!")
                    else:
                        events.append(f"🩸 {player.name} is injured at the Cornucopia, taking {damage} damage.")
            else:
                # Flee to a random connected region
                escape_region = random.choice([r for r in self.regions.values() if r.name != "Cornucopia"])
                self.move_player(player, escape_region)
                events.append(f"🏃 {player.name} flees to the {escape_region.name}.")

        # Add events to embed
        for i in range(0, len(events), 5):
            chunk = events[i:i + 5]
            bloodbath_embed.add_field(
                name=f"Bloodbath Events",
                value="\n".join(chunk),
                inline=False
            )

        # Send the bloodbath results
        await self.ctx.send(embed=bloodbath_embed)

        # Update game phase
        self.game_phase = "main"

    async def run_daily_recap(self):
        """Display a recap of the day, including deaths"""
        if not self.killed_this_round:
            return

        time_of_day = "Night" if self.is_night else "Day"

        recap = Embed(
            title=f"⚰️ FALLEN TRIBUTES - {time_of_day} {self.day} ⚰️",
            description="The anthem plays as faces appear in the sky...",
            color=Color.dark_grey()
        )

        # Group deaths by team
        deaths_by_team = {}
        for player in self.killed_this_round:
            team_id = player.team_id
            if team_id not in deaths_by_team:
                deaths_by_team[team_id] = []
            deaths_by_team[team_id].append(player)

        # Add each team's deaths
        for team_id, deaths in deaths_by_team.items():
            team = next((t for t in self.teams if t.team_id == team_id), None)
            if team:
                death_text = "\n".join([f"⚰️ {p.name}" for p in deaths])
                recap.add_field(
                    name=f"Team {team_id + 1}",
                    value=death_text,
                    inline=True
                )

        # Add kill counts
        killers = [p for p in self.players if p.kills > 0 and p.is_alive]
        if killers:
            killers.sort(key=lambda p: p.kills, reverse=True)
            killer_text = "\n".join([f"{p.name}: {p.kills} kills" for p in killers[:5]])
            recap.add_field(
                name="Top Killers",
                value=killer_text,
                inline=False
            )

        # Reset killed list
        self.killed_this_round = []

        # Send recap
        await self.ctx.send(embed=recap)

    async def run_event(self):
        """Run a random arena event"""
        # 30% chance for an event each day
        if random.random() > 0.3:
            return None

        possible_events = [
            ("Gamemaker Fireballs", "Fireballs rain down on parts of the arena!", "fireballs"),
            ("Arctic Storm", "A freezing storm sweeps through the arena!", "freeze"),
            ("Poison Fog", "A bank of deadly fog begins to move across the arena!", "fog"),
            ("Feast at Cornucopia", "Attention tributes! A feast awaits at the Cornucopia!", "feast"),
            ("Flash Flood", "Water rapidly rises in parts of the arena!", "flood"),
            ("Tracker Jacker Release", "Tracker jacker nests have been placed in the arena!", "trackerjackers"),
            ("Forest Fire", "A wildfire spreads through parts of the arena!", "fire"),
            ("Sponsor Gifts", "Silver parachutes descend into the arena!", "sponsors"),
            ("Arena Collapse", "Parts of the arena begin to collapse!", "collapse"),
            ("Muttation Release", "Deadly mutts have been released into the arena!", "mutts")
        ]

        event_name, event_desc, event_type = random.choice(possible_events)

        # Create event embed
        event_embed = Embed(
            title=f"⚠️ ARENA EVENT: {event_name.upper()} ⚠️",
            description=event_desc,
            color=Color.red()
        )

        # Apply event effects
        results = []

        if event_type == "fireballs":
            # Target 2-3 random regions
            target_regions = random.sample(list(self.regions.values()), random.randint(2, 3))

            affected_regions = []
            for region in target_regions:
                region.set_condition("fire", 2)
                affected_regions.append(f"{region.emoji} {region.name}")

                # Damage players in those regions
                for player in region.players:
                    if player.is_alive:
                        # Check for shelter/defense
                        shelter_bonus = 0
                        if any(item.type == "defense" for item in player.items):
                            shelter_bonus = 30

                        # 70% chance to be hit if in affected region
                        if random.randint(1, 100) <= (70 - shelter_bonus):
                            damage = random.randint(20, 40)
                            player.health -= damage
                            results.append(f"🔥 {player.name} takes {damage} damage from fireballs!")

                            if player.health <= 0:
                                player.is_alive = False
                                self.killed_this_round.append(player)
                                results.append(f"⚰️ {player.name} is killed by fireballs!")
                        else:
                            results.append(f"🛡️ {player.name} finds shelter from the fireballs!")

            event_embed.add_field(
                name="Affected Areas",
                value="Fireballs target: " + ", ".join(affected_regions),
                inline=False
            )

        elif event_type == "freeze":
            # Cold affects all outdoor regions
            outdoor_regions = ["Plains", "Mountain", "Beach", "Forest"]

            for region_name in outdoor_regions:
                self.regions[region_name].set_condition("storm", 2)

            # Each player in outdoor regions takes cold damage
            for player in self.get_all_alive_players():
                if player.current_region.name in outdoor_regions:
                    # Check for protection
                    has_protection = any(i.name == "Sleeping Bag" for i in player.items)

                    if not has_protection:
                        damage = random.randint(10, 25)
                        player.health -= damage
                        player.add_status_effect("freezing", 2)
                        results.append(f"❄️ {player.name} suffers {damage} damage from the cold!")

                        if player.health <= 0:
                            player.is_alive = False
                            self.killed_this_round.append(player)
                            results.append(f"⚰️ {player.name} freezes to death!")
                    else:
                        results.append(f"🛡️ {player.name} stays warm with their sleeping bag!")

            event_embed.add_field(
                name="Freezing Conditions",
                value="The following regions are affected by the storm: " + ", ".join(outdoor_regions),
                inline=False
            )

        elif event_type == "feast":
            # Add supplies to Cornucopia
            cornucopia = self.regions["Cornucopia"]
            cornucopia.set_condition("feast", 3)

            # Add high-value items to Cornucopia
            for _ in range(10):
                if random.random() < 0.5:
                    item = copy.deepcopy(random.choice(self.available_items))
                    cornucopia.supplies.append(("item", item))
                else:
                    weapon = copy.deepcopy(random.choice(self.available_weapons))
                    cornucopia.supplies.append(("weapon", weapon))

            event_embed.add_field(
                name="Feast Announcement",
                value="A feast has been prepared at the Cornucopia! Tables are laden with food, weapons, and supplies that many of you desperately need. Will you risk confrontation for these valuable resources?",
                inline=False
            )

        elif event_type == "sponsors":
            # Random players receive sponsor gifts
            lucky_tributes = random.sample(
                self.get_all_alive_players(),
                min(len(self.get_all_alive_players()) // 2, 5)
            )

            gifts = []
            for player in lucky_tributes:
                # Determine gift based on player's needs
                if player.health < 40:
                    # Health item
                    item = copy.deepcopy(next((i for i in self.available_items if i.type == "healing"), None))
                elif player.food < 30 or player.water < 30:
                    # Food or water
                    item = copy.deepcopy(next((i for i in self.available_items if i.type in ["food", "water"]), None))
                elif not player.weapons:
                    # Weapon for defenseless player
                    item = copy.deepcopy(random.choice(self.available_weapons))
                    player.add_weapon(item)
                    gifts.append(f"🎁 {player.name} receives {item.name} from sponsors!")
                    continue
                else:
                    # Random useful item
                    item = copy.deepcopy(random.choice(self.available_items))

                player.add_item(item)
                gifts.append(f"🎁 {player.name} receives {item.name} from sponsors!")

            event_embed.add_field(
                name="Sponsor Gifts",
                value="\n".join(gifts) if gifts else "No tributes received gifts.",
                inline=False
            )

        elif event_type == "fire":
            # Set forest on fire
            forest = self.regions["Forest"]
            forest.set_condition("fire", 3)

            # Players in forest must escape or take damage
            for player in [p for p in forest.players if p.is_alive]:
                # Chance to escape based on agility
                escape_chance = 40 + player.agility * 8

                if random.randint(1, 100) <= escape_chance:
                    # Escape to adjacent region
                    safe_regions = [self.regions[r] for r in forest.connections]
                    if safe_regions:
                        new_region = random.choice(safe_regions)
                        self.move_player(player, new_region)
                        results.append(f"🏃 {player.name} escapes the fire to {new_region.name}!")
                    else:
                        # Take damage if no escape
                        damage = random.randint(20, 35)
                        player.health -= damage
                        results.append(f"🔥 {player.name} takes {damage} damage from the fire!")
                else:
                    # Take significant fire damage
                    damage = random.randint(30, 50)
                    player.health -= damage
                    player.add_status_effect("burning", 2)
                    results.append(f"🔥 {player.name} is badly burned, taking {damage} damage!")

                # Check for death
                if player.health <= 0:
                    player.is_alive = False
                    self.killed_this_round.append(player)
                    results.append(f"⚰️ {player.name} perishes in the fire!")

            event_embed.add_field(
                name="Forest Fire",
                value="The forest is engulfed in flames! Tributes must escape or face the consequences.",
                inline=False
            )

        # Add results to embed
        if results:
            # Split results into fields if needed
            for i in range(0, len(results), 5):
                chunk = results[i:i + 5]
                event_embed.add_field(
                    name="Event Results",
                    value="\n".join(chunk),
                    inline=False
                )

        return event_embed

    def get_solo_actions(self, player):
        """Get available actions for a solo player"""
        actions = []

        # Get current region and players there
        current_region = player.current_region
        region_players = [p for p in current_region.players if p != player and p.is_alive]

        # ===== SURVIVAL ACTIONS =====
        # Search for supplies
        actions.append(
            ("🔍 Search for supplies", {
                "type": "search",
                "description": f"Search the {current_region.name} for useful items"
            })
        )

        # Hunt/forage for food
        if current_region.resources["food"] > 10:
            actions.append(
                ("🍗 Hunt for food", {
                    "type": "hunt",
                    "description": f"Hunt for food in the {current_region.name}"
                })
            )

        # Find water
        if current_region.resources["water"] > 10:
            actions.append(
                ("💧 Gather water", {
                    "type": "water",
                    "description": f"Collect water in the {current_region.name}"
                })
            )

        # ===== MOVEMENT ACTIONS =====
        # Move to adjacent regions
        for region_name in current_region.connections:
            region = self.regions[region_name]
            actions.append(
                (f"🚶 Travel to {region.emoji} {region.name}", {
                    "type": "move",
                    "target_region": region_name,
                    "description": f"Travel to the {region_name}"
                })
            )

        # ===== COMBAT ACTIONS =====
        # Attack another player in same region
        for target in region_players:
            # Skip teammates and allies
            if target.team_id == player.team_id or target.id in player.alliances:
                continue

            actions.append(
                (f"⚔️ Attack {target.name}", {
                    "type": "attack",
                    "target": target,
                    "description": f"Attack {target.name} directly"
                })
            )

            # Ambush option if player has weapons
            if player.weapons:
                actions.append(
                    (f"🗡️ Ambush {target.name}", {
                        "type": "ambush",
                        "target": target,
                        "description": f"Set up an ambush for {target.name}"
                    })
                )

        # ===== STEALTH ACTIONS =====
        # Hide in current region
        actions.append(
            ("👁️ Hide and observe", {
                "type": "hide",
                "description": f"Find a hiding spot in the {current_region.name}"
            })
        )

        # Set trap
        if player.weapons and any(w.type == "trap" for w in player.weapons):
            actions.append(
                ("⚠️ Set a trap", {
                    "type": "trap",
                    "description": f"Set a trap in the {current_region.name}"
                })
            )

        # ===== ITEM ACTIONS =====
        # Use healing items
        healing_items = [i for i in player.items if i.type == "healing"]
        for item in healing_items:
            actions.append(
                (f"🩹 Use {item.name}", {
                    "type": "use_item",
                    "item": item,
                    "description": f"Use {item.name} to restore health"
                })
            )

        # Use food items
        food_items = [i for i in player.items if i.type == "food"]
        for item in food_items:
            actions.append(
                (f"🍗 Eat {item.name}", {
                    "type": "use_item",
                    "item": item,
                    "description": f"Eat {item.name} to satisfy hunger"
                })
            )

        # Use water items
        water_items = [i for i in player.items if i.type == "water"]
        for item in water_items:
            actions.append(
                (f"💧 Drink {item.name}", {
                    "type": "use_item",
                    "item": item,
                    "description": f"Drink {item.name} to quench thirst"
                })
            )

        # ===== SOCIAL ACTIONS =====
        # Ally with another player in region (not from same team)
        for potential_ally in region_players:
            if potential_ally.team_id != player.team_id and potential_ally.id not in player.alliances:
                actions.append(
                    (f"🤝 Ally with {potential_ally.name}", {
                        "type": "ally",
                        "target": potential_ally,
                        "description": f"Offer an alliance to {potential_ally.name}"
                    })
                )

        # ===== DESPERATE ACTIONS =====
        if player.health < 30 or player.food < 20 or player.water < 20:
            if current_region.name != "Cornucopia":
                actions.append(
                    ("🏛️ Rush to Cornucopia", {
                        "type": "rush_cornucopia",
                        "description": "Make a desperate dash to the Cornucopia for supplies"
                    })
                )

            actions.append(
                ("🆘 Call for help", {
                    "type": "call_help",
                    "description": "Call for help, hoping for sponsor attention"
                })
            )

        # ===== REST ACTION =====
        actions.append(
            ("😴 Rest and recover", {
                "type": "rest",
                "description": "Take time to rest and recover energy"
            })
        )

        return actions

    def get_team_actions(self, team):
        """Get available actions for a team"""
        actions = []
        alive_members = team.get_alive_players()

        # Check if all team members are in the same region
        regions = set(player.current_region.name for player in alive_members)
        team_together = len(regions) == 1

        # ===== TEAM COORDINATION =====
        if not team_together:
            actions.append(
                ("🔄 Regroup team", {
                    "type": "regroup",
                    "description": "Coordinate to bring all team members together"
                })
            )

        # ===== TEAM SURVIVAL =====
        actions.append(
            ("🍗 Hunt together", {
                "type": "team_hunt",
                "description": "Coordinate hunting to maximize food gathering"
            })
        )

        actions.append(
            ("🏕️ Set up camp", {
                "type": "team_camp",
                "description": "Establish a defensible camp location"
            })
        )

        # ===== TEAM COMBAT =====
        # Find potential targets in regions where team members are
        potential_targets = []
        for player in alive_members:
            region_players = self.get_region_players(player.current_region.name, player)
            for target in region_players:
                # Skip allies
                if target.team_id == team.team_id or target.team_id in team.alliances:
                    continue
                if target not in potential_targets:
                    potential_targets.append(target)

        for target in potential_targets:
            target_team = self.get_player_team(target)
            actions.append(
                (f"⚔️ Attack {target.name}", {
                    "type": "team_attack",
                    "target": target,
                    "description": f"Coordinate a team attack on {target.name}"
                })
            )

            if target_team:
                actions.append(
                    (f"⚔️ Attack Team {target_team.team_id + 1}", {
                        "type": "team_attack_team",
                        "target_team": target_team,
                        "description": f"Launch an assault on Team {target_team.team_id + 1}"
                    })
                )

        # ===== TEAM ALLIANCE =====
        # Find potential team allies
        for other_team in self.teams:
            if other_team.team_id != team.team_id and other_team.is_active() and other_team.team_id not in team.alliances:
                # Check if any other team members are in regions with our team
                can_contact = False
                for our_player in alive_members:
                    for their_player in other_team.get_alive_players():
                        if our_player.current_region == their_player.current_region:
                            can_contact = True
                            break

                if can_contact:
                    actions.append(
                        (f"🤝 Ally with Team {other_team.team_id + 1}", {
                            "type": "team_alliance",
                            "target_team": other_team,
                            "description": f"Propose an alliance to Team {other_team.team_id + 1}"
                        })
                    )

        # ===== TEAM STRATEGY =====
        actions.append(
            ("🔍 Scout territory", {
                "type": "team_scout",
                "description": "Spread out to gather intelligence about the arena"
            })
        )

        actions.append(
            ("🛠️ Craft supplies", {
                "type": "team_craft",
                "description": "Work together to create useful items"
            })
        )

        actions.append(
            ("🏹 Weapon training", {
                "type": "team_train",
                "description": "Train together to improve combat effectiveness"
            })
        )

        # ===== TEAM BETRAYAL =====
        # Betrayal options for existing alliances
        for allied_team_id in team.alliances:
            allied_team = next((t for t in self.teams if t.team_id == allied_team_id), None)
            if allied_team and allied_team.is_active():
                actions.append(
                    (f"🗡️ Betray Team {allied_team.team_id + 1}", {
                        "type": "team_betray",
                        "target_team": allied_team,
                        "description": f"Break alliance with Team {allied_team.team_id + 1} with a surprise attack"
                    })
                )

        # ===== TEAM MOVEMENT =====
        if team_together:
            current_region = alive_members[0].current_region
            for region_name in current_region.connections:
                region = self.regions[region_name]
                actions.append(
                    (f"🚶 Travel to {region.emoji} {region.name} together", {
                        "type": "team_move",
                        "target_region": region_name,
                        "description": f"Move the entire team to {region_name}"
                    })
                )

        return actions

    def process_solo_action(self, player, action_type, action_data):
        """Process a solo player action and return the results"""
        results = ""
        success = False
        critical = False

        # Roll for success/failure/critical
        roll = random.randint(1, 100)
        if roll <= 10:  # 10% critical failure
            success = False
            critical = True
        elif roll <= 30:  # 20% normal failure
            success = False
            critical = False
        elif roll >= 90:  # 10% critical success
            success = True
            critical = True
        else:  # 60% normal success
            success = True
            critical = False

        # Process based on action type
        if action_type == "search":
            region = player.current_region

            if success:
                # Find something based on region
                if region.supplies:
                    # Take an existing supply
                    supply_idx = random.randint(0, len(region.supplies) - 1)
                    supply_type, item = region.supplies.pop(supply_idx)

                    if supply_type == "weapon":
                        player.add_weapon(item)
                        results = f"found a {item.get_emoji()} {item.name}!"
                    else:
                        player.add_item(item)
                        results = f"found a {item.get_emoji()} {item.name}!"
                else:
                    # Generate a new item based on region chance
                    if random.randint(1, 100) <= region.resources["items"]:
                        if random.random() < 0.3:  # 30% chance for weapon
                            weapon = copy.deepcopy(random.choice(self.available_weapons))
                            player.add_weapon(weapon)
                            results = f"discovered a {weapon.get_emoji()} {weapon.name}!"
                        else:  # 70% chance for item
                            item = copy.deepcopy(random.choice(self.available_items))
                            player.add_item(item)
                            results = f"discovered a {item.get_emoji()} {item.name}!"
                    else:
                        results = "searches but finds nothing useful."

                if critical:
                    # Critical success: find an additional item
                    if random.random() < 0.5:  # 50% chance for weapon
                        weapon = copy.deepcopy(random.choice(self.available_weapons))
                        player.add_weapon(weapon)
                        results += f" Amazing luck! Also found a {weapon.get_emoji()} {weapon.name}!"
                    else:  # 50% chance for item
                        item = copy.deepcopy(random.choice(self.available_items))
                        player.add_item(item)
                        results += f" Amazing luck! Also found a {item.get_emoji()} {item.name}!"
            else:
                results = "searches but finds nothing of value."

                if critical:
                    # Critical failure: get injured
                    damage = random.randint(5, 15)
                    player.health -= damage
                    results += f" While searching, {player.name} is injured and loses {damage} health!"

                    # Check for death
                    if player.health <= 0:
                        player.is_alive = False
                        self.killed_this_round.append(player)
                        results += f" {player.name} bleeds out from the injury!"

        elif action_type == "hunt":
            region = player.current_region
            base_chance = region.resources["food"]

            # Adjust chance based on weapons
            if any(w.type == "ranged" for w in player.weapons):
                base_chance += 20
            elif any(w.type == "melee" for w in player.weapons):
                base_chance += 10

            if success:
                food_gained = random.randint(20, 40)
                player.food = min(100, player.food + food_gained)
                results = f"successfully hunts and gains {food_gained} food!"

                if critical:
                    bonus_food = random.randint(15, 30)
                    player.food = min(100, player.food + bonus_food)
                    results += f" The hunt was exceptionally successful! Gained an extra {bonus_food} food!"
            else:
                results = "fails to catch anything while hunting."

                if critical:
                    # Critical failure: injury or worse
                    if random.random() < 0.3:
                        damage = random.randint(10, 25)
                        player.health -= damage
                        results += f" {player.name} is injured during the hunt and loses {damage} health!"

                        # Check for death
                        if player.health <= 0:
                            player.is_alive = False
                            self.killed_this_round.append(player)
                            results += f" {player.name} bleeds out from the hunting injury!"
                    else:
                        player.energy -= 20
                        results += " The failed hunt was exhausting!"

        elif action_type == "water":
            region = player.current_region
            base_chance = region.resources["water"]

            if success:
                water_gained = random.randint(25, 45)
                player.water = min(100, player.water + water_gained)
                results = f"finds water and quenches their thirst! Gained {water_gained} water."

                if critical:
                    # Critical success: find a sustainable source
                    bonus_water = random.randint(20, 30)
                    player.water = min(100, player.water + bonus_water)
                    results += f" Found an excellent water source! Gained extra {bonus_water} water!"
            else:
                results = "is unable to find clean water."

                if critical:
                    # Critical failure: drink contaminated water
                    player.add_status_effect("infected", 2)
                    player.water += random.randint(10, 20)
                    results += " Desperate with thirst, drinks contaminated water and becomes ill!"

        elif action_type == "move":
            target_region_name = action_data.get("target_region")
            if target_region_name in self.regions:
                target_region = self.regions[target_region_name]

                # Move player to new region
                self.move_player(player, target_region)
                results = f"travels to the {target_region.name}."

                # Events based on region condition
                if target_region.condition != "normal":
                    if target_region.condition == "fire":
                        damage = random.randint(15, 30)
                        player.health -= damage
                        results += f" The area is on fire! {player.name} takes {damage} damage!"
                    elif target_region.condition == "fog":
                        player.add_status_effect("poisoned", 2)
                        results += f" The area is filled with poisonous fog! {player.name} is poisoned!"
                    elif target_region.condition == "flood":
                        # 50% chance to be swept away
                        if random.random() < 0.5:
                            random_region = random.choice([r for r in self.regions.values()
                                                           if r.name != target_region_name])
                            self.move_player(player, random_region)
                            damage = random.randint(10, 20)
                            player.health -= damage
                            results += f" {player.name} is swept away by flood waters to {random_region.name} and takes {damage} damage!"

                # Check for other players in region
                other_players = [p for p in target_region.players if p != player and p.is_alive]
                if other_players:
                    players_text = ", ".join([p.name for p in other_players[:3]])
                    if len(other_players) > 3:
                        players_text += f" and {len(other_players) - 3} others"
                    results += f" {player.name} spots {players_text} in the area!"

                # Check for traps
                for trap in target_region.traps[:]:
                    trap_type, trap_owner = trap

                    # Don't trigger own traps or ally traps
                    if trap_owner == player or trap_owner.id in player.alliances:
                        continue

                    # 70% chance to trigger trap
                    if random.randint(1, 100) <= 70:
                        damage = random.randint(20, 40)
                        player.health -= damage
                        results += f" {player.name} triggers a {trap_type} trap and takes {damage} damage!"

                        # Remove trap after triggered
                        target_region.traps.remove(trap)

                        # Award trap owner
                        if trap_owner.is_alive:
                            trap_owner.kills += 0.5  # Partial kill credit

                        # Check for death
                        if player.health <= 0:
                            player.is_alive = False
                            self.killed_this_round.append(player)
                            results += f" {player.name} is killed by the trap!"

                            # Full kill credit
                            if trap_owner.is_alive:
                                trap_owner.kills += 0.5  # Complete the kill credit
            else:
                results = f"tries to travel to {target_region_name} but gets lost."

        elif action_type == "attack":
            target = action_data.get("target")
            if not target or not target.is_alive or target.current_region != player.current_region:
                results = f"looks for {target.name if target else 'a target'} but they are nowhere to be found."
                return results

            # Calculate attack power
            weapon_power = 0
            weapon_used = None
            for weapon in player.weapons:
                if weapon.damage > weapon_power:
                    weapon_power = weapon.damage
                    weapon_used = weapon

            attack_power = (player.strength * 3) + weapon_power

            # Calculate defense power
            defense_item = next((item for item in target.items if item.type == "defense"), None)
            defense_power = target.agility * 3
            if defense_item:
                defense_power += defense_item.effect_value

            # Compute success chance
            base_chance = 50 + (attack_power - defense_power) / 2
            base_chance = max(20, min(80, base_chance))  # Cap between 20-80%

            if success:
                # Calculate damage
                damage = random.randint(10, 20) + weapon_power // 2
                target.health -= damage

                results = f"attacks {target.name}"
                if weapon_used:
                    results += f" with their {weapon_used.name}"
                results += f" and deals {damage} damage!"

                # Use weapon durability
                if weapon_used and not weapon_used.use():
                    player.remove_weapon(weapon_used)
                    results += f" {player.name}'s {weapon_used.name} breaks during the attack!"

                # Critical success: cause status effect or extra damage
                if critical:
                    if weapon_used and weapon_used.special:
                        target.add_status_effect(weapon_used.special, 2)
                        results += f" {target.name} is now {weapon_used.special}!"
                    else:
                        extra_damage = random.randint(10, 20)
                        target.health -= extra_damage
                        results += f" Critical hit! Deals an extra {extra_damage} damage!"

                # Check for death
                if target.health <= 0:
                    target.is_alive = False
                    self.killed_this_round.append(target)
                    player.kills += 1
                    results += f" {target.name} has been killed!"

                    # Loot some items
                    if target.items or target.weapons:
                        looted = []

                        if target.items:
                            num_items = min(2, len(target.items))
                            items_to_loot = random.sample(target.items, num_items)
                            for item in items_to_loot:
                                player.add_item(item)
                                target.remove_item(item)
                                looted.append(f"{item.name}")

                        if target.weapons:
                            num_weapons = min(1, len(target.weapons))
                            weapons_to_loot = random.sample(target.weapons, num_weapons)
                            for weapon in weapons_to_loot:
                                player.add_weapon(weapon)
                                target.remove_weapon(weapon)
                                looted.append(f"{weapon.name}")

                        if looted:
                            results += f" {player.name} loots {', '.join(looted)} from the body."
            else:
                results = f"attacks {target.name} but misses!"

                # Critical failure: counter-attack
                if critical and target.weapons:
                    counter_weapon = random.choice(target.weapons)
                    counter_damage = random.randint(10, 20)
                    player.health -= counter_damage
                    results += f" {target.name} counter-attacks with their {counter_weapon.name} and deals {counter_damage} damage to {player.name}!"

                    # Check for death from counter
                    if player.health <= 0:
                        player.is_alive = False
                        self.killed_this_round.append(player)
                        target.kills += 1
                        results += f" {player.name} is killed by the counter-attack!"

        elif action_type == "ambush":
            target = action_data.get("target")
            if not target or not target.is_alive or target.current_region != player.current_region:
                results = f"sets up an ambush, but {target.name if target else 'the target'} never shows up."
                return results

            # Calculate ambush success chance - much higher than normal attack
            stealth_bonus = 20 if player.is_hidden else 0
            camouflage_bonus = 15 if any(i.special == "stealth" for i in player.items) else 0

            # Ambush is more effective with certain weapons
            weapon_bonus = 0
            weapon_used = None
            for weapon in player.weapons:
                if weapon.type == "ranged" or weapon.type == "trap":
                    if weapon.damage > weapon_bonus:
                        weapon_bonus = weapon.damage
                        weapon_used = weapon

            ambush_chance = 60 + stealth_bonus + camouflage_bonus + (weapon_bonus // 2)
            ambush_chance = min(90, ambush_chance)  # Cap at 90%

            if success:
                # Ambush succeeds - deal extra damage
                base_damage = random.randint(15, 25)
                weapon_damage = weapon_used.damage if weapon_used else 0
                ambush_bonus = random.randint(10, 20)  # Ambush bonus damage

                total_damage = base_damage + weapon_damage + ambush_bonus
                target.health -= total_damage

                results = f"ambushes {target.name}"
                if weapon_used:
                    results += f" with their {weapon_used.name}"
                results += f" and deals a devastating {total_damage} damage!"

                # Use weapon durability
                if weapon_used and not weapon_used.use():
                    player.remove_weapon(weapon_used)
                    results += f" {player.name}'s {weapon_used.name} breaks during the ambush!"

                # Critical success: status effect and prevent counter
                if critical:
                    if weapon_used and weapon_used.special:
                        target.add_status_effect(weapon_used.special, 3)  # Longer effect for critical
                        results += f" {target.name} is now severely {weapon_used.special}!"
                    else:
                        target.add_status_effect("bleeding", 2)
                        results += f" {target.name} is severely wounded and bleeding!"

                # Check for death
                if target.health <= 0:
                    target.is_alive = False
                    self.killed_this_round.append(target)
                    player.kills += 1
                    results += f" {target.name} has been killed by the ambush!"

                    # Loot items - ambush allows for more efficient looting
                    if target.items or target.weapons:
                        looted = []

                        if target.items:
                            num_items = min(3, len(target.items))
                            items_to_loot = random.sample(target.items, num_items)
                            for item in items_to_loot:
                                player.add_item(item)
                                target.remove_item(item)
                                looted.append(f"{item.name}")

                        if target.weapons:
                            num_weapons = min(2, len(target.weapons))
                            weapons_to_loot = random.sample(target.weapons, num_weapons)
                            for weapon in weapons_to_loot:
                                player.add_weapon(weapon)
                                target.remove_weapon(weapon)
                                looted.append(f"{weapon.name}")

                        if looted:
                            results += f" {player.name} loots {', '.join(looted)} from the body."
            else:
                results = f"tries to ambush {target.name} but is spotted! The element of surprise is lost."

                # Critical failure: target evades and retaliates
                if critical:
                    # Target can counter-attack
                    if target.weapons:
                        counter_weapon = random.choice(target.weapons)
                        counter_damage = random.randint(15, 30)
                        player.health -= counter_damage
                        results += f" {target.name} turns the tables and attacks with their {counter_weapon.name}, dealing {counter_damage} damage!"

                        # Check for death
                        if player.health <= 0:
                            player.is_alive = False
                            self.killed_this_round.append(player)
                            target.kills += 1
                            results += f" {player.name} is killed in the failed ambush!"
                    else:
                        # Target escapes
                        # Move target to random connected region
                        escape_regions = [self.regions[r] for r in target.current_region.connections]
                        if escape_regions:
                            escape_region = random.choice(escape_regions)
                            self.move_player(target, escape_region)
                            results += f" {target.name} flees to the {escape_region.name}!"

        elif action_type == "hide":
            region = player.current_region

            # Hiding success chance depends on region and skills
            hide_chance = region.shelter * 5 + player.agility * 5
            if any(i.special == "stealth" for i in player.items):
                hide_chance += 20

            if success:
                player.is_hidden = True

                # Rest while hidden
                energy_gain = random.randint(10, 20)
                player.energy = min(100, player.energy + energy_gain)

                results = f"finds a good hiding spot in the {region.name} and rests, recovering {energy_gain} energy."

                # Critical success: healing and discovery
                if critical:
                    health_gain = random.randint(10, 20)
                    player.health = min(100, player.health + health_gain)
                    results += f" The excellent spot allows for recovery, gaining {health_gain} health!"

                    # 50% chance to find something while hiding
                    if random.random() < 0.5:
                        if random.random() < 0.7:  # 70% food, 30% item
                            food_gain = random.randint(15, 30)
                            player.food = min(100, player.food + food_gain)
                            results += f" While hiding, finds some edible plants and gains {food_gain} food!"
                        else:
                            item = copy.deepcopy(random.choice([i for i in self.available_items if i.type != "weapon"]))
                            player.add_item(item)
                            results += f" While hiding, finds a {item.name}!"
            else:
                results = f"tries to hide but can't find a good spot in the {region.name}."

                # Critical failure: spotted by enemies
                if critical:
                    other_players = [p for p in region.players if p != player and p.is_alive
                                     and p.team_id != player.team_id and p.id not in player.alliances]

                    if other_players:
                        spotter = random.choice(other_players)
                        results += f" {spotter.name} spots {player.name} trying to hide!"

                        # 50% chance of attack
                        if random.random() < 0.5 and spotter.weapons:
                            weapon = random.choice(spotter.weapons)
                            damage = random.randint(10, 20) + weapon.damage // 2
                            player.health -= damage
                            results += f" {spotter.name} attacks with their {weapon.name} and deals {damage} damage!"

                            # Check for death
                            if player.health <= 0:
                                player.is_alive = False
                                self.killed_this_round.append(player)
                                spotter.kills += 1
                                results += f" {player.name} is killed while trying to hide!"

        elif action_type == "trap":
            region = player.current_region

            # Find trap weapon
            trap_weapon = next((w for w in player.weapons if w.type == "trap"), None)

            if trap_weapon:
                # Set trap in region
                region.traps.append((trap_weapon.name, player))

                # Use weapon durability
                if not trap_weapon.use():
                    player.remove_weapon(trap_weapon)

                results = f"sets a {trap_weapon.name} in the {region.name}."

                # Critical success: more effective trap
                if critical and success:
                    results += " The trap is exceptionally well concealed!"
                elif not success:
                    results = f"attempts to set a {trap_weapon.name} but it malfunctions."

                    # Critical failure: trap backfires
                    if critical:
                        damage = random.randint(10, 25)
                        player.health -= damage
                        player.add_status_effect("bleeding", 1)
                        results += f" The trap backfires and {player.name} takes {damage} damage and is bleeding!"

                        # Check for death
                        if player.health <= 0:
                            player.is_alive = False
                            self.killed_this_round.append(player)
                            results += f" {player.name} is killed by their own trap!"
            else:
                # Try to craft makeshift trap
                if random.randint(1, 100) <= (player.intelligence * 10):
                    trap_weapon = copy.deepcopy(next((w for w in self.available_weapons if w.type == "trap"), None))
                    if trap_weapon:
                        region.traps.append((trap_weapon.name, player))
                        results = f"crafts a makeshift {trap_weapon.name} and sets it in the {region.name}."
                    else:
                        results = "tries to set a trap but lacks the necessary materials."
                else:
                    results = "tries to create a trap but fails."

        elif action_type == "use_item":
            item = action_data.get("item")
            if item in player.items:
                # Use item based on type
                if item.type == "healing":
                    healing = item.effect_value
                    player.health = min(100, player.health + healing)
                    results = f"uses {item.name} and recovers {healing} health."

                    # Clear negative status effects if item has cure property
                    if item.special == "cure":
                        negative_effects = ["bleeding", "poisoned", "infected", "freezing", "burning"]
                        player.status_effects = [(effect, duration) for effect, duration in player.status_effects
                                                 if effect not in negative_effects]
                        results += " All negative status effects are cured!"

                elif item.type == "food":
                    food_value = item.effect_value
                    player.food = min(100, player.food + food_value)
                    results = f"eats {item.name} and gains {food_value} food."

                    # Energy bonus if item has energy property
                    if item.special == "energy":
                        energy_gain = random.randint(20, 40)
                        player.energy = min(100, player.energy + energy_gain)
                        results += f" The energy-rich food provides {energy_gain} energy!"

                elif item.type == "water":
                    water_value = item.effect_value
                    player.water = min(100, player.water + water_value)
                    results = f"drinks {item.name} and gains {water_value} water."

                    # Purify benefit
                    if item.special == "purify":
                        if any(effect == "infected" for effect, _ in player.status_effects):
                            player.status_effects = [(effect, duration) for effect, duration in player.status_effects
                                                     if effect != "infected"]
                            results += " The clean water helps cure the infection!"

                # Use item charge
                if not item.use():
                    player.remove_item(item)
                    results += f" The {item.name} has been used up."

                # Critical success: extra benefit
                if success and critical:
                    if item.type == "healing":
                        extra_healing = random.randint(10, 20)
                        player.health = min(100, player.health + extra_healing)
                        results += f" The treatment is exceptionally effective! Gained extra {extra_healing} health!"
                    elif item.type == "food":
                        extra_food = random.randint(10, 20)
                        player.food = min(100, player.food + extra_food)
                        results += f" The food is particularly nutritious! Gained extra {extra_food} food!"
                    elif item.type == "water":
                        extra_water = random.randint(10, 20)
                        player.water = min(100, player.water + extra_water)
                        results += f" The water is especially refreshing! Gained extra {extra_water} water!"

                # Failure: item has reduced effect
                if not success:
                    results += " However, the item doesn't seem very effective."

                    # Critical failure: item causes problems
                    if critical:
                        if item.type == "food":
                            player.add_status_effect("infected", 1)
                            results += " The food was spoiled! Gained an infection!"
                        elif item.type == "water":
                            player.add_status_effect("infected", 1)
                            results += " The water was contaminated! Gained an infection!"
            else:
                results = f"reaches for {item.name if item else 'an item'} but doesn't have it."

        elif action_type == "ally":
            target = action_data.get("target")
            if not target or not target.is_alive or target.current_region != player.current_region:
                results = f"looks for {target.name if target else 'potential allies'} but they're nowhere to be found."
                return results

            # Cannot ally with enemies in combat
            if player.health < 30 and target.weapons:
                results = f"tries to form an alliance with {target.name}, but they sense weakness and refuse."
                return results

            # Calculate alliance acceptance chance
            accept_chance = 50 - (player.health - target.health)

            # Bonus for similar needs
            if (player.food < 30 and target.food < 30) or (player.water < 30 and target.water < 30):
                accept_chance += 20

            # Bonus if player has items/weapons to share
            if len(player.items) > 1 or len(player.weapons) > 1:
                accept_chance += 15

            accept_chance = max(10, min(90, accept_chance))

            if success:
                # Alliance accepted
                if player.id not in target.alliances:
                    target.alliances.append(player.id)
                if target.id not in player.alliances:
                    player.alliances.append(target.id)

                results = f"forms an alliance with {target.name}!"

                # Critical success: share supplies
                if critical:
                    # Share an item if available
                    if player.items:
                        item = random.choice(player.items)
                        item_copy = copy.deepcopy(item)
                        target.add_item(item_copy)
                        results += f" {player.name} shares a {item.name} to seal the alliance!"

                    # Healing boost from alliance
                    healing = random.randint(10, 20)
                    player.health = min(100, player.health + healing)
                    target.health = min(100, target.health + healing)
                    results += f" Both allies gain {healing} health from the morale boost!"
            else:
                results = f"offers an alliance to {target.name}, but they are suspicious and decline."

                # Critical failure: target becomes hostile
                if critical:
                    results += f" In fact, {target.name} sees this as a trick and becomes hostile!"

                    # 30% chance of immediate attack
                    if random.random() < 0.3 and target.weapons:
                        weapon = random.choice(target.weapons)
                        damage = random.randint(10, 20) + weapon.damage // 2
                        player.health -= damage
                        results += f" {target.name} attacks with their {weapon.name}, dealing {damage} damage!"

                        # Check for death
                        if player.health <= 0:
                            player.is_alive = False
                            self.killed_this_round.append(player)
                            target.kills += 1
                            results += f" {player.name} is killed after the failed alliance attempt!"

        elif action_type == "rush_cornucopia":
            # Move to Cornucopia in desperation
            cornucopia = self.regions["Cornucopia"]

            # Success chance based on player condition
            rush_chance = 40 + (100 - player.health)

            if success:
                # Make it to Cornucopia
                previous_region = player.current_region
                self.move_player(player, cornucopia)
                results = f"makes a desperate rush from {previous_region.name} to the Cornucopia!"

                # Find supplies if any available
                if cornucopia.supplies:
                    # Take up to 2 supplies
                    num_supplies = min(2, len(cornucopia.supplies))
                    supplies_taken = []

                    for _ in range(num_supplies):
                        if cornucopia.supplies:
                            supply_idx = random.randint(0, len(cornucopia.supplies) - 1)
                            supply_type, item = cornucopia.supplies.pop(supply_idx)

                            if supply_type == "weapon":
                                player.add_weapon(item)
                                supplies_taken.append(f"{item.name}")
                            else:
                                player.add_item(item)
                                supplies_taken.append(f"{item.name}")

                    if supplies_taken:
                        results += f" Found {', '.join(supplies_taken)} at the Cornucopia!"

                # Critical success: extra supplies
                if critical:
                    # Generate high-value supplies
                    if random.random() < 0.6:  # 60% item, 40% weapon
                        item_types = ["healing", "food", "water"]
                        selected_type = random.choice(item_types)
                        item = copy.deepcopy(next((i for i in self.available_items if i.type == selected_type), None))
                        if item:
                            player.add_item(item)
                            results += f" Also found a life-saving {item.name}!"
                    else:
                        weapon = copy.deepcopy(random.choice([w for w in self.available_weapons if w.damage >= 20]))
                        player.add_weapon(weapon)
                        results += f" Also found a powerful {weapon.name}!"
            else:
                results = f"tries to rush to the Cornucopia but gets lost along the way."

                # Critical failure: ambushed en route
                if critical:
                    damage = random.randint(20, 40)
                    player.health -= damage
                    results += f" {player.name} is ambushed while trying to reach the Cornucopia and takes {damage} damage!"

                    # 50% chance of being moved to random region
                    if random.random() < 0.5:
                        random_region = random.choice([r for r in self.regions.values()
                                                       if r.name != player.current_region.name])
                        self.move_player(player, random_region)
                        results += f" {player.name} flees to {random_region.name}!"

                    # Check for death
                    if player.health <= 0:
                        player.is_alive = False
                        self.killed_this_round.append(player)
                        results += f" {player.name} bleeds out from the ambush wounds!"

        elif action_type == "call_help":
            # Success chance based on kills and condition
            help_chance = 30 + (player.kills * 10) + (20 - player.health // 5)
            help_chance = min(80, help_chance)

            if success:
                # Receive sponsor gift
                if random.random() < 0.7:  # 70% specific need, 30% random
                    if player.health < 40:
                        # Health item
                        item = copy.deepcopy(next((i for i in self.available_items if i.type == "healing"), None))
                        need_type = "healing"
                    elif player.food < 30:
                        # Food item
                        item = copy.deepcopy(next((i for i in self.available_items if i.type == "food"), None))
                        need_type = "food"
                    elif player.water < 30:
                        # Water item
                        item = copy.deepcopy(next((i for i in self.available_items if i.type == "water"), None))
                        need_type = "water"
                    else:
                        # Random useful item
                        need_type = random.choice(["healing", "food", "water", "utility"])
                        item = copy.deepcopy(next((i for i in self.available_items if i.type == need_type), None))
                else:
                    # Random item
                    item = copy.deepcopy(random.choice(self.available_items))
                    need_type = item.type

                player.add_item(item)
                results = f"calls for help and receives a sponsor gift: {item.name}!"

                # Critical success: extra gift
                if critical:
                    if need_type != "weapon" and not player.weapons:
                        # Give weapon to defenseless player
                        weapon = copy.deepcopy(random.choice(self.available_weapons))
                        player.add_weapon(weapon)
                        results += f" The sponsors are generous! Also received a {weapon.name}!"
                    else:
                        # Give second item
                        second_item = copy.deepcopy(
                            random.choice([i for i in self.available_items if i.type != need_type]))
                        player.add_item(second_item)
                        results += f" The sponsors are generous! Also received a {second_item.name}!"
            else:
                results = f"calls for help, but no sponsors respond."

                # Critical failure: attracts attention
                if critical:
                    results += f" The calls attract unwanted attention!"

                    # Reveal player's position
                    player.is_hidden = False

                    # Check for nearby hostiles
                    hostiles = [p for p in player.current_region.players if p != player and p.is_alive
                                and p.team_id != player.team_id and p.id not in player.alliances]

                    if hostiles:
                        hostile = random.choice(hostiles)
                        results += f" {hostile.name} hears the calls and approaches!"

                        # 50% chance of attack
                        if random.random() < 0.5 and hostile.weapons:
                            weapon = random.choice(hostile.weapons)
                            damage = random.randint(15, 25) + weapon.damage // 2
                            player.health -= damage
                            results += f" {hostile.name} attacks with their {weapon.name}, dealing {damage} damage!"

                            # Check for death
                            if player.health <= 0:
                                player.is_alive = False
                                self.killed_this_round.append(player)
                                hostile.kills += 1
                                results += f" {player.name} is killed after calling for help!"

        elif action_type == "rest":
            # Rest recovery
            energy_gain = random.randint(20, 40)
            player.energy = min(100, player.energy + energy_gain)

            health_gain = random.randint(5, 15)
            player.health = min(100, player.health + health_gain)

            results = f"takes time to rest, recovering {energy_gain} energy and {health_gain} health."

            # Sleeping bag bonus
            if any(i.name == "Sleeping Bag" for i in player.items):
                extra_health = random.randint(5, 15)
                player.health = min(100, player.health + extra_health)
                results += f" The sleeping bag provides comfort, healing an additional {extra_health} health!"

            # Critical success: additional recovery and food find
            if success and critical:
                # Find food while resting
                food_gain = random.randint(10, 25)
                player.food = min(100, player.food + food_gain)
                results += f" While resting, finds some edible plants and gains {food_gain} food!"

            # Failure: interrupted rest
            if not success:
                results += " The rest is interrupted and not very effective."

                # Critical failure: surprise attack
                if critical:
                    results += " Suddenly, danger strikes!"

                    # 50% chance of player attack, 50% chance of natural danger
                    if random.random() < 0.5:
                        # Check for nearby hostiles
                        hostiles = [p for p in player.current_region.players if p != player and p.is_alive
                                    and p.team_id != player.team_id and p.id not in player.alliances]

                        if hostiles:
                            hostile = random.choice(hostiles)
                            damage = random.randint(15, 30)
                            player.health -= damage
                            results += f" {hostile.name} ambushes {player.name} while resting, dealing {damage} damage!"

                            # Check for death
                            if player.health <= 0:
                                player.is_alive = False
                                self.killed_this_round.append(player)
                                hostile.kills += 1
                                results += f" {player.name} is killed in their sleep!"
                        else:
                            # Wild animal attack
                            damage = random.randint(10, 25)
                            player.health -= damage
                            results += f" A wild animal attacks during rest, dealing {damage} damage!"
                    else:
                        # Weather danger
                        damage = random.randint(10, 20)
                        player.health -= damage
                        if player.current_region.name in ["Mountain", "Beach"]:
                            results += f" A sudden storm strikes, dealing {damage} damage from exposure!"
                        else:
                            results += f" The temperature drops rapidly, dealing {damage} damage from cold!"

        return results

    def process_team_action(self, team, action_type, action_data):
        """Process a team action and return the results"""
        results = ""
        success = False
        critical = False

        # Roll for success/failure/critical
        roll = random.randint(1, 100)
        if roll <= 10:  # 10% critical failure
            success = False
            critical = True
        elif roll <= 30:  # 20% normal failure
            success = False
            critical = False
        elif roll >= 90:  # 10% critical success
            success = True
            critical = True
        else:  # 60% normal success
            success = True
            critical = False

        # Get living team members
        alive_members = team.get_alive_players()

        # Process based on action type
        if action_type == "regroup":
            # Try to bring team members together
            if len(alive_members) <= 1:
                return f"has only one surviving member. No need to regroup."

            # Find most common region
            regions = {}
            for player in alive_members:
                region = player.current_region.name
                if region not in regions:
                    regions[region] = 0
                regions[region] += 1

            target_region_name = max(regions.items(), key=lambda x: x[1])[0]
            target_region = self.regions[target_region_name]

            # Move all members to target region
            members_moved = 0
            for player in alive_members:
                if player.current_region.name != target_region_name:
                    self.move_player(player, target_region)
                    members_moved += 1

            if success:
                results = f"regroups at the {target_region_name}. {members_moved} members have rejoined the team."

                # Critical success: find supplies while regrouping
                if critical:
                    supplies_found = []

                    for _ in range(min(2, len(alive_members))):
                        if random.random() < 0.7:  # 70% item, 30% weapon
                            item = copy.deepcopy(random.choice(self.available_items))
                            random.choice(alive_members).add_item(item)
                            supplies_found.append(item.name)
                        else:
                            weapon = copy.deepcopy(random.choice(self.available_weapons))
                            random.choice(alive_members).add_weapon(weapon)
                            supplies_found.append(weapon.name)

                    if supplies_found:
                        results += f" While regrouping, the team finds {', '.join(supplies_found)}!"
            else:
                results = f"tries to regroup at the {target_region_name}, but only {members_moved} members make it."

                # Critical failure: ambushed while regrouping
                if critical:
                    results += " The team is ambushed during regrouping!"

                    # Random team member takes damage
                    victim = random.choice(alive_members)
                    damage = random.randint(20, 40)
                    victim.health -= damage
                    results += f" {victim.name} takes {damage} damage in the ambush!"

                    # Check for death
                    if victim.health <= 0:
                        victim.is_alive = False
                        self.killed_this_round.append(victim)
                        results += f" {victim.name} is killed during the regrouping attempt!"

        elif action_type == "team_hunt":
            # Coordinate hunting
            regions = set(player.current_region.name for player in alive_members)

            # Calculate base hunting success
            hunt_regions = []
            for region_name in regions:
                region = self.regions[region_name]
                if region.resources["food"] >= 10:
                    hunt_regions.append(region_name)

            # Hunting efficiency based on weapons
            has_weapons = any(p.weapons for p in alive_members)
            weapon_bonus = 15 if has_weapons else 0

            if success and hunt_regions:
                # Get total food
                base_food = random.randint(25, 40)
                bonus_food = len(alive_members) * 5 + weapon_bonus
                total_food = base_food + bonus_food

                # Distribute food
                food_per_player = total_food // len(alive_members)
                for player in alive_members:
                    player.food = min(100, player.food + food_per_player)

                results = f"coordinates a successful hunt, each member gaining {food_per_player} food."

                # Critical success: bonus water and possible item
                if critical:
                    water_gain = random.randint(15, 30)
                    for player in alive_members:
                        player.water = min(100, player.water + water_gain)

                    results += f" The team also finds a water source, gaining {water_gain} water each!"

                    # 50% chance of finding an item
                    if random.random() < 0.5:
                        item = copy.deepcopy(random.choice(self.available_items))
                        lucky_member = random.choice(alive_members)
                        lucky_member.add_item(item)
                        results += f" {lucky_member.name} also finds a {item.name}!"
            else:
                results = "attempts to hunt but finds little food."

                # Still get some food on normal failure
                if not critical:
                    food_gain = random.randint(5, 15)
                    for player in alive_members:
                        player.food = min(100, player.food + food_gain)
                    results += f" Each member only gains {food_gain} food."

                # Critical failure: hunting accident
                if critical:
                    results += " The hunt goes terribly wrong!"

                    # Random team member is injured
                    victim = random.choice(alive_members)
                    damage = random.randint(15, 30)
                    victim.health -= damage
                    victim.add_status_effect("bleeding", 2)
                    results += f" {victim.name} is injured during the hunt, taking {damage} damage and is now bleeding!"

                    # Check for death
                    if victim.health <= 0:
                        victim.is_alive = False
                        self.killed_this_round.append(victim)
                        results += f" {victim.name} bleeds out from the hunting accident!"

        elif action_type == "team_camp":
            # Set up camp in current region
            if len(set(p.current_region for p in alive_members)) > 1:
                return "cannot set up camp because team members are in different regions."

            region = alive_members[0].current_region

            # Calculate camp quality based on region and items
            shelter_value = region.shelter

            # Bonus for sleeping bags and defensive items
            shelter_bonus = 0
            for player in alive_members:
                if any(i.name == "Sleeping Bag" for i in player.items):
                    shelter_bonus += 10
                if any(i.type == "defense" for i in player.items):
                    shelter_bonus += 5

            camp_quality = min(100, shelter_value * 10 + shelter_bonus)

            if success:
                # Setup successful camp
                team.base = region.name

                # Recovery benefits
                health_gain = random.randint(10, 20)
                energy_gain = random.randint(20, 40)

                for player in alive_members:
                    player.health = min(100, player.health + health_gain)
                    player.energy = min(100, player.energy + energy_gain)

                results = f"sets up a camp at the {region.name}. Each member recovers {health_gain} health and {energy_gain} energy."

                # Critical success: excellent camp with extra benefits
                if critical:
                    # Extra recovery
                    extra_health = random.randint(10, 20)
                    for player in alive_members:
                        player.health = min(100, player.health + extra_health)

                    results += f" The camp is exceptionally well-built, providing an additional {extra_health} health recovery!"

                    # 70% chance of finding supplies
                    if random.random() < 0.7:
                        food_gain = random.randint(15, 30)
                        water_gain = random.randint(15, 30)

                        for player in alive_members:
                            player.food = min(100, player.food + food_gain)
                            player.water = min(100, player.water + water_gain)

                        results += f" The team finds nearby resources, gaining {food_gain} food and {water_gain} water each!"
            else:
                results = f"tries to set up camp at the {region.name}, but the location is not ideal."

                # Minimal recovery on failure
                health_gain = random.randint(5, 10)
                for player in alive_members:
                    player.health = min(100, player.health + health_gain)

                results += f" Each member still recovers {health_gain} health from the rest."

                # Critical failure: camp disaster
                if critical:
                    results += " The camp collapses during the night!"

                    # All members take some damage
                    damage = random.randint(10, 20)
                    for player in alive_members:
                        player.health -= damage

                        # Check for death
                        if player.health <= 0:
                            player.is_alive = False
                            self.killed_this_round.append(player)
                            results += f" {player.name} is killed in the camp collapse!"

        elif action_type == "team_attack":
            target = action_data.get("target")

            if not target or not target.is_alive:
                return f"prepares to attack {target.name if target else 'a target'}, but they can't be found."

            # Check if at least one team member is in same region as target
            attackers = [p for p in alive_members if p.current_region == target.current_region]
            if not attackers:
                return f"plans to attack {target.name}, but no team members are in position."

            # Calculate team attack power
            attack_power = sum(player.get_combat_power() for player in attackers)

            # Calculate target defense
            target_team = self.get_player_team(target)
            defenders = []
            if target_team:
                # Check for teammates in same region
                defenders = [p for p in target_team.get_alive_players()
                             if p != target and p.current_region == target.current_region]

            # Add target to defenders
            defense_power = target.get_combat_power() + sum(p.get_combat_power() for p in defenders)

            # Adjust success chance based on power ratio
            power_ratio = attack_power / max(1, defense_power)
            attack_chance = min(90, 50 + int((power_ratio - 1) * 30))

            if success:
                # Calculate damage
                base_damage = random.randint(20, 40)
                bonus_damage = (len(attackers) - 1) * 10  # Bonus for multiple attackers

                total_damage = base_damage + bonus_damage
                target.health -= total_damage

                results = f"coordinates an attack on {target.name} with {len(attackers)} members, dealing {total_damage} damage!"

                # Critical success: greater damage and possible instant kill
                if critical:
                    critical_damage = random.randint(20, 40)
                    target.health -= critical_damage
                    results += f" The attack is devastatingly effective, dealing an additional {critical_damage} damage!"

                # Check for death
                if target.health <= 0:
                    target.is_alive = False
                    self.killed_this_round.append(target)

                    # Award kill to random attacker
                    killer = random.choice(attackers)
                    killer.kills += 1

                    results += f" {target.name} has been killed by the team!"

                    # Loot distribution
                    if target.items or target.weapons:
                        looted = []

                        if target.items:
                            for item in target.items[:]:
                                recipient = random.choice(attackers)
                                recipient.add_item(item)
                                target.remove_item(item)
                                looted.append(f"{item.name}")

                        if target.weapons:
                            for weapon in target.weapons[:]:
                                recipient = random.choice(attackers)
                                recipient.add_weapon(weapon)
                                target.remove_weapon(weapon)
                                looted.append(f"{weapon.name}")

                        if looted:
                            results += f" The team loots {', '.join(looted)} from the body."

                # Damage defenders too if critical success
                if critical and defenders:
                    splash_damage = random.randint(10, 25)
                    defenders_hit = []

                    for defender in defenders:
                        defender.health -= splash_damage
                        defenders_hit.append(defender.name)

                        # Check for death
                        if defender.health <= 0:
                            defender.is_alive = False
                            self.killed_this_round.append(defender)

                            # Award kill to random attacker
                            random.choice(attackers).kills += 1

                    results += f" The attack also hits {', '.join(defenders_hit)}, each taking {splash_damage} damage!"

                    # Report deaths of defenders
                    deaths = [d.name for d in defenders if d.health <= 0]
                    if deaths:
                        results += f" {', '.join(deaths)} {'are' if len(deaths) > 1 else 'is'} killed in the attack!"
            else:
                results = f"attempts to coordinate an attack on {target.name}, but the attack fails!"

                # Normal failure: minimal damage
                if not critical:
                    minor_damage = random.randint(5, 15)
                    target.health -= minor_damage
                    results += f" The team only manages to deal {minor_damage} damage."

                # Critical failure: counter-attack
                if critical:
                    results += f" {target.name} and {len(defenders)} allies counter-attack!"

                    # Distribute damage to attackers
                    counter_damage = random.randint(15, 30)
                    for attacker in attackers:
                        attacker.health -= counter_damage

                        # Check for death
                        if attacker.health <= 0:
                            attacker.is_alive = False
                            self.killed_this_round.append(attacker)

                            # Award kill to target
                            target.kills += 1

                    results += f" Each attacker takes {counter_damage} damage in the counter-attack!"

                    # Report deaths
                    deaths = [a.name for a in attackers if a.health <= 0]
                    if deaths:
                        results += f" {', '.join(deaths)} {'are' if len(deaths) > 1 else 'is'} killed in the failed attack!"

        elif action_type == "team_attack_team":
            target_team = action_data.get("target_team")

            if not target_team or not target_team.is_active():
                return f"plans an attack on another team, but can't locate them."

            # Find regions where both teams have members
            attacking_regions = set(p.current_region.name for p in alive_members)
            defending_regions = set(p.current_region.name for p in target_team.get_alive_players())

            common_regions = attacking_regions.intersection(defending_regions)

            if not common_regions:
                return f"plans to attack Team {target_team.team_id + 1}, but they're not in the same regions."

            # Choose primary battle region
            battle_region_name = random.choice(list(common_regions))

            # Get attackers and defenders in that region
            attackers = [p for p in alive_members if p.current_region.name == battle_region_name]
            defenders = [p for p in target_team.get_alive_players() if p.current_region.name == battle_region_name]

            # Calculate team powers
            attack_power = sum(p.get_combat_power() for p in attackers)
            defense_power = sum(p.get_combat_power() for p in defenders)

            # Adjust for team morale
            attack_power = attack_power * (1 + (team.morale - 50) / 100)
            defense_power = defense_power * (1 + (target_team.morale - 50) / 100)

            # Compute success chance
            power_ratio = attack_power / max(1, defense_power)
            success_chance = min(90, 50 + int((power_ratio - 1) * 30))

            if success:
                results = f"launches a coordinated assault against Team {target_team.team_id + 1} in the {battle_region_name}!"

                # Calculate base damage
                base_damage = random.randint(20, 35)

                # Apply damage to all defenders
                casualties = []
                wounded = []

                for defender in defenders:
                    # Adjust damage based on defender's items
                    actual_damage = base_damage
                    if any(i.type == "defense" for i in defender.items):
                        actual_damage = max(10, int(actual_damage * 0.7))  # 30% reduction, minimum 10

                    defender.health -= actual_damage

                    if defender.health <= 0:
                        defender.is_alive = False
                        self.killed_this_round.append(defender)
                        casualties.append(defender.name)

                        # Distribute kill credit randomly among attackers
                        if attackers:
                            random.choice(attackers).kills += 1
                    else:
                        wounded.append(defender.name)

                # Report results
                if casualties:
                    results += f" {len(casualties)} enemies killed: {', '.join(casualties)}!"
                if wounded:
                    results += f" {len(wounded)} enemies wounded: {', '.join(wounded)}."

                # Critical success: loot and morale effects
                if critical:
                    # Loot from casualties
                    looted_items = []
                    for dead_player in [p for p in defenders if p.health <= 0]:
                        # Distribute items
                        for item in dead_player.items[:]:
                            if attackers:
                                recipient = random.choice(attackers)
                                recipient.add_item(item)
                                dead_player.remove_item(item)
                                looted_items.append(item.name)

                        # Distribute weapons
                        for weapon in dead_player.weapons[:]:
                            if attackers:
                                recipient = random.choice(attackers)
                                recipient.add_weapon(weapon)
                                dead_player.remove_weapon(weapon)
                                looted_items.append(weapon.name)

                    if looted_items:
                        results += f" The team loots valuable supplies: {', '.join(looted_items)}!"

                    # Morale shifts
                    team.morale = min(100, team.morale + 15)
                    target_team.morale = max(0, target_team.morale - 15)

                    results += f" Team {team.team_id + 1}'s morale increases while Team {target_team.team_id + 1}'s morale plummets!"
            else:
                results = f"attempts to attack Team {target_team.team_id + 1} in the {battle_region_name}, but the assault fails!"

                # Normal failure: minimal damage
                if not critical:
                    minor_damage = random.randint(5, 15)
                    for defender in defenders:
                        defender.health -= minor_damage

                    results += f" Each defender only takes {minor_damage} damage."

                # Critical failure: devastating counter-attack
                if critical:
                    results += " The defenders were prepared and launch a devastating counter-attack!"

                    # Counter-attack damage
                    counter_damage = random.randint(20, 35)
                    attacker_casualties = []

                    for attacker in attackers:
                        attacker.health -= counter_damage

                        if attacker.health <= 0:
                            attacker.is_alive = False
                            self.killed_this_round.append(attacker)
                            attacker_casualties.append(attacker.name)

                            # Award kills to random defenders
                            if defenders:
                                random.choice(defenders).kills += 1

                    results += f" Each attacker takes {counter_damage} damage in the counter-attack!"

                    if attacker_casualties:
                        results += f" {len(attacker_casualties)} team members killed: {', '.join(attacker_casualties)}!"

                    # Morale shift
                    team.morale = max(0, team.morale - 15)
                    target_team.morale = min(100, target_team.morale + 15)

                    results += f" Team {team.team_id + 1}'s morale falls while Team {target_team.team_id + 1}'s morale rises!"

        elif action_type == "team_alliance":
            target_team = action_data.get("target_team")

            if not target_team or not target_team.is_active():
                return f"looks for Team {target_team.team_id + 1 if target_team else 'another team'} to ally with, but can't find them."

            # Check if any team members can contact the other team
            can_contact = False
            for our_player in alive_members:
                for their_player in target_team.get_alive_players():
                    if our_player.current_region == their_player.current_region:
                        can_contact = True
                        break

            if not can_contact:
                return f"wants to ally with Team {target_team.team_id + 1}, but they're not in the same region."

            # Calculate alliance acceptance
            # More likely if both teams are weak
            our_strength = len(alive_members)
            their_strength = len(target_team.get_alive_players())

            # Teams are more willing to ally if they're similar strength or weaker
            strength_factor = 0
            if their_strength <= our_strength:
                strength_factor = 20
            elif their_strength >= our_strength * 2:
                strength_factor = -20

            # More likely if there are still many teams/players alive
            remaining_teams = len(self.get_active_teams())
            remaining_players = len(self.get_all_alive_players())

            # Teams more willing to ally when many threats remain
            remaining_factor = min(30, (remaining_teams - 2) * 10)

            alliance_chance = 50 + strength_factor + remaining_factor
            alliance_chance = max(10, min(90, alliance_chance))

            if success:
                # Alliance formed
                team.form_alliance(target_team)

                results = f"forms an alliance with Team {target_team.team_id + 1}!"

                # Critical success: share supplies
                if critical:
                    # Share items between teams
                    our_shared = []
                    their_shared = []

                    # We share 1-2 items
                    available_items = []
                    for player in alive_members:
                        available_items.extend([(item, player) for item in player.items])

                    if available_items:
                        num_to_share = min(2, len(available_items))
                        for _ in range(num_to_share):
                            if available_items:
                                item, owner = random.choice(available_items)
                                available_items.remove((item, owner))

                                # Give to random member of other team
                                if target_team.get_alive_players():
                                    recipient = random.choice(target_team.get_alive_players())
                                    item_copy = copy.deepcopy(item)
                                    recipient.add_item(item_copy)
                                    our_shared.append(item.name)

                    # They share 1-2 items
                    their_available = []
                    for player in target_team.get_alive_players():
                        their_available.extend([(item, player) for item in player.items])

                    if their_available:
                        num_to_receive = min(2, len(their_available))
                        for _ in range(num_to_receive):
                            if their_available:
                                item, owner = random.choice(their_available)
                                their_available.remove((item, owner))

                                # Give to random member of our team
                                if alive_members:
                                    recipient = random.choice(alive_members)
                                    item_copy = copy.deepcopy(item)
                                    recipient.add_item(item_copy)
                                    their_shared.append(item.name)

                    if our_shared or their_shared:
                        results += " To seal the alliance, the teams exchange supplies:"
                        if our_shared:
                            results += f" Team {team.team_id + 1} shares {', '.join(our_shared)}."
                        if their_shared:
                            results += f" Team {target_team.team_id + 1} shares {', '.join(their_shared)}."

                    # Healing boost from alliance
                    healing = random.randint(15, 25)
                    for player in alive_members:
                        player.health = min(100, player.health + healing)
                    for player in target_team.get_alive_players():
                        player.health = min(100, player.health + healing)

                    results += f" Both teams gain {healing} health from the morale boost!"
            else:
                results = f"offers an alliance to Team {target_team.team_id + 1}, but they decline."

                # Critical failure: betrayal
                if critical:
                    results += " In fact, Team {target_team.team_id + 1} sees this as an opportunity to attack!"

                    # Ambush damage
                    ambush_damage = random.randint(15, 30)
                    casualties = []

                    # Find members in contact regions
                    vulnerable_members = []
                    for our_player in alive_members:
                        for their_player in target_team.get_alive_players():
                            if our_player.current_region == their_player.current_region:
                                vulnerable_members.append(our_player)
                                break

                    if vulnerable_members:
                        for member in vulnerable_members:
                            member.health -= ambush_damage

                            if member.health <= 0:
                                member.is_alive = False
                                self.killed_this_round.append(member)
                                casualties.append(member.name)

                                # Award kill to random member of target team
                                if target_team.get_alive_players():
                                    random.choice(target_team.get_alive_players()).kills += 1

                        results += f" {len(vulnerable_members)} team members are ambushed, taking {ambush_damage} damage each!"

                        if casualties:
                            results += f" {', '.join(casualties)} {'are' if len(casualties) > 1 else 'is'} killed in the betrayal!"

                        # Morale impact
                        team.morale = max(0, team.morale - 20)
                        results += f" Team {team.team_id + 1}'s morale plummets!"

        elif action_type == "team_scout":
            # Spread out team to scout arena
            regions_spotted = {}
            intel_gathered = []

            for player in alive_members:
                # Each player scouts their region and possibly adjacent ones
                current_region = player.current_region
                scouted_regions = [current_region.name]

                # 50% chance to scout adjacent regions
                if random.random() < 0.5:
                    for adjacent in current_region.connections:
                        if random.random() < 0.7:  # 70% chance per adjacent region
                            scouted_regions.append(adjacent)

                # Record players spotted in each region
                for region_name in scouted_regions:
                    if region_name not in regions_spotted:
                        regions_spotted[region_name] = []

                    # Find players in that region
                    for p in self.get_region_players(region_name):
                        # Skip teammates and self
                        if p.team_id != team.team_id and p not in regions_spotted[region_name]:
                            regions_spotted[region_name].append(p)

                            # Update player's known players
                            player.known_players[p.id] = region_name

            if success:
                results = f"spreads out to scout the arena."

                # Report intel
                for region_name, spotted in regions_spotted.items():
                    if spotted:
                        players_text = ", ".join([f"{p.name} (Team {p.team_id + 1})" for p in spotted])
                        intel_gathered.append(f"Spotted in {region_name}: {players_text}")

                if intel_gathered:
                    results += " Intel gathered:\n- " + "\n- ".join(intel_gathered)
                else:
                    results += " No other tributes spotted."

                # Critical success: find supplies while scouting
                if critical:
                    supplies_found = []

                    for player in alive_members:
                        # 70% chance to find something
                        if random.random() < 0.7:
                            if random.random() < 0.6:  # 60% food/water, 40% item
                                food_gain = random.randint(15, 30)
                                water_gain = random.randint(15, 30)
                                player.food = min(100, player.food + food_gain)
                                player.water = min(100, player.water + water_gain)
                                supplies_found.append(f"{player.name} finds food and water")
                            else:
                                item = copy.deepcopy(random.choice(self.available_items))
                                player.add_item(item)
                                supplies_found.append(f"{player.name} finds a {item.name}")

                    if supplies_found:
                        results += "\nWhile scouting, team members find supplies:\n- " + "\n- ".join(supplies_found)
            else:
                results = f"attempts to scout but gathers limited intel."

                # Limited intel on failure
                if intel_gathered:
                    results += " Partial intel gathered:\n- " + "\n- ".join(intel_gathered[:1])

                # Critical failure: spotted
                if critical:
                    results += " While scouting, the team is spotted!"

                    # Random team member encounters danger
                    unlucky_member = random.choice(alive_members)

                    # Check for enemies in same region
                    enemies = [p for p in unlucky_member.current_region.players if p != unlucky_member and p.is_alive
                               and p.team_id != team.team_id and p.id not in unlucky_member.alliances]

                    if enemies:
                        enemy = random.choice(enemies)
                        damage = random.randint(15, 30)
                        unlucky_member.health -= damage
                        results += f" {enemy.name} ambushes {unlucky_member.name}, dealing {damage} damage!"

                        # Check for death
                        if unlucky_member.health <= 0:
                            unlucky_member.is_alive = False
                            self.killed_this_round.append(unlucky_member)
                            enemy.kills += 1
                            results += f" {unlucky_member.name} is killed while scouting!"
                    else:
                        # Natural hazard
                        damage = random.randint(10, 25)
                        unlucky_member.health -= damage
                        results += f" {unlucky_member.name} is injured by a natural hazard, taking {damage} damage!"

        elif action_type == "team_craft":
            # Team crafting - pool resources to create better items
            crafting_power = sum(p.intelligence for p in alive_members)

            if success:
                results = f"combines skills to craft useful supplies."

                # Determine what to craft based on team needs
                team_health = sum(p.health for p in alive_members) / len(alive_members)
                team_food = sum(p.food for p in alive_members) / len(alive_members)
                team_water = sum(p.water for p in alive_members) / len(alive_members)

                items_crafted = []

                # Craft based on greatest need
                if team_health < 50:
                    # Medical supplies
                    for _ in range(max(1, len(alive_members) // 2)):
                        item = copy.deepcopy(next((i for i in self.available_items if i.type == "healing"), None))
                        if item:
                            recipient = min(alive_members, key=lambda p: p.health)
                            recipient.add_item(item)
                            items_crafted.append(f"{item.name} (for {recipient.name})")

                elif team_food < 30 or team_water < 30:
                    # Food and water
                    for _ in range(max(1, len(alive_members) // 2)):
                        if team_food < team_water:
                            item = copy.deepcopy(next((i for i in self.available_items if i.type == "food"), None))
                            if item:
                                recipient = min(alive_members, key=lambda p: p.food)
                                recipient.add_item(item)
                                items_crafted.append(f"{item.name} (for {recipient.name})")
                        else:
                            item = copy.deepcopy(next((i for i in self.available_items if i.type == "water"), None))
                            if item:
                                recipient = min(alive_members, key=lambda p: p.water)
                                recipient.add_item(item)
                                items_crafted.append(f"{item.name} (for {recipient.name})")

                elif not any(p.weapons for p in alive_members):
                    # Weapons for defenseless team
                    for p in alive_members:
                        if not p.weapons:
                            weapon = copy.deepcopy(
                                random.choice([w for w in self.available_weapons if w.type == "melee"]))
                            p.add_weapon(weapon)
                            items_crafted.append(f"{weapon.name} (for {p.name})")

                else:
                    # Balanced crafting - mix of items
                    for _ in range(max(1, len(alive_members) // 2)):
                        if random.random() < 0.7:  # 70% items, 30% weapons
                            item = copy.deepcopy(random.choice(self.available_items))
                            recipient = random.choice(alive_members)
                            recipient.add_item(item)
                            items_crafted.append(f"{item.name} (for {recipient.name})")
                        else:
                            weapon = copy.deepcopy(random.choice([w for w in self.available_weapons if w.damage <= 20]))
                            recipient = random.choice(alive_members)
                            recipient.add_weapon(weapon)
                            items_crafted.append(f"{weapon.name} (for {recipient.name})")

                if items_crafted:
                    results += " The team crafts:\n- " + "\n- ".join(items_crafted)
                else:
                    results += " But they lack the necessary materials to craft anything useful."

                # Critical success: exceptional crafting
                if critical:
                    # Craft one exceptional item
                    if random.random() < 0.6:  # 60% weapon, 40% item
                        weapon = copy.deepcopy(random.choice([w for w in self.available_weapons if w.damage >= 25]))
                        recipient = random.choice(alive_members)
                        recipient.add_weapon(weapon)
                        results += f"\nIncredible success! The team also crafts a powerful {weapon.name} for {recipient.name}!"
                    else:
                        item_types = ["healing", "defense"]
                        item_type = random.choice(item_types)
                        item = copy.deepcopy(next((i for i in self.available_items if i.type == item_type), None))
                        if item:
                            recipient = random.choice(alive_members)
                            recipient.add_item(item)
                            results += f"\nIncredible success! The team also crafts a high-quality {item.name} for {recipient.name}!"
            else:
                results = f"attempts to craft supplies but has limited success."

                # Minor success on normal failure
                if not critical:
                    item = copy.deepcopy(random.choice([i for i in self.available_items if i.effect_value <= 20]))
                    recipient = random.choice(alive_members)
                    recipient.add_item(item)
                    results += f" They only manage to create a simple {item.name} for {recipient.name}."

                # Critical failure: crafting accident
                if critical:
                    results += " The crafting attempt goes terribly wrong!"

                    # Random team member is injured
                    victim = random.choice(alive_members)
                    damage = random.randint(10, 25)
                    victim.health -= damage
                    results += f" {victim.name} is injured in a crafting accident, taking {damage} damage!"

                    # Check for death
                    if victim.health <= 0:
                        victim.is_alive = False
                        self.killed_this_round.append(victim)
                        results += f" {victim.name} dies from the crafting accident!"

        elif action_type == "team_train":
            # Team training to improve combat effectiveness
            if success:
                results = f"conducts combat training together."

                # Temporary combat boost (status effect)
                duration = 3
                for player in alive_members:
                    player.add_status_effect("strengthened", duration)

                # Energy cost
                energy_cost = random.randint(10, 20)
                for player in alive_members:
                    player.energy = max(0, player.energy - energy_cost)

                results += f" All members gain increased combat effectiveness for {duration} rounds (used {energy_cost} energy)."

                # Critical success: weapon mastery
                if critical:
                    # Each member with a weapon gets better with it
                    weapon_masters = []
                    for player in alive_members:
                        if player.weapons:
                            weapon = random.choice(player.weapons)
                            # Boost weapon effectiveness (in this simulation just increase durability)
                            weapon.durability += random.randint(2, 5)
                            weapon_masters.append(f"{player.name} (with {weapon.name})")

                    if weapon_masters:
                        results += "\nExceptional training! The following members master their weapons:\n- " + "\n- ".join(
                            weapon_masters)

                    # Health boost from good exercise
                    health_gain = random.randint(5, 15)
                    for player in alive_members:
                        player.health = min(100, player.health + health_gain)

                    results += f"\nThe rigorous training also improves team health by {health_gain}."
            else:
                results = f"attempts to train but the session isn't very effective."

                # Energy cost with no benefit
                energy_cost = random.randint(15, 25)
                for player in alive_members:
                    player.energy = max(0, player.energy - energy_cost)

                results += f" The team uses {energy_cost} energy with little benefit."

                # Critical failure: training accident
                if critical:
                    results += " A serious training accident occurs!"

                    # Random team members are injured
                    num_injured = random.randint(1, min(len(alive_members), 2))
                    victims = random.sample(alive_members, num_injured)

                    for victim in victims:
                        damage = random.randint(10, 25)
                        victim.health -= damage
                        results += f" {victim.name} is injured during training, taking {damage} damage!"

                        # Check for death (rare but possible)
                        if victim.health <= 0:
                            victim.is_alive = False
                            self.killed_this_round.append(victim)
                            results += f" {victim.name} dies from the training accident!"

        elif action_type == "team_betray":
            target_team = action_data.get("target_team")

            if not target_team or not target_team.is_active() or target_team.team_id not in team.alliances:
                return f"considers betrayal, but has no allied team to betray."

            # Check if teams are in contact
            teams_in_contact = False
            for our_player in alive_members:
                for their_player in target_team.get_alive_players():
                    if our_player.current_region == their_player.current_region:
                        teams_in_contact = True
                        break

            if not teams_in_contact:
                return f"plans to betray Team {target_team.team_id + 1}, but they're not in the same region."

            # Betray the alliance
            team.break_alliance(target_team)
            results = f"breaks alliance with Team {target_team.team_id + 1} and launches a surprise attack!"

            # Betrayal attack has advantage
            surprise_factor = 1.5  # 50% damage bonus

            # Find groups in contact for attack
            attack_groups = {}
            for our_player in alive_members:
                for their_player in target_team.get_alive_players():
                    if our_player.current_region == their_player.current_region:
                        region_name = our_player.current_region.name
                        if region_name not in attack_groups:
                            attack_groups[region_name] = {"attackers": [], "defenders": []}

                        if our_player not in attack_groups[region_name]["attackers"]:
                            attack_groups[region_name]["attackers"].append(our_player)

                        if their_player not in attack_groups[region_name]["defenders"]:
                            attack_groups[region_name]["defenders"].append(their_player)

            if success:
                casualties = []
                wounded = []

                # Process each attack group
                for region_name, group in attack_groups.items():
                    attackers = group["attackers"]
                    defenders = group["defenders"]

                    # Skip if no attackers or defenders
                    if not attackers or not defenders:
                        continue

                    # Calculate base damage
                    base_damage = random.randint(20, 35)
                    damage = int(base_damage * surprise_factor)

                    results += f"\nIn the {region_name}, {len(attackers)} attackers ambush {len(defenders)} defenders!"

                    # Apply damage to defenders
                    for defender in defenders:
                        defender.health -= damage

                        if defender.health <= 0:
                            defender.is_alive = False
                            self.killed_this_round.append(defender)
                            casualties.append(f"{defender.name} (in {region_name})")

                            # Award kill to random attacker
                            if attackers:
                                random.choice(attackers).kills += 1
                        else:
                            wounded.append(f"{defender.name} (-{damage} HP, in {region_name})")

                # Report results
                if casualties:
                    results += f"\nKilled in the betrayal: {', '.join(casualties)}"
                if wounded:
                    results += f"\nWounded in the betrayal: {', '.join(wounded)}"

                # Critical success: perfect betrayal
                if critical:
                    # Loot from casualties
                    looted = []
                    for casualty_name in casualties:
                        casualty_name = casualty_name.split(" (")[0]  # Remove the region part
                        dead_player = next((p for p in target_team.players if p.name == casualty_name), None)

                        if dead_player and (dead_player.items or dead_player.weapons):
                            # Distribute all items
                            for item in dead_player.items[:]:
                                if alive_members:
                                    recipient = random.choice(alive_members)
                                    recipient.add_item(item)
                                    dead_player.remove_item(item)
                                    looted.append(item.name)

                            # Distribute all weapons
                            for weapon in dead_player.weapons[:]:
                                if alive_members:
                                    recipient = random.choice(alive_members)
                                    recipient.add_weapon(weapon)
                                    dead_player.remove_weapon(weapon)
                                    looted.append(weapon.name)

                    if looted:
                        results += f"\nLooted from the dead: {', '.join(looted)}"

                    # Fleeing defenders
                    fled = []
                    for region_name, group in attack_groups.items():
                        defenders = [d for d in group["defenders"] if d.is_alive]

                        for defender in defenders:
                            # 70% chance to flee
                            if random.random() < 0.7:
                                # Flee to random connected region
                                escape_regions = [self.regions[r] for r in self.regions[region_name].connections]
                                if escape_regions:
                                    escape_region = random.choice(escape_regions)
                                    self.move_player(defender, escape_region)
                                    fled.append(f"{defender.name} (to {escape_region.name})")

                    if fled:
                        results += f"\nFled in terror: {', '.join(fled)}"

                    # Morale shifts
                    team.morale = min(100, team.morale + 10)
                    target_team.morale = max(0, target_team.morale - 25)

                    results += f"\nTeam {team.team_id + 1}'s morale increases, while Team {target_team.team_id + 1}'s morale plummets!"
            else:
                results = f"attempts to betray Team {target_team.team_id + 1}, but they were suspicious and prepared!"

                # Process each attack group
                for region_name, group in attack_groups.items():
                    attackers = group["attackers"]
                    defenders = group["defenders"]

                    # Skip if no attackers or defenders
                    if not attackers or not defenders:
                        continue

                    # Some damage still occurs
                    damage = random.randint(10, 20)

                    # Apply reduced damage to defenders
                    for defender in defenders:
                        defender.health -= damage

                        if defender.health <= 0:
                            defender.is_alive = False
                            self.killed_this_round.append(defender)

                            # Award kill to random attacker
                            if attackers:
                                random.choice(attackers).kills += 1

                    results += f"\nIn the {region_name}, the betrayal only deals {damage} damage to each defender."

                # Critical failure: counter-betrayal
                if critical:
                    results += "\nThe betrayal backfires catastrophically! They counter-attack with full force!"

                    # Counter-attack in each region
                    for region_name, group in attack_groups.items():
                        attackers = group["attackers"]
                        defenders = [d for d in group["defenders"] if d.is_alive]

                        if not attackers or not defenders:
                            continue

                        # Devastating counter-attack
                        counter_damage = random.randint(25, 40)

                        results += f"\nIn the {region_name}, {len(defenders)} defenders counter-attack, dealing {counter_damage} damage to each attacker!"

                        # Apply damage to attackers
                        attacker_casualties = []
                        for attacker in attackers:
                            attacker.health -= counter_damage

                            if attacker.health <= 0:
                                attacker.is_alive = False
                                self.killed_this_round.append(attacker)
                                attacker_casualties.append(attacker.name)

                                # Award kill to random defender
                                if defenders:
                                    random.choice(defenders).kills += 1

                        if attacker_casualties:
                            results += f" {', '.join(attacker_casualties)} {'are' if len(attacker_casualties) > 1 else 'is'} killed in the failed betrayal!"

                    # Morale shifts
                    team.morale = max(0, team.morale - 25)
                    target_team.morale = min(100, target_team.morale + 10)

                    results += f"\nTeam {team.team_id + 1}'s morale plummets, while Team {target_team.team_id + 1}'s morale rises!"

        elif action_type == "team_move":
            target_region_name = action_data.get("target_region")

            if not target_region_name or target_region_name not in self.regions:
                return f"plans to move as a group, but the destination is unclear."

            # Check if team is together
            regions = set(player.current_region.name for player in alive_members)
            team_together = len(regions) == 1

            if not team_together:
                return f"tries to move together to {target_region_name}, but the team is separated."

            current_region = alive_members[0].current_region

            # Check if target region is accessible
            if target_region_name not in current_region.connections:
                return f"wants to travel to {target_region_name}, but it's not accessible from {current_region.name}."

            target_region = self.regions[target_region_name]

            if success:
                # Move whole team
                for player in alive_members:
                    self.move_player(player, target_region)

                results = f"moves as a group from {current_region.name} to {target_region_name}."

                # Check region conditions
                if target_region.condition != "normal":
                    if target_region.condition == "fire":
                        damage = random.randint(10, 20)
                        for player in alive_members:
                            player.health -= damage
                        results += f" The area is on fire! Each team member takes {damage} damage!"
                    elif target_region.condition == "fog":
                        for player in alive_members:
                            player.add_status_effect("poisoned", 2)
                        results += f" The area is filled with poisonous fog! All team members are poisoned!"
                    elif target_region.condition == "flood":
                        damage = random.randint(5, 15)
                        for player in alive_members:
                            player.health -= damage
                        results += f" The area is flooded! Each team member takes {damage} damage from the water!"

                # Report other players in region
                other_players = []
                for player in target_region.players:
                    if player.is_alive and player.team_id != team.team_id:
                        other_players.append(f"{player.name} (Team {player.team_id + 1})")

                if other_players:
                    results += f" The team spots other tributes in the area: {', '.join(other_players)}"

                # Critical success: find supplies
                if critical:
                    results += f" The move was perfectly timed and executed!"

                    # Find supplies in new region
                    supplies_found = []
                    for player in alive_members:
                        if random.random() < 0.7:  # 70% chance to find something
                            if random.random() < 0.6:  # 60% resources, 40% item
                                food_gain = random.randint(15, 25)
                                water_gain = random.randint(15, 25)
                                player.food = min(100, player.food + food_gain)
                                player.water = min(100, player.water + water_gain)
                                supplies_found.append(f"{player.name} finds food and water")
                            else:
                                item = copy.deepcopy(random.choice(self.available_items))
                                player.add_item(item)
                                supplies_found.append(f"{player.name} finds a {item.name}")

                    if supplies_found:
                        results += "\nTeam members find supplies in the new area:\n- " + "\n- ".join(supplies_found)
            else:
                # Only some members make it
                successful_movers = []
                for player in alive_members:
                    if random.random() < 0.7:  # 70% chance to make it
                        self.move_player(player, target_region)
                        successful_movers.append(player.name)

                if successful_movers:
                    results = f"attempts to move from {current_region.name} to {target_region_name}, but only {', '.join(successful_movers)} make it."
                else:
                    results = f"attempts to move from {current_region.name} to {target_region_name}, but gets lost and stays put."

                # Critical failure: team split and hazard
                if critical:
                    results += " The move goes terribly wrong!"

                    # Random hazard affects separated members
                    hazard_victims = [p for p in alive_members if p.name not in successful_movers]

                    if hazard_victims:
                        damage = random.randint(15, 30)
                        casualties = []

                        for victim in hazard_victims:
                            victim.health -= damage

                            if victim.health <= 0:
                                victim.is_alive = False
                                self.killed_this_round.append(victim)
                                casualties.append(victim.name)

                        results += f" {len(hazard_victims)} separated members encounter a hazard and take {damage} damage each!"

                        if casualties:
                            results += f" {', '.join(casualties)} {'die' if len(casualties) > 1 else 'dies'} from the hazard!"

                    # Team coordination suffers
                    team.morale = max(0, team.morale - 15)
                    results += f" Team {team.team_id + 1}'s morale is shaken by the failed movement."

        return results

    async def run_action_phase(self):
        """Run the action phase where players choose and execute actions"""
        time_of_day = "Night" if self.is_night else "Day"
        status_message = await self.ctx.send(f"**{time_of_day} {self.day} - Round {self.round}**")

        # Process team actions first
        for team in self.get_active_teams():
            if len(team.get_alive_players()) <= 1:
                continue  # Skip solo players - they'll be handled individually

            # Get team action options
            action_options = self.get_team_actions(team)

            # Show options to team
            action_descriptions = [a[0] for a in action_options[:10]]  # Limit to 10 options

            # Find a team member to make the choice
            chooser = None
            for player in team.get_alive_players():
                # Priority to real players over bots
                if player.id >= 10000:  # Assumed to be a bot
                    continue
                chooser = player
                break

            if not chooser:
                # All bots, pick random chooser
                chooser = random.choice(team.get_alive_players())

            try:
                await status_message.edit(
                    content=f"{status_message.content}\nTeam {team.team_id + 1} is choosing their action...")
            except:
                pass

            # Get choice from player or random for bots
            selected_index = 0

            if chooser.id >= 10000 or self.is_test:  # Bot or test mode
                # Make a strategic choice
                selected_index = random.randint(0, min(9, len(action_options) - 1))
            else:
                try:
                    # Use your bot's paginator or replace with a custom menu
                    selected_index = await self.ctx.bot.paginator.Choose(
                        entries=action_descriptions,
                        return_index=True,
                        title=f"Choose a team action for Team {team.team_id + 1}"
                    ).paginate(self.ctx, location=chooser.user)
                except:
                    # Fallback to random choice
                    selected_index = random.randint(0, min(9, len(action_options) - 1))

            # Process the selected action
            action_text, action_data = action_options[selected_index]
            action_type = action_data.get("type", "")

            # Execute action and get results
            result_text = self.process_team_action(team, action_type, action_data)

            # Create team action embed
            color = team.get_color()
            embed = Embed(
                title=f"Team {team.team_id + 1} - {time_of_day} {self.day}",
                color=color
            )

            # List team members
            member_list = []
            for player in team.get_alive_players():
                health_emoji = "❤️" if player.health > 50 else "💔"
                member_list.append(f"{player.name} {health_emoji} {player.health}HP")

            if member_list:
                embed.add_field(name="Team Members", value="\n".join(member_list), inline=False)

            # Add action and result
            embed.add_field(name="Action", value=action_text, inline=False)
            embed.add_field(name="Result", value=result_text, inline=False)

            await self.ctx.send(embed=embed)

            # Check for deaths from action
            await self.update_game_state()

        # Now process individual actions for solo players
        solos = []
        for player in self.get_all_alive_players():
            teammates = self.get_player_teammates(player)
            if not teammates:
                solos.append(player)

        for player in solos:
            # Skip if player died during team phases
            if not player.is_alive:
                continue

            # Get action options
            action_options = self.get_solo_actions(player)

            # Show options to player
            action_descriptions = [a[0] for a in action_options[:10]]  # Limit to 10 options

            try:
                await status_message.edit(
                    content=f"{status_message.content}\n{player.name} is choosing their action...")
            except:
                pass

            # Get choice from player or random for bots
            selected_index = 0

            if player.id >= 10000 or self.is_test:  # Bot or test mode
                # Make a strategic choice
                if player.health < 30:
                    # Prioritize healing
                    for i, (_, data) in enumerate(action_options[:10]):
                        if data.get("type") in ["use_item", "heal", "rest"] or "heal" in data.get("description",
                                                                                                  "").lower():
                            selected_index = i
                            break
                elif player.food < 20:
                    # Prioritize food
                    for i, (_, data) in enumerate(action_options[:10]):
                        if data.get("type") in ["hunt", "gather"] or "food" in data.get("description", "").lower():
                            selected_index = i
                            break
                elif player.water < 20:
                    # Prioritize water
                    for i, (_, data) in enumerate(action_options[:10]):
                        if data.get("type") in ["water", "drink"] or "water" in data.get("description", "").lower():
                            selected_index = i
                            break
                else:
                    # Random choice with weight toward offensive actions
                    weights = []
                    for i, (_, data) in enumerate(action_options[:10]):
                        if data.get("type") in ["attack", "ambush"]:
                            weights.append(3)  # Higher weight for attacks
                        elif data.get("type") in ["move", "search"]:
                            weights.append(2)  # Medium weight for exploration
                        else:
                            weights.append(1)  # Base weight

                    if len(weights) < 10:
                        weights.extend([1] * (10 - len(weights)))

                    # Choose based on weights
                    selected_index = \
                    random.choices(range(min(10, len(action_options))), weights=weights[:min(10, len(action_options))])[
                        0]
            else:
                try:
                    # Use your bot's paginator or replace with a custom menu
                    selected_index = await self.ctx.bot.paginator.Choose(
                        entries=action_descriptions,
                        return_index=True,
                        title="Choose your action"
                    ).paginate(self.ctx, location=player.user)
                except:
                    # Fallback to random choice
                    selected_index = random.randint(0, min(9, len(action_options) - 1))

            # Process the selected action
            action_text, action_data = action_options[selected_index]
            action_type = action_data.get("type", "")

            # Execute action and get results
            result_text = self.process_solo_action(player, action_type, action_data)

            # Create solo action embed
            team = self.get_player_team(player)
            color = team.get_color() if team else Color.default()

            embed = Embed(
                title=f"{player.name} - {time_of_day} {self.day}",
                color=color
            )

            # Add player stats
            stats = [
                f"❤️ Health: {player.health}/100",
                f"🍗 Food: {player.food}/100",
                f"💧 Water: {player.water}/100",
                f"📍 Location: {player.current_region.emoji} {player.current_region.name}"
            ]

            embed.add_field(name="Stats", value="\n".join(stats), inline=False)

            # Add action and result
            embed.add_field(name="Action", value=action_text, inline=False)
            embed.add_field(name="Result", value=result_text, inline=False)

            # Add weapon and item info if available
            if player.weapons:
                weapon_text = "\n".join([str(w) for w in player.weapons])
                embed.add_field(name="Weapons", value=weapon_text, inline=True)

            if player.items:
                item_text = "\n".join([str(i) for i in player.items])
                embed.add_field(name="Items", value=item_text, inline=True)

            await self.ctx.send(embed=embed)

            # Check for deaths from action
            await self.update_game_state()

    async def update_game_state(self):
        """Update game state after each phase"""
        # Update needs for all living players
        for player in self.get_all_alive_players():
            player.update_needs()

            # Check for death from needs
            if player.health <= 0:
                player.is_alive = False
                self.killed_this_round.append(player)

        # Update status effects
        for player in [p for p in self.players if p.is_alive]:
            player.update_status_effects()

            # Check for death from status effects
            if not player.is_alive and player not in self.killed_this_round:
                self.killed_this_round.append(player)

        # Update region conditions
        for region in self.regions.values():
            region.update()

    async def show_status(self):
        """Show current game status"""
        embed = Embed(
            title=f"Arena Status - Day {self.day}",
            description=f"{'Night' if self.is_night else 'Day'} {self.day} - Round {self.round}",
            color=Color.blue()
        )

        # Count tributes by region
        region_counts = {}
        for region in self.regions.values():
            alive_count = len([p for p in region.players if p.is_alive])
            if alive_count > 0:
                region_counts[region.name] = alive_count

        # Add region information
        region_text = []
        for name, count in region_counts.items():
            region = self.regions[name]
            condition = f" {region.get_condition_emoji()}" if region.condition != "normal" else ""
            region_text.append(f"{region.emoji} {name}{condition}: {count} tributes")

        if region_text:
            embed.add_field(name="Regions", value="\n".join(region_text), inline=False)

        # Add team information
        for team in self.get_active_teams():
            alive_members = team.get_alive_players()
            if not alive_members:
                continue

            member_text = []
            for player in alive_members:
                health_status = "❤️" if player.health > 50 else "💔"
                member_text.append(f"{player.name}: {health_status} {player.health}HP, {player.kills} kills")

            embed.add_field(
                name=f"Team {team.team_id + 1} ({len(alive_members)} alive)",
                value="\n".join(member_text),
                inline=False
            )

        # Add kill leaders
        killers = sorted([p for p in self.players if p.kills > 0], key=lambda p: p.kills, reverse=True)[:5]
        if killers:
            kill_text = "\n".join([f"{p.name}: {p.kills} kills" for p in killers])
            embed.add_field(name="Top Killers", value=kill_text, inline=False)

        await self.ctx.send(embed=embed)

    async def run_game(self):
        """Main game loop"""
        try:
            # Setup game
            self.setup_game()
            await self.send_cast()

            # Initial bloodbath
            embed = Embed(
                title="🔥 THE HUNGER GAMES BEGIN 🔥",
                description="The tributes rise on their platforms. The countdown begins...\n\n60... 59... 58...",
                color=Color.gold()
            )
            await self.ctx.send(embed=embed)

            await asyncio.sleep(3)
            await self.run_bloodbath()

            # Game loop
            self.round = 1
            self.game_phase = "main"

            while len(self.get_active_teams()) > 1:
                # Start new day if needed
                if not self.is_night and self.round > 1:
                    self.day += 1

                # Toggle day/night
                self.is_night = not self.is_night

                # Run special event (30% chance)
                if random.random() < 0.3:
                    event_embed = await self.run_event()
                    if event_embed:
                        await self.ctx.send(embed=event_embed)

                # Run action phase
                await self.run_action_phase()

                # Run recap if any deaths
                if self.killed_this_round:
                    await self.run_daily_recap()

                # Show status every 2 rounds
                if self.round % 2 == 0:
                    await self.show_status()

                # Update round counter
                self.round += 1

                # Force finale if too many rounds
                if self.round > 30:
                    self.game_phase = "finale"
                    finale_embed = Embed(
                        title="🔥 FINALE 🔥",
                        description="Attention tributes! The Gamemakers have decided to end these games. The arena boundaries are shrinking to the Cornucopia. All tributes must converge there immediately!",
                        color=Color.red()
                    )
                    await self.ctx.send(embed=finale_embed)

                    # Force all players to Cornucopia
                    for player in self.get_all_alive_players():
                        self.move_player(player, "Cornucopia")

                # Check if we should stop
                if len(self.get_active_teams()) <= 1:
                    break

                # Brief pause between rounds
                await asyncio.sleep(2)

            # Game over - announce winner
            await self.announce_winner()

        except Exception as e:
            await self.ctx.send(f"Error in game: {e}")
            raise e

    async def announce_winner(self):
        """Announce the winner of the Hunger Games"""
        winner = next(iter(self.get_active_teams()), None)

        if winner:
            survivors = winner.get_alive_players()
            survivor_names = [p.mention for p in survivors]

            # Calculate stats
            total_kills = sum(p.kills for p in winner.players)

            embed = Embed(
                title="🏆 HUNGER GAMES WINNER 🏆",
                description=f"Team {winner.team_id + 1} has won the Hunger Games!",
                color=Color.gold()
            )

            # Add survivor information
            survivors_text = []
            for player in survivors:
                survivors_text.append(f"{player.mention} - {player.kills} kills")

            embed.add_field(name=f"Survivors", value="\n".join(survivors_text), inline=False)

            # Add team stats
            embed.add_field(name="Team Stats", value=f"Total Kills: {total_kills}", inline=False)

            # Add a congratulatory message
            embed.set_footer(text="Congratulations to the victors! May the odds be ever in your favor.")

            # If we have a survivor with avatar, set it as thumbnail
            if survivors and survivors[0].avatar:
                embed.set_thumbnail(url=survivors[0].avatar.url)
        else:
            # No winners (unlikely)
            embed = Embed(
                title="HUNGER GAMES ENDED",
                description="There are no survivors. The arena has claimed all tributes.",
                color=Color.dark_red()
            )

            embed.set_footer(text="A hollow victory for the Capitol.")

        await self.ctx.send(embed=embed)

        # Show final statistics
        await self.show_final_stats()

    async def show_final_stats(self):
        """Show detailed final statistics"""
        embed = Embed(
            title="📊 HUNGER GAMES STATISTICS 📊",
            color=Color.blue()
        )

        # Kill rankings
        kill_leaders = sorted([p for p in self.players if p.kills > 0], key=lambda p: p.kills, reverse=True)
        if kill_leaders:
            kill_text = []
            for i, player in enumerate(kill_leaders[:10]):
                medal = "🥇" if i == 0 else "🥈" if i == 1 else "🥉" if i == 2 else f"{i + 1}."
                kill_text.append(f"{medal} **{player.name}** - {player.kills} kills")

            embed.add_field(name="Top Killers", value="\n".join(kill_text), inline=False)

        # Team rankings
        team_stats = []
        for team in sorted(self.teams, key=lambda t: -sum(p.kills for p in t.players)):
            survivors = len(team.get_alive_players())
            total_kills = sum(p.kills for p in team.players)
            team_stats.append(f"Team {team.team_id + 1}: {total_kills} kills, {survivors} survivors")

        if team_stats:
            embed.add_field(name="Team Performance", value="\n".join(team_stats), inline=False)

        # Region statistics
        region_deaths = defaultdict(int)
        for player in self.players:
            if not player.is_alive and player.current_region:
                region_deaths[player.current_region.name] += 1

        if region_deaths:
            deadliest = sorted(region_deaths.items(), key=lambda x: -x[1])
            region_text = []
            for name, count in deadliest[:5]:
                region = self.regions[name]
                region_text.append(f"{region.emoji} {name}: {count} deaths")

            embed.add_field(name="Deadliest Regions", value="\n".join(region_text), inline=False)

        await self.ctx.send(embed=embed)


class HGGameCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.games = {}

    @commands.command(aliases=["hg"])
    async def hungergames(self, ctx):
        """Start a Hunger Games simulation"""
        if ctx.channel.id in self.games:
            return await ctx.send("A Hunger Games is already running in this channel!")

        # Create join view
        view = JoinView(
            Button(style=ButtonStyle.primary, label="Join the Hunger Games", emoji="🔥"),
            message="You've joined the Hunger Games!",
            timeout=120
        )
        view.joined.add(ctx.author)

        join_embed = Embed(
            title="🔥 THE HUNGER GAMES 🔥",
            description="Click the button to join the Hunger Games!\nThe games will begin in 2 minutes.",
            color=Color.gold()
        )
        join_embed.set_footer(text="May the odds be ever in your favor.")

        join_message = await ctx.send(embed=join_embed, view=view)
        self.games[ctx.channel.id] = "joining"

        # Wait for joins
        await asyncio.sleep(120)
        view.stop()

        players = list(view.joined)
        if len(players) < 2:
            del self.games[ctx.channel.id]
            return await ctx.send("Not enough players joined. Hunger Games cancelled.")

        # Start the game
        game = HungerGames(ctx, players)
        self.games[ctx.channel.id] = game

        try:
            await game.run_game()
        except Exception as e:
            await ctx.send(f"Error in the Hunger Games: {e}")
            raise e
        finally:
            if ctx.channel.id in self.games:
                del self.games[ctx.channel.id]

    @commands.command(aliases=["hgtest"])
    async def hungergamestest(self, ctx, num_bots: int = 8):
        """Start a test Hunger Games with bots"""
        if ctx.channel.id in self.games:
            return await ctx.send("A Hunger Games is already running in this channel!")

        # Validate bot count
        num_bots = max(1, min(num_bots, 23))

        try:
            await ctx.send(f"Starting a test Hunger Games with you and {num_bots} bots!")

            # Start the game
            game = HungerGames(ctx, [ctx.author], is_test=True, num_bots=num_bots, force_choice=True)
            self.games[ctx.channel.id] = game


            await game.run_game()
        except Exception as e:
            await ctx.send(f"Error in the test Hunger Games: {e}")
            raise e
        finally:
            if ctx.channel.id in self.games:
                del self.games[ctx.channel.id]


# JoinView class for player joining
class JoinView(View):
    def __init__(self, button, message, timeout=60):
        super().__init__(timeout=timeout)
        self.joined = set()
        self.message = message
        self.add_item(button)
        button.callback = self.button_callback

    async def button_callback(self, interaction):
        self.joined.add(interaction.user)
        await interaction.response.send_message(self.message, ephemeral=True)


async def setup(bot):
    await bot.add_cog(HGGameCog(bot))