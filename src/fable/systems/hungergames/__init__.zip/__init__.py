"""
The IdleRPG Discord Bot
Copyright (C) 2018-2021 Diniboy and Gelbpunkt
Copyright (C) 2023-2024 Lunar (PrototypeX37)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
"""
import asyncio
import copy
from typing import Dict, List, Tuple, Union, Optional

import discord
from discord import Embed

from discord.enums import ButtonStyle
from discord.ext import commands
from discord.ui.button import Button

from cogs.help import chunks
from utils import random
import random as randomm
from utils.checks import is_gm
from utils.i18n import _, locale_doc
from utils.joins import JoinView
from utils.misc import nice_join


class Player:
    def __init__(self, user, team_id=None):
        self.user = user
        self.name = user.name
        self.mention = user.mention
        self.avatar = user.avatar
        self.team_id = team_id
        self.health = 100
        self.food = 50
        self.water = 50
        self.weapons = []
        self.items = []
        self.status_effects = []
        self.kills = 0
        self.is_alive = True

    def add_item(self, item):
        self.items.append(item)

    def add_weapon(self, weapon):
        self.weapons.append(weapon)

    def add_status_effect(self, effect, duration=1):
        self.status_effects.append((effect, duration))

    def update_status_effects(self):
        """Update status effects at the end of a round"""
        new_status_effects = []
        for effect, duration in self.status_effects:
            if duration > 1:
                new_status_effects.append((effect, duration - 1))
            # Apply effect consequences that persist until removed
            if effect == "poisoned":
                self.health -= 10
            elif effect == "wounded":
                self.health -= 5
            elif effect == "infection":
                self.health -= 15
        self.status_effects = new_status_effects

        # Basic survival mechanics
        self.food -= randomm.randint(5, 15)
        self.water -= randomm.randint(10, 20)

        if self.food <= 0:
            self.health -= 10
            self.food = 0
        if self.water <= 0:
            self.health -= 15
            self.water = 0

        if self.health <= 0:
            self.is_alive = False
            return False
        return True


class Team:
    def __init__(self, team_id, players):
        self.team_id = team_id
        self.players = players
        self.base = None
        self.alliances = []  # List of Team objects
        self.enemies = []     # List of Team objects
        self.items = []
        self.weapons = []
        self.traps = []


    def form_alliance(self, other_team):
        """Form alliance with another team"""
        if other_team not in self.alliances and other_team != self:
            self.alliances.append(other_team)
            other_team.alliances.append(self)
            # Remove from enemies if present
            if other_team in self.enemies:
                self.enemies.remove(other_team)
            if self in other_team.enemies:
                other_team.enemies.remove(self)

    def break_alliance(self, other_team):
        """Break alliance with another team"""
        if other_team in self.alliances:
            self.alliances.remove(other_team)
            other_team.alliances.remove(self)
            self.enemies.append(other_team)
            other_team.enemies.append(self)

    def is_active(self):
        return any(player.is_alive for player in self.players)

    def get_alive_players(self):
        return [player for player in self.players if player.is_alive]

    def add_item(self, item):
        self.items.append(item)

    def add_weapon(self, weapon):
        self.weapons.append(weapon)

    def add_trap(self, trap_type, location):
        self.traps.append((trap_type, location))


class GameBase:
    def __init__(self, ctx, players: list, is_test_mode=False, num_bots=2, force_choice=False):
        self.ctx = ctx
        self.raw_players = players
        self.players = []
        self.teams = []
        self.round = 1
        self.events = []
        self.map_areas = ["Cornucopia", "Forest", "Mountain", "Lake", "Cave", "Ruins", "Plains", "Beach"]
        self.current_area = "Cornucopia"
        self.is_test_mode = is_test_mode
        self.num_bots = num_bots  # Store the number of bots to add
        self.bot_players = []
        self.force_choice = force_choice
        self.bot_names = [
            "BotTribute1", "BotTribute2", "BotTribute3", "BotTribute4",
            "BotTribute5", "BotTribute6", "BotTribute7", "BotTribute8",
            "DeadlyBot", "SurvivorBot", "HunterBot", "SneakyBot"
        ]
        # Game state tracking
        self.day = 1
        self.is_night = False
        self.cornucopia_active = True
        self.special_events = []
        self.killed_this_round = []
        self.traps = []  # List of (trap_type, location, owner) tuples

        # Item and weapon lists with power values
        self.weapons = {
            "Wooden Spear": 10,
            "Bow": 15,
            "Crossbow": 20,
            "Sword": 25,
            "Mace": 30,
            "Chainsaw": 40,
            "Throwing Knives": 15,
            "Slingshot": 10,
            "Axe": 20,
            "Pickaxe": 15,
            "Machete": 20,
            "Trident": 25,
            "Brass Knuckles": 10,
            "Blowgun": 15,
            "Poison Darts": 25
        }

        self.items = {
            "First Aid Kit": "healing",
            "Bandages": "healing",
            "Backpack": "utility",
            "Water Canteen": "water",
            "Purification Tablets": "water",
            "Rope": "utility",
            "Sleeping Bag": "utility",
            "Night Vision Goggles": "utility",
            "Food Rations": "food",
            "Fishing Rod": "food",
            "Matches": "utility",
            "Camouflage Paint": "stealth",
            "Landmine": "trap",
            "Spikes": "trap",
            "Poison": "offensive",
            "Antidote": "healing",
            "Smoke Bomb": "escape",
            "Signal Flare": "utility",
            "Map": "intel",
            "Compass": "intel"
        }

    def get_active_teams(self):
        """Return list of teams with at least one living member"""
        return [team for team in self.teams if team.is_active()]

    def create_bot_player(self, name=None):
        """Create a bot player for testing"""
        if not name:
            name = self.bot_names.pop(0) if self.bot_names else f"Bot{randomm.randint(1,999)}"

        # Create a fake user object with the necessary attributes
        class FakeUser:
            def __init__(self, name):
                self.name = name
                self.mention = f"@{name}"
                self.avatar = None
                self.id = randomm.randint(10000, 99999)

        user = FakeUser(name)
        player = Player(user)
        self.bot_players.append(player)
        return player

    def rand_chunks(self, iterable):
        """Create random-sized chunks of the player list"""
        idx = 0
        for i in range(0, len(iterable)):
            if i < idx:
                continue
            num = random.randint(1, 4)
            yield iterable[i : i + num]
            idx += num

    def setup_game(self):
        """Initialize players and teams for the game"""
        if self.is_test_mode:
            # Add exactly self.num_bots bots
            for _ in range(self.num_bots):
                self.raw_players.append(self.create_bot_player())

        # Shuffle players for randomized teams
        all_players = copy.copy(self.raw_players)
        randomm.shuffle(all_players)

        # Create Player objects
        for idx, user in enumerate(all_players):
            player = Player(user) if not hasattr(user, 'health') else user
            self.players.append(player)

        # Form teams
        self.form_teams()

    def form_teams(self):
        """
        Create teams of exactly 2, with one leftover if odd.
        We'll assume the list is already shuffled in setup_game.
        """
        self.teams.clear()
        player_count = len(self.players)

        # Chunk players into pairs of 2
        chunked = [self.players[i: i + 2] for i in range(0, player_count, 2)]

        for team_id, chunk in enumerate(chunked):
            for p in chunk:
                p.team_id = team_id
            self.teams.append(Team(team_id, chunk))

    async def send_cast(self):
        """Display the teams and players"""
        embed = discord.Embed(title="The Hunger Games - The Cast", color=discord.Color.blue())

        for team in self.teams:
            team_members = [p.mention for p in team.players]
            if len(team_members) > 0:
                embed.add_field(
                    name=f"Team #{team.team_id + 1}",
                    value=nice_join(team_members),
                    inline=False
                )

        await self.ctx.send(embed=embed)

    def get_team_actions(self, team_size):
        """Get appropriate team actions based on team size"""
        # Team actions with real gameplay effects
        common_actions = [
            (_("search for water and food together"), {"type": "gather", "food": 20, "water": 30}),
            (_("set up a defensive camp"), {"type": "defend", "defense_bonus": 15}),
            (_("forge an alliance with another team"), {"type": "alliance"}),
            (_("hunt for wild game"), {"type": "gather", "food": 35}),
            (_("raid another team's supplies"), {"type": "raid"}),
            (_("set deadly traps for others"), {"type": "trap"}),
            (_("find a good vantage point to scout"), {"type": "scout"}),
            (_("train together to improve combat skills"), {"type": "train", "combat_bonus": 10}),
            (_("share supplies and treat each other's wounds"), {"type": "heal", "health": 20}),
            (_("ambush another tribute"), {"type": "ambush"}),
        ]

        # Actions specific to 2-person teams
        duo_actions = [
            (_("form a romantic alliance"), {"type": "bond", "morale": 20}),
            (_("share a heartfelt conversation by the fire"), {"type": "bond", "morale": 15}),
            (_("take shifts keeping watch during the night"), {"type": "defend", "defense_bonus": 20}),
            (_("teach each other survival skills"), {"type": "train", "skill_bonus": 15}),
        ]

        # Actions specific to 3+ person teams
        group_actions = [
            (_("split up to cover more ground"), {"type": "explore", "discovery_chance": 20}),
            (_("hold a strategy meeting"), {"type": "plan", "strategy_bonus": 15}),
            (_("combine their skills to create something useful"), {"type": "craft"}),
            (_("perform a coordinated hunt"), {"type": "hunt", "food": 40, "combat_bonus": 10}),
        ]

        # Lethal team actions
        lethal_actions = [
            (_("hunt down USER"), {"type": "kill", "target": "USER"}),
            (_("ambush USER at the river"), {"type": "kill", "target": "USER"}),
            (_("set a trap that kills USER"), {"type": "kill", "target": "USER"}),
            (_("surround and eliminate USER"), {"type": "kill", "target": "USER"}),
        ]

        # Team failures or accidents
        accident_actions = [
            (_("accidentally trigger their own trap"), {"type": "accident", "damage": 30}),
            (_("eat poisonous berries by mistake"), {"type": "poison", "damage": 25}),
            (_("get into a violent argument"), {"type": "betrayal"}),
            (_("lose their way and wander into danger"), {"type": "lost"}),
        ]

        # Build the action list based on team size
        if team_size == 2:
            actions = common_actions + duo_actions
        else:
            actions = common_actions + group_actions

        # Add some lethal and accident actions
        actions += lethal_actions + accident_actions

        return actions

    def get_solo_actions(self):
        """Get actions for solo players with meaningful gameplay effects"""
        # Basic survival actions
        survival_actions = [
            (_("search for food"), {"type": "gather", "food": 25}),
            (_("look for water"), {"type": "gather", "water": 30}),
            (_("set up a small shelter"), {"type": "shelter", "defense": 15}),
            (_("scout the area"), {"type": "scout", "intel": 1}),
            (_("forage for medicinal herbs"), {"type": "heal", "health": 20}),
            (_("hunt small game"), {"type": "hunt", "food": 20}),
            (_("fish at the lake"), {"type": "fish", "food": 15, "water": 10}),
        ]

        # Combat/offensive actions
        combat_actions = [
            (_("craft a makeshift weapon"), {"type": "craft", "weapon": True}),
            (_("set traps for other tributes"), {"type": "trap"}),
            (_("stalk another tribute"), {"type": "stalk"}),
            (_("attack USER"), {"type": "attack", "target": "USER"}),
            (_("ambush USER"), {"type": "ambush", "target": "USER"}),
            (_("poison USER's water supply"), {"type": "poison", "target": "USER"}),
        ]

        # Special actions
        special_actions = [
            (_("search for supplies at the Cornucopia"), {"type": "cornucopia"}),
            (_("steal from another tribute"), {"type": "steal"}),
            (_("form an alliance with another loner"), {"type": "alliance"}),
            (_("hide and observe other tributes"), {"type": "observe"}),
            (_("follow another tribute"), {"type": "follow"}),
        ]

        # Risky actions with high reward/risk
        risky_actions = [
            (_("attempt to raid a team's camp"), {"type": "raid", "team": True}),
            (_("search the most dangerous part of the arena"), {"type": "danger"}),
            (_("challenge USER to a direct fight"), {"type": "duel", "target": "USER"}),
            (_("attempt to steal from the strongest team"), {"type": "steal", "team": True}),
        ]

        # Desperate actions
        desperate_actions = [
            (_("run away and hide"), {"type": "hide"}),
            (_("beg for mercy from USER"), {"type": "beg", "target": "USER"}),
            (_("play dead to avoid detection"), {"type": "fake_death"}),
            (_("make a desperate attack on USER"), {"type": "desperate", "target": "USER"}),
        ]

        # Self-ending actions
        end_actions = [
            (_("take a lethal poison"), {"type": "suicide"}),
            (_("walk into a known trap zone"), {"type": "suicide"}),
            (_("give up and stop running"), {"type": "surrender"}),
        ]

        # Combine all action types with weights to control frequency
        all_actions = survival_actions * 3 + combat_actions * 2 + special_actions * 2 + risky_actions + desperate_actions

        # Add end actions only rarely
        if randomm.random() < 0.05:  # 5% chance
            all_actions.extend(end_actions)

        return all_actions

    def process_action_effects(self, player, action_data):
        """Process the effects of an action on a player"""
        action_type = action_data.get("type", "")
        result_text = ""

        if action_type == "gather":
            food_gain = action_data.get("food", 0)
            water_gain = action_data.get("water", 0)

            if food_gain:
                player.food = min(100, player.food + food_gain)
                result_text += f" Found {food_gain} food."

            if water_gain:
                player.water = min(100, player.water + water_gain)
                result_text += f" Found {water_gain} water."

        elif action_type == "heal":
            health_gain = action_data.get("health", 0)
            player.health = min(100, player.health + health_gain)
            result_text += f" Restored {health_gain} health."

        elif action_type == "craft":
            if action_data.get("weapon", False):
                weapon = randomm.choice(list(self.weapons.keys()))
                player.add_weapon(weapon)
                result_text += f" Crafted a {weapon}."
            else:
                item = randomm.choice(list(self.items.keys()))
                player.add_item(item)
                result_text += f" Crafted a {item}."

        elif action_type == "trap":
            trap_type = randomm.choice(["snare", "pitfall", "poisoned spikes", "tripwire"])
            location = randomm.choice(self.map_areas)
            self.traps.append((trap_type, location, player))
            result_text += f" Set a {trap_type} trap in the {location}."

        elif action_type == "attack" or action_type == "ambush":
            target = action_data.get("target")
            if isinstance(target, Player) and target.is_alive:
                # Calculate attack success chance and damage
                weapon_power = 0
                for weapon in player.weapons:
                    weapon_power += self.weapons.get(weapon, 5)

                base_chance = 50 + weapon_power
                if action_type == "ambush":
                    base_chance += 20

                if randomm.randint(1, 100) <= base_chance:
                    # Attack succeeds
                    damage = randomm.randint(10, 30) + weapon_power//2
                    target.health -= damage
                    result_text += f" Dealt {damage} damage to {target.name}."

                    if target.health <= 0:
                        target.is_alive = False
                        player.kills += 1
                        self.killed_this_round.append(target)
                        result_text += f" {target.name} has been eliminated!"
                else:
                    result_text += f" Attempted to attack {target.name} but missed."

        elif action_type == "cornucopia":
            if self.cornucopia_active:
                # Higher risk, higher reward
                if randomm.randint(1, 100) <= 40:  # 40% chance of injury
                    damage = randomm.randint(10, 25)
                    player.health -= damage
                    result_text += f" Was injured at the Cornucopia, taking {damage} damage."

                    if player.health <= 0:
                        player.is_alive = False
                        self.killed_this_round.append(player)
                        result_text += f" {player.name} died at the Cornucopia!"
                        return result_text

                # Get rewards
                num_items = randomm.randint(1, 3)
                for _ in range(num_items):
                    if randomm.random() < 0.6:  # 60% chance for an item
                        item = randomm.choice(list(self.items.keys()))
                        player.add_item(item)
                        result_text += f" Found a {item}."
                    else:  # 40% chance for a weapon
                        weapon = randomm.choice(list(self.weapons.keys()))
                        player.add_weapon(weapon)
                        result_text += f" Found a {weapon}."
            else:
                result_text += " Found the Cornucopia empty."

        elif action_type == "suicide" or action_type == "surrender":
            player.health = 0
            player.is_alive = False
            self.killed_this_round.append(player)
            result_text += f" {player.name} has eliminated themselves from the games."

        return result_text

    async def process_team_action(self, team, action_text, action_data):
        """Process a team action with team targeting"""
        result_text = action_text
        alive_members = team.get_alive_players()

        if not alive_members:
            return result_text

        action_type = action_data.get("type", "")
        target_team = action_data.get("target_team")

        # Get alive players in this team
        alive_players = team.get_alive_players()
        if not alive_players:
            return result_text

        action_type = action_data.get("type", "")

        # Team heal action
        if action_type == "heal":
            health_gain = action_data.get("health", 15)
            for player in alive_players:
                player.health = min(100, player.health + health_gain)
            result_text += f" Each team member restores {health_gain} health."

        # Team resource gathering
        elif action_type == "gather" or action_type == "hunt":
            food_gain = action_data.get("food", 0)
            water_gain = action_data.get("water", 0)

            # Distribute resources among team members
            for player in alive_players:
                if food_gain:
                    player.food = min(100, player.food + food_gain)
                if water_gain:
                    player.water = min(100, player.water + water_gain)

            if food_gain:
                result_text += f" The team gathered {food_gain} food per person."
            if water_gain:
                result_text += f" The team found {water_gain} water per person."

        # Team training/bonding
        elif action_type == "train" or action_type == "bond":
            # Apply bonuses to all team members (handled abstractly for now)
            bonus_type = "combat" if action_type == "train" else "morale"
            result_text += f" The team's {bonus_type} increases."

        # Team killing action
        elif action_type == "kill":
            target = action_data.get("target")
            if isinstance(target, Player) and target.is_alive:
                # Calculate combined team attack power
                team_power = 0
                for player in alive_players:
                    for weapon in player.weapons:
                        team_power += self.weapons.get(weapon, 5)

                # Teams are much more effective than individuals
                base_chance = 70 + min(team_power, 30)

                if randomm.randint(1, 100) <= base_chance:
                    # Team attack succeeds
                    target.health = 0
                    target.is_alive = False
                    self.killed_this_round.append(target)

                    # Award kill to a random team member
                    killer = randomm.choice(alive_players)
                    killer.kills += 1

                    result_text += f" They successfully eliminated {target.name}!"
                else:
                    # Attack fails
                    result_text += f" They attempted to eliminate {target.name} but failed."

        # Team accident
        elif action_type == "accident":
            damage = action_data.get("damage", 20)
            for player in alive_players:
                player.health -= damage
                if player.health <= 0:
                    player.is_alive = False
                    self.killed_this_round.append(player)

            casualties = [p for p in alive_players if p.health <= 0]
            if casualties:
                casualty_names = [p.name for p in casualties]
                result_text += f" {nice_join(casualty_names)} {'were' if len(casualties) > 1 else 'was'} killed in the accident."
            else:
                result_text += f" Everyone was injured, taking {damage} damage."

        # Team betrayal (random chance for team to break apart)
        elif action_type == "betrayal" and target_team:
            if target_team in team.alliances:
                team.break_alliance(target_team)
                result_text += f" betrays Team {target_team.team_id+1}!"
                # 50% chance of free attack
                if randomm.random() < 0.5:
                    damage = randomm.randint(20, 40)
                    victim = randomm.choice(target_team.get_alive_players())
                    victim.health -= damage
                    if victim.health <= 0:
                        victim.is_alive = False
                        self.killed_this_round.append(victim)
                        result_text += f" Killed {victim.name} in the betrayal!"
            else:
                result_text += " Can't betray a non-ally!"


        elif action_type == "attack" and target_team:
            if target_team.team_id == team.team_id:
                return result_text + " Can't attack themselves!"

            # Calculate team strengths
            attacker_power = sum(len(p.weapons) for p in alive_members)
            defender_power = sum(len(p.weapons) for p in target_team.get_alive_players())

            # Base 60% chance + difference in power
            success_chance = 60 + (attacker_power - defender_power)
            success = randomm.randint(1, 100) <= success_chance

            if success:
                # Calculate damage based on team sizes
                damage_per_member = randomm.randint(15, 25)
                casualties = []

                for defender in target_team.get_alive_players():
                    # Check for armor
                    if "Armor" in defender.items:
                        damage_per_member = max(0, damage_per_member - 10)
                        defender.items.remove("Armor")

                    defender.health -= damage_per_member
                    if defender.health <= 0:
                        defender.is_alive = False
                        casualties.append(defender.name)
                        self.killed_this_round.append(defender)
                        # Award kill to random attacker
                        randomm.choice(alive_members).kills += 1

                result_text += f" attacks Team {target_team.team_id + 1}!"
                if casualties:
                    result_text += f"\nCasualties: {', '.join(casualties)}"
            else:
                result_text += " fails their attack!"

        elif action_type == "alliance" and target_team:
            if target_team in team.alliances:
                result_text += " Already allied with this team!"
            else:
                team.form_alliance(target_team)
                result_text += f" forms alliance with Team {target_team.team_id+1}!"


        return result_text

    async def handle_special_events(self):
        """Create random arena events that affect all players"""
        # Only trigger special events occasionally
        if randomm.random() > 0.2:  # 20% chance per round
            return None

        possible_events = [
            ("Game Maker Fireball", "A series of fireballs rain down from the sky!", "damage"),
            ("Freezing Weather", "The temperature drops dramatically overnight.", "cold"),
            ("Fog of Death", "A toxic fog slowly creeps through the arena.", "poison"),
            ("Feast at Cornucopia", "A feast has been laid out at the Cornucopia with supplies for all!", "feast"),
            ("Flash Flood", "Water rapidly rises in the lower parts of the arena.", "flood"),
            ("Muttation Attack", "Genetically modified creatures hunt the tributes.", "mutts"),
            ("Forest Fire", "A section of the forest has been set ablaze.", "fire"),
            ("Supply Drop", "Parachutes with supplies descend into the arena.", "supplies"),
            ("Arena Shift", "The arena's geography changes, forcing tributes to move.", "shift"),
            ("Tracker Jacker Nest", "Nests of deadly wasps have been placed around the arena.", "wasps")
        ]

        event = randomm.choice(possible_events)
        event_name, event_desc, event_type = event

        embed = discord.Embed(
            title=f"Special Event: {event_name}",
            description=event_desc,
            color=discord.Color.red()
        )

        # Apply event effects to players
        if event_type == "damage":
            # Random damage to random players
            affected = []
            for player in [p for p in self.players if p.is_alive]:
                if randomm.random() < 0.3:  # 30% chance to be hit
                    damage = randomm.randint(10, 30)
                    player.health -= damage
                    affected.append(f"{player.name} (-{damage} health)")

                    if player.health <= 0:
                        player.is_alive = False
                        self.killed_this_round.append(player)
                        affected[-1] += " [KILLED]"

            if affected:
                embed.add_field(name="Affected Tributes", value="\n".join(affected))
            else:
                embed.add_field(name="Results", value="Everyone managed to find shelter in time.")

        elif event_type == "cold":
            # Cold weather affects those without shelter
            affected = []
            for player in [p for p in self.players if p.is_alive]:
                has_shelter = "Sleeping Bag" in player.items
                if not has_shelter:
                    damage = randomm.randint(5, 15)
                    player.health -= damage
                    affected.append(f"{player.name} (-{damage} health)")

                    if player.health <= 0:
                        player.is_alive = False
                        self.killed_this_round.append(player)
                        affected[-1] += " [KILLED]"
                else:
                    affected.append(f"{player.name} (protected by shelter)")

            embed.add_field(name="Affected Tributes", value="\n".join(affected))

        elif event_type == "feast":
            # Cornucopia feast - can lead to conflicts
            self.cornucopia_active = True
            embed.add_field(
                name="Announcement",
                value="All tributes are invited to a feast at the Cornucopia. Weapons, food, medicine, and other supplies await those brave enough to claim them."
            )

        elif event_type == "supplies":
            # Random supply drops for some players
            recipients = []
            for player in [p for p in self.players if p.is_alive]:
                if randomm.random() < 0.4:  # 40% chance to get supplies
                    if randomm.random() < 0.7:  # 70% item, 30% weapon
                        item = randomm.choice(list(self.items.keys()))
                        player.add_item(item)
                        recipients.append(f"{player.name} received {item}")
                    else:
                        weapon = randomm.choice(list(self.weapons.keys()))
                        player.add_weapon(weapon)
                        recipients.append(f"{player.name} received {weapon}")

            if recipients:
                embed.add_field(name="Supply Recipients", value="\n".join(recipients))
            else:
                embed.add_field(name="Results", value="The supplies were taken by unknown forces.")

        else:
            # Generic effect for other event types
            affected = []
            for player in [p for p in self.players if p.is_alive]:
                if randomm.random() < 0.3:  # 30% chance to be affected
                    damage = randomm.randint(5, 15)
                    player.health -= damage
                    affected.append(f"{player.name} (-{damage} health)")

                    if player.health <= 0:
                        player.is_alive = False
                        self.killed_this_round.append(player)
                        affected[-1] += " [KILLED]"

            if affected:
                embed.add_field(name="Affected Tributes", value="\n".join(affected))
            else:
                embed.add_field(name="Results", value="Everyone managed to avoid the danger.")

        return embed

    async def get_inputs(self):
        """Get and process player actions for a round."""
        self.killed_this_round = []

        manual_round = self.force_choice or (self.round % 2 == 0)

        self.is_night = not self.is_night
        if not self.is_night:
            self.day += 1

        special_event = await self.handle_special_events()

        time_of_day = "Night" if self.is_night else "Day"
        roundtext = f"**{time_of_day} {self.day} - Round {self.round}**"
        status = await self.ctx.send(roundtext)

        user_actions = []

        alive_players = [p for p in self.players if p.is_alive]
        teams = {}
        for player in alive_players:
            teams.setdefault(player.team_id, []).append(player)

        for team_group in teams.values():
            if len(team_group) == 1:
                # SOLO ACTION HANDLING
                player = team_group[0]
                prompt_text = f"Letting {player.mention} choose their action..."
                try:
                    await status.edit(content=f"{status.content}\n{prompt_text}")
                except discord.errors.NotFound:
                    status = await self.ctx.send(roundtext)

                actions = self.get_solo_actions()
                allowed_types_solo = {
                    "gather", "heal", "craft", "trap", "attack", "ambush", "cornucopia",
                    "shelter", "scout", "hunt", "fish"
                }
                filtered_actions = [
                    act for act in actions
                    if (not isinstance(act[1], dict)) or (act[1].get("type") in allowed_types_solo)
                ]
                possible_actions = random.sample(filtered_actions, min(5, len(filtered_actions)))
                possible_targets = [p for p in alive_players if p != player]
                target = random.choice(possible_targets) if possible_targets else None

                actions_with_targets = []
                for action_text, action_data in possible_actions:
                    if isinstance(action_data, dict) and action_data.get("target") == "USER" and target:
                        new_text = action_text.replace("USER", target.name)
                        new_data = action_data.copy()
                        new_data["target"] = target
                        actions_with_targets.append((new_text, new_data))
                    else:
                        actions_with_targets.append((action_text, action_data))

                action_descriptions = [a[0] for a in actions_with_targets]
                selected_index = 0

                if (player in self.bot_players and not self.force_choice) or not manual_round:
                    if player.health < 30 or player.food < 20 or player.water < 20:
                        for i, (_, data) in enumerate(actions_with_targets):
                            if isinstance(data, dict) and (
                                    data.get("type") in {"heal", "gather"} or
                                    data.get("health", 0) > 0 or data.get("food", 0) > 0 or data.get("water", 0) > 0
                            ):
                                selected_index = i
                                break
                    elif player.weapons and target and randomm.random() < 0.7:
                        for i, (_, data) in enumerate(actions_with_targets):
                            if isinstance(data, dict) and (data.get("type") in {"attack", "ambush"}):
                                selected_index = i
                                break
                    else:
                        selected_index = randomm.randint(0, len(actions_with_targets) - 1)
                else:
                    if player in self.bot_players:
                        selected_index = randomm.randint(0, len(actions_with_targets) - 1)
                    else:
                        try:
                            selected_index = await self.ctx.bot.paginator.Choose(
                                entries=action_descriptions,
                                return_index=True,
                                title=("Choose an action"),
                            ).paginate(self.ctx, location=player.user)
                        except (self.ctx.bot.paginator.NoChoice, discord.Forbidden, asyncio.TimeoutError):
                            await self.ctx.send(
                                ("I couldn't DM {user} or they didn't choose! Choosing a random action...").format(
                                    user=player.name),
                                delete_after=30,
                            )
                            selected_index = randomm.randint(0, len(actions_with_targets) - 1)
                        else:
                            if hasattr(player.user, "send"):
                                try:
                                    await player.user.send(f"Return to the Hunger Games: {self.ctx.message.jump_url}")
                                except Exception:
                                    pass

                selected_action = actions_with_targets[selected_index]
                action_text, action_data = selected_action
                result_text = self.process_action_effects(player, action_data)
                full_text = f"{action_text}{result_text}"
                user_actions.append((player.name, full_text))
                try:
                    await status.edit(content=f"{status.content} - Done")
                except discord.errors.NotFound:
                    pass

            else:
                # TEAM ACTION HANDLING WITH TEAM TARGETING
                current_team = next((t for t in self.teams if t.team_id == team_group[0].team_id), None)
                possible_target_teams = [
                    t for t in self.teams
                    if t.team_id != current_team.team_id and t.is_active()
                ]

                # Add team action prompt
                team_members = [p.name for p in team_group]
                prompt_text = f"Letting Team {current_team.team_id + 1} ({', '.join(team_members)}) choose their action..."
                try:
                    await status.edit(content=f"{status.content}\n{prompt_text}")
                except discord.errors.NotFound:
                    status = await self.ctx.send(roundtext)

                team_actions = self.get_team_actions(len(team_group))
                allowed_types_team = {
                    "gather", "defend", "alliance", "raid", "trap", "scout", "train", "heal",
                    "ambush", "hunt", "plan", "attack", "betrayal"
                }
                filtered_team_actions = [
                    act for act in team_actions
                    if (not isinstance(act[1], dict)) or (act[1].get("type") in allowed_types_team)
                ]
                actions_with_targets = random.sample(filtered_team_actions, min(5, len(filtered_team_actions)))

                # Convert individual targets to team targets
                processed_actions = []
                for action_text, action_data in actions_with_targets:
                    new_data = action_data.copy()
                    new_text = action_text

                    if isinstance(new_data, dict):
                        # Handle team targeting
                        if new_data.get("target") == "USER" and possible_target_teams:
                            target_team = random.choice(possible_target_teams)
                            new_text = action_text.replace("USER", f"Team {target_team.team_id + 1}")
                            new_data["target_team"] = target_team
                            del new_data["target"]

                        # Add acting team reference
                        new_data["acting_team"] = current_team

                    processed_actions.append((new_text, new_data))

                actions_with_targets = processed_actions

                random.shuffle(team_group)
                chooser = None
                for p in team_group:
                    if p not in self.bot_players:
                        chooser = p
                        break
                if chooser is None:
                    chooser = team_group[0]

                selected_index = 0
                if (chooser in self.bot_players and not self.force_choice) or not manual_round:
                    selected_index = randomm.randint(0, len(actions_with_targets) - 1)
                else:
                    if chooser in self.bot_players:
                        selected_index = randomm.randint(0, len(actions_with_targets) - 1)
                    else:
                        action_descriptions = [a[0] for a in actions_with_targets]
                        try:
                            selected_index = await self.ctx.bot.paginator.Choose(
                                entries=action_descriptions,
                                return_index=True,
                                title=("Choose a team action for your team"),
                            ).paginate(self.ctx, location=chooser.user)
                        except (self.ctx.bot.paginator.NoChoice, discord.Forbidden, asyncio.TimeoutError):
                            await self.ctx.send(
                                ("I couldn't DM {user} or they didn't choose! Choosing a random team action...").format(
                                    user=chooser.name),
                                delete_after=30,
                            )
                            selected_index = randomm.randint(0, len(actions_with_targets) - 1)
                        else:
                            if hasattr(chooser.user, "send"):
                                try:
                                    await chooser.user.send(f"Return to the Hunger Games: {self.ctx.message.jump_url}")
                                except Exception:
                                    pass

                selected_action = actions_with_targets[selected_index]
                action_text, action_data = selected_action
                result_text = await self.process_team_action(
                    current_team,
                    action_text,
                    action_data
                )
                user_actions.append((f"Team {current_team.team_id + 1}", result_text))

        # Status effects and final updates
        for player in self.players:
            if player.is_alive:
                if not player.update_status_effects():
                    self.killed_this_round.append(player)

        embed_color = discord.Color.dark_blue() if self.is_night else discord.Color.green()
        embed = discord.Embed(
            title=f"{time_of_day} {self.day} - Round {self.round}",
            color=embed_color
        )
        for actor, action in user_actions:
            embed.add_field(name=actor, value=action, inline=False)
        await self.ctx.send(embed=embed)

        if special_event:
            await self.ctx.send(embed=special_event)

        if self.killed_this_round:
            killed_names = [p.name for p in self.killed_this_round]
            cannon_embed = discord.Embed(
                title="Cannon Shots",
                description=f"The following tributes have fallen:\n{nice_join(killed_names)}",
                color=discord.Color.red()
            )
            await self.ctx.send(embed=cannon_embed)

        if self.round >= 3:
            self.cornucopia_active = False

        self.round += 1
        for player in self.killed_this_round:
            if player in self.players:
                player.is_alive = False

    async def show_player_stats(self):
        alive_players = [p for p in self.players if p.is_alive]
        if not alive_players:
            return

        embed = discord.Embed(
            title="Current Tribute Status",
            description=f"Remaining: {len(alive_players)}/{len(self.players)}",
            color=discord.Color.blue()
        )

        # Group players by team
        for team in self.teams:
            team_players = team.get_alive_players()
            if not team_players:
                continue

            # You can shorten the lines:
            lines = []
            for player in team_players:
                lines.append(
                    f"**{player.name}** | HP: {player.health} | Kills: {player.kills}"
                )

            embed.add_field(
                name=f"Team {team.team_id + 1}",
                value="\n".join(lines),
                inline=False
            )

        await self.ctx.send(embed=embed)

    async def show_final_stats(self):
        embed = discord.Embed(title="Final Statistics", color=discord.Color.blue())

        # Team standings
        team_lines = []
        for team in sorted(self.teams, key=lambda t: t.team_id):
            status = "Survived" if team.is_active() else "Eliminated"
            members = ", ".join([p.name for p in team.players])
            team_lines.append(
                f"**Team {team.team_id + 1}** ({status})\n"
                f"Members: {members}\n"
                f"Kills: {sum(p.kills for p in team.players)}"
            )

        embed.add_field(name="Team Standings", value="\n\n".join(team_lines), inline=False)

        # Individual leaderboard
        sorted_players = sorted(self.players, key=lambda p: p.kills, reverse=True)
        kill_leaders = "\n".join(
            [f"{p.name}: {p.kills} kills" for p in sorted_players[:5]]
        )
        embed.add_field(name="Top Killers", value=kill_leaders, inline=False)

        await self.ctx.send(embed=embed)


    async def main(self):
        """Main game loop"""
        # Setup the game
        self.setup_game()

        # Show the starting cast
        await self.send_cast()

        # Initial round
        embed = discord.Embed(
            title="Let the Hunger Games begin!",
            description="The tributes are rising on their platforms as the countdown begins...",
            color=discord.Color.gold()
        )
        await self.ctx.send(embed=embed)

        # Initial cornucopia bloodbath
        await asyncio.sleep(6)

        # Game loop
        while len(self.get_active_teams()) > 1:
            await self.get_inputs()

            # Break alliances when only allied teams remain
            active_teams = self.get_active_teams()
            if len(active_teams) == 2:
                team1, team2 = active_teams
                if team1 in team2.alliances:
                    team1.break_alliance(team2)
                    await self.ctx.send(
                        "**The final alliance breaks!** "
                        f"Team {team1.team_id + 1} and Team {team2.team_id + 1} turn on each other!"
                    )

            if self.round % 3 == 0:
                await self.show_player_stats()

            await asyncio.sleep(6)

        # Game over - announce winner or draw
        winning_teams = self.get_active_teams()
        if len(winning_teams) == 1:
            winner = winning_teams[0]
            members = winner.get_alive_players()
            embed = discord.Embed(
                title="Hunger Games Results",
                description=_("Team {team_id} wins!").format(team_id=winner.team_id + 1),
                color=discord.Color.gold()
            )

            # Add team members
            member_list = "\n".join(
                [f"{p.mention} | Kills: {p.kills} | Health: {p.health}"
                 for p in members]
            )
            embed.add_field(name="Surviving Members", value=member_list)

            # Add team stats
            total_kills = sum(p.kills for p in winner.players)
            embed.set_footer(text=f"Total team kills: {total_kills}")

            # Add team thumbnail
            if members:
                avatar_url = str(members[0].avatar) if members[0].avatar else None
                if avatar_url:
                    embed.set_thumbnail(url=avatar_url)

        else:  # No teams left (shouldn't happen)
            embed = discord.Embed(
                title="Hunger Games Results",
                description="The arena claims all!",
                color=discord.Color.red()
            )

        # Game summary with kill counts

        await self.ctx.send(embed=embed)
        await self.show_final_stats()


class HungerGames(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.games = {}

    @commands.command(aliases=["hg"], brief=_("Play the hunger games"))
    @locale_doc
    async def hungergames(self, ctx):
        _(
            """Starts the hunger games

            Players will be able to join via the :shallow_pan_of_food: emoji.
            The game is controlled via both random actions and possibly chosen actions.
            Players may choose an action if they get a direct message from the bot. If no action is chosen by the player, the bot chooses one for them.

            Not every player will get the opportunity to choose an action. Sometimes nobody gets to choose, so don't be discouraged.

            The new and improved system includes:
            - Resource management (health, food, water)
            - Weapons and items that affect combat
            - Team mechanics that make teams meaningful
            - Day/night cycles and special events
            - Status effects and more strategic choices
            """
        )

        #return await ctx.send("New Version being worked on. Command cancelled")

        if self.games.get(ctx.channel.id):
            return await ctx.send(_("There is already a game in here!"))

        self.games[ctx.channel.id] = "forming"

        if ctx.channel.id == self.bot.config.game.official_tournament_channel_id:
            view = JoinView(
                Button(
                    style=ButtonStyle.primary,
                    label="Join the Hunger Games!",
                    emoji="\U0001f958",
                ),
                message=_("You joined the Hunger Games."),
                timeout=60 * 10,
            )
            await ctx.send(
                f"{ctx.author.mention} started a mass-game of Hunger Games!",
                view=view,
            )
            await asyncio.sleep(60 * 10)
            view.stop()
            players = list(view.joined)
        else:
            view = JoinView(
                Button(
                    style=ButtonStyle.primary,
                    label="Join the Hunger Games!",
                    emoji="\U0001f958",
                ),
                message=_("You joined the Hunger Games."),
                timeout=60 * 2,
            )
            view.joined.add(ctx.author)
            text = _("{author} started a game of Hunger Games!")
            await ctx.send(text.format(author=ctx.author.mention), view=view)
            await asyncio.sleep(60 * 2)
            view.stop()
            players = list(view.joined)

        if len(players) < 2:
            del self.games[ctx.channel.id]
            await self.bot.reset_cooldown(ctx)
            return await ctx.send(_("Not enough players joined..."))

        game = GameBase(ctx, players=players)
        self.games[ctx.channel.id] = game
        try:
            await game.main()
        except Exception as e:
            await ctx.send(
                _(f"{e} An error happened during the hungergame. Please try again!")
            )
            raise e
        finally:
            try:
                del self.games[ctx.channel.id]
            except KeyError:  # got stuck in between
                pass

    @commands.command(aliases=["hgtest"], brief=_("Test the hunger games with bots"))
    @locale_doc
    async def hungergamestest(self, ctx, num_bots: int = 8):
        _(
            """Starts a test hunger games with bots

            You can specify how many bots to add to the game.
            This command is useful for testing the hunger games without needing real players.

            Usage: !hungergamestest [num_bots]
            """
        )
        if self.games.get(ctx.channel.id):
            return await ctx.send(_("There is already a game in here!"))

        self.games[ctx.channel.id] = "forming"

        # Add the command author
        players = [ctx.author]

        # Make sure num_bots is within a reasonable range
        num_bots = min(max(1, num_bots), 23)  # 1 <= num_bots <= 23

        await ctx.send(
            _("{author} started a test game of Hunger Games with {num} bots!").format(
                author=ctx.author.mention,
                num=num_bots
            )
        )

        # Pass num_bots to GameBase
        game = GameBase(ctx, players=players, is_test_mode=True, num_bots=num_bots, force_choice=True)
        self.games[ctx.channel.id] = game

        try:
            await game.main()
        except Exception as e:
            await ctx.send(
                _(f"{e} An error happened during the test hungergame. Please try again!")
            )
            raise e
        finally:
            try:
                del self.games[ctx.channel.id]
            except KeyError:  # got stuck in between
                pass


async def setup(bot):
    await bot.add_cog(HungerGames(bot))